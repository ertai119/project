#include "StdAfx.h"
#include "SerialComm.h"

CSerialComm::CSerialComm(void)
{
	m_hParentPort = NULL;
	m_lParentThread = 0;

	m_hThreadTerm = NULL;
	m_hThreadHandle = NULL;
	m_ThreadID = 0;

	m_long_StartFlag = 0;
	SetStartFlag(FALSE);

	::ZeroMemory(&m_TTY, sizeof(TTYSTRUCT));

	m_hCommPort = NULL;
	bConnected = FALSE;

	::ZeroMemory(&osRead, sizeof(OVERLAPPED));
	::ZeroMemory(&osWrite, sizeof(OVERLAPPED));

	InitializeCriticalSection (&m_csLock );
}

CSerialComm::~CSerialComm(void)
{
   if(bConnected)
   {
      TRACE(_T("Warning: terminating COMM connection in CSerialComm::~CSerialComm()\n"));
      Disconnect();
   }
   DeleteCriticalSection (&m_csLock );
}

BOOL CSerialComm::Start(HANDLE hParentPort, LPTTYSTRUCT lpTTY, LPCTSTR pCommName)
{
	if(GetStartFlag() == FALSE)
	{
		m_hParentPort = hParentPort;
		CopyMemory(&m_TTY, lpTTY, sizeof(TTYSTRUCT));

		if(lstrlen(pCommName)) lstrcpy(m_CommName, pCommName);

		m_hThreadTerm = ::CreateEvent(0, 0, 0, 0);
		m_hThreadHandle = ::CreateThread(NULL, 0, CSerialComm::ListenProc, this, 0, &m_ThreadID);
	}
	return TRUE;
}

void CSerialComm::Stop()
{
	if(GetStartFlag() == TRUE)
	{
		SignalObjectAndWait(m_hThreadTerm, m_hThreadHandle, INFINITE, FALSE);

		m_hParentPort = NULL;
		m_lParentThread = 0;
		lstrcpy(m_CommName, _T(""));
		::CloseHandle(m_hThreadTerm);
		::CloseHandle(m_hThreadHandle);

		m_hThreadTerm = NULL;
		m_hThreadHandle = NULL;
		m_ThreadID = 0;
	}
}

BOOL CSerialComm::IsConnected() const
{
   return (bConnected);
}


BOOL CSerialComm::CreateSerialPort(LPTTYSTRUCT lpTTY)
{
	TCHAR      szPort[ 15 ] ;

	osWrite.Offset = 0 ;
	osWrite.OffsetHigh = 0 ;
	osRead.Offset = 0 ;
	osRead.OffsetHigh = 0 ;

	if((osRead.hEvent = CreateEvent( NULL, TRUE, FALSE, NULL )) == NULL)
		return FALSE;

	if((osWrite.hEvent = CreateEvent( NULL, TRUE, FALSE,  NULL )) == NULL)
	{
		CloseHandle( osRead.hEvent );
		osRead.hEvent = NULL;
		return FALSE;
	}

	if(lpTTY->byCommPort)
	{
		wsprintf( szPort, _T("COM%d"), lpTTY->byCommPort );

		m_hCommPort = ::CreateFile(szPort,	GENERIC_READ | GENERIC_WRITE, 
											0,
											NULL, OPEN_EXISTING, 
											FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED, 
											NULL);

		if(m_hCommPort == INVALID_HANDLE_VALUE)
		  return FALSE;

		BOOL bPurge = FALSE;
		if(::SetCommMask(m_hCommPort, EV_RXCHAR | EV_TXEMPTY))
		{
			if(::SetupComm(m_hCommPort, 4096, 4096))
			{
				if(::PurgeComm(m_hCommPort,	PURGE_TXABORT | PURGE_RXABORT |
										PURGE_TXCLEAR | PURGE_RXCLEAR))
				{
					bPurge = TRUE;
				}
			}
		}

		if(!bPurge)
		{
		  ::CloseHandle(m_hCommPort);
		  m_hCommPort = NULL;
		  return FALSE;
		}

		COMMTIMEOUTS CommTimeOuts;

		CommTimeOuts.ReadIntervalTimeout = 0xFFFFFFFF;
		CommTimeOuts.ReadTotalTimeoutMultiplier = 0;
		CommTimeOuts.ReadTotalTimeoutConstant = 1000;
		CommTimeOuts.WriteTotalTimeoutMultiplier = 0;
		CommTimeOuts.WriteTotalTimeoutConstant = 1000;

		if(!::SetCommTimeouts(m_hCommPort, &CommTimeOuts))
		{
			::CloseHandle(m_hCommPort);
			m_hCommPort = NULL;
			return FALSE;
		}
	}

	if (!SetupConnection(lpTTY))	
	{
		CloseHandle( m_hCommPort) ;
		m_hCommPort = NULL;
		return FALSE;
	}


	return TRUE;
}

BOOL CSerialComm::SetupConnection(LPTTYSTRUCT lpTTY, bool bReconnect)
{
	if(bReconnect)
	{
		CopyMemory(&m_TTY, lpTTY, sizeof(TTYSTRUCT));
		Disconnect();
		return CreateSerialPort(lpTTY);
	}

	if(m_hCommPort == NULL || m_hCommPort == INVALID_HANDLE_VALUE)
		return FALSE;
 
	DCB dcb;
	::ZeroMemory(&dcb, sizeof(DCB));
	dcb.DCBlength = sizeof(DCB);

	if(!::GetCommState(m_hCommPort, &dcb))
	{
		::CloseHandle(m_hCommPort);
		m_hCommPort = NULL;
		return FALSE;
	}

	dcb.BaudRate = lpTTY->dwBaudRate;
	dcb.ByteSize = lpTTY->byByteSize;
	dcb.Parity = lpTTY->byParity;
	dcb.StopBits = lpTTY->byStopBits;

	BOOL bSet = (BYTE)((lpTTY->byFlowCtrl & FC_DTRDSR) != 0);
	dcb.fOutxDsrFlow = bSet;
	if(bSet)
		dcb.fDtrControl = DTR_CONTROL_HANDSHAKE;
	else
		dcb.fDtrControl = DTR_CONTROL_ENABLE;

	bSet = (BYTE)((lpTTY->byFlowCtrl & FC_RTSCTS) != 0);
	dcb.fOutxCtsFlow = bSet;
	if(bSet)
		dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;
	else
		dcb.fRtsControl = RTS_CONTROL_ENABLE;

	bSet = (BYTE)((lpTTY->byFlowCtrl & FC_XONXOFF) != 0);

	dcb.fInX = dcb.fOutX = bSet;
	dcb.XonChar = ASCII_XON;
	dcb.XoffChar = ASCII_XOFF;
	dcb.XonLim = 100;
	dcb.XoffLim = 100;

	dcb.fBinary = TRUE;
	dcb.fParity = TRUE;

	if(!::SetCommState(m_hCommPort, &dcb))
	{
		int error = ::GetLastError();

		::CloseHandle(m_hCommPort);
		m_hCommPort = NULL;
		return FALSE;
	}

	bConnected = TRUE;

	return bConnected;
}

BOOL CSerialComm::Disconnect()
{
   bConnected = FALSE;
   
   if(m_hCommPort && m_hCommPort != INVALID_HANDLE_VALUE)
   {
	   SetCommMask(m_hCommPort, 0);

	   EscapeCommFunction(m_hCommPort, CLRDTR);

	   PurgeComm(m_hCommPort, PURGE_TXABORT | PURGE_RXABORT |
						   PURGE_TXCLEAR | PURGE_RXCLEAR);

	   ::CloseHandle(m_hCommPort);
	   m_hCommPort = NULL;
   }

	if(osRead.hEvent)	::CloseHandle(osRead.hEvent);
	if(osWrite.hEvent)	::CloseHandle(osWrite.hEvent);

	osRead.hEvent = NULL;
	osWrite.hEvent = NULL;

   return TRUE;
}

int CSerialComm::ReadCommBlock(LPBYTE lpszBlock, DWORD nLen)
{
	DWORD dwErrorFlags;
	COMSTAT ComStat;

	::ClearCommError(m_hCommPort, &dwErrorFlags, &ComStat);
	DWORD dwLength = min((DWORD)nLen, ComStat.cbInQue);

	if(dwLength > 0)
	{
		BOOL bReadStat = ReadFile(m_hCommPort, lpszBlock, dwLength, &dwLength, &osRead);

		if(!bReadStat)
		{
			if(GetLastError() == ERROR_IO_PENDING)
			{
				OutputDebugString("\n\rIO Pending");
				while(!GetOverlappedResult(m_hCommPort, &osRead, &dwLength, TRUE))
				{
					DWORD dwError = GetLastError();
					if(dwError == ERROR_IO_INCOMPLETE)
					{
					  continue;
					}
					else
					{
					  ::ClearCommError(m_hCommPort, &dwErrorFlags, &ComStat);
					  if(dwErrorFlags > 0)
					  {
					  }

					  break;
					}
				}
			}
			else
			{
				dwLength = 0;
				ClearCommError(m_hCommPort, &dwErrorFlags, &ComStat);
				if(dwErrorFlags > 0)
				{
				}
			}
		}

		if(dwLength)
		{
			byte* lpbyte = NULL;
			lpbyte = (byte*)::CoTaskMemAlloc(dwLength);
			ZeroMemory(lpbyte, dwLength);
			::CopyMemory(lpbyte, lpszBlock, dwLength);

			TTYEvent* pEvent = (TTYEvent*)::CoTaskMemAlloc(sizeof(TTYEvent));
			ZeroMemory(pEvent, sizeof(TTYEvent));
			pEvent->ttyid = m_TTY.byCommPort;
			sprintf( pEvent->commdev, "COM%d", m_TTY.byCommPort );
			::time(&(pEvent->eventtime));
			pEvent->datasize = dwLength;
			pEvent->pdata = lpbyte;
			pEvent->pParam = (void*)this;
			::PostQueuedCompletionStatus(m_hParentPort, sizeof(*pEvent), SERIAL_COMM_RECEIVE, (LPOVERLAPPED)pEvent);
		}
		//
   }

   return dwLength;
} 

BOOL CSerialComm::WriteCommBlock(LPBYTE lpszBlock, DWORD dwBytesToWrite)
{
	DWORD		dwErrorFlags;
	BOOL        fWriteStat ;
	DWORD       dwBytesWritten ;
	COMSTAT		ComStat;

	DWORD	dwLength = dwBytesToWrite;

	if(m_hCommPort == NULL)
		return S_FALSE;

	::ClearCommError(m_hCommPort, &dwErrorFlags, &ComStat);
	fWriteStat = WriteFile( m_hCommPort, lpszBlock, dwBytesToWrite, &dwBytesWritten, &osWrite ) ;
	
	if(!fWriteStat)
	{
		if(GetLastError() == ERROR_IO_PENDING)
		{
			while(!GetOverlappedResult(m_hCommPort, &osWrite, &dwLength, TRUE))
			{
				DWORD dwError = GetLastError();
				if(dwError == ERROR_IO_INCOMPLETE)
				{
					// normal result if not finished
					continue;
				}
				else
				{
					// CAN DISPLAY ERROR MESSAGE HERE
					// an error occured, try to recover
					::ClearCommError(m_hCommPort, &dwErrorFlags, &ComStat);
					if(dwErrorFlags > 0)
					{
						// CAN DISPLAY ERROR MESSAGE HERE
						TRACE("ERROR");
						return TTY_ERROR_9;
					}
					break;
				}
			}
		}
		else
		{	// some other error occured
			dwLength = 0;
			ClearCommError(m_hCommPort, &dwErrorFlags, &ComStat);
			if(dwErrorFlags > 0)
			{
				// CAN DISPLAY ERROR MESSAGE HERE				
				TRACE("ERROR");
				return TTY_ERROR_9;
			}
		}		
	}

	return ( S_OK ) ;
} 


DWORD WINAPI CSerialComm::ListenProc(LPVOID lpParameter)
{
	CSerialComm* pParent = (CSerialComm*)lpParameter;

	HANDLE hParentPort = pParent->m_hParentPort;
	ULONG  hParentThread = pParent->m_lParentThread;

	if(pParent == NULL)
	{	// Error�� ǥ���Ѵ�.
		TRACE(_T("ERROR : Main Class is NULL"));
		return 1;
	}

	// Parent ���� Start �� �˸���.
	::PostQueuedCompletionStatus(pParent->m_hParentPort, 0, SERIAL_COMM_START, NULL);

	if(pParent->CreateSerialPort(&pParent->m_TTY) == FALSE)
	{
		TTYEvent* pEvent = (TTYEvent*)::CoTaskMemAlloc(sizeof(TTYEvent));
		ZeroMemory(pEvent, sizeof(TTYEvent));
		pEvent->ttyid = pParent->m_TTY.byCommPort;
		::time(&(pEvent->eventtime));
		pEvent->pParam = (void*)pParent;
		pEvent->result = TTY_ERROR_12;	
		::PostQueuedCompletionStatus(pParent->m_hParentPort, sizeof(*pEvent), SERIAL_COMM_ERROR, (LPOVERLAPPED)pEvent);
		return 1;
	}

	BOOL		bContinue = TRUE;
	DWORD		dwEventMask = 0;
	DWORD		dwResult;
	OVERLAPPED	ov;

	memset(&ov, 0, sizeof(ov));
	ov.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	if(ov.hEvent == NULL || !SetCommMask(pParent->m_hCommPort, EV_RXCHAR | EV_TXEMPTY))
	{
		TTYEvent* pEvent = (TTYEvent*)::CoTaskMemAlloc(sizeof(TTYEvent));
		ZeroMemory(pEvent, sizeof(TTYEvent));
		pEvent->ttyid = pParent->m_TTY.byCommPort;
		::time(&(pEvent->eventtime));
		pEvent->pParam = (void*)pParent;
		pEvent->result = TTY_ERROR_8;	
		::PostQueuedCompletionStatus(pParent->m_hParentPort, sizeof(*pEvent), SERIAL_COMM_ERROR, (LPOVERLAPPED)pEvent);
		return 1;
	}

	HANDLE arHandles[2];
	arHandles[0] = pParent->m_hThreadTerm;

	pParent->SetStartFlag(TRUE);								

	TTYEvent* pEvent = (TTYEvent*)::CoTaskMemAlloc(sizeof(TTYEvent));
	ZeroMemory(pEvent, sizeof(TTYEvent));
	pEvent->ttyid = pParent->m_TTY.byCommPort;
	::time(&(pEvent->eventtime));
	pEvent->pParam = (void*)pParent;
	::PostQueuedCompletionStatus(pParent->m_hParentPort, sizeof(*pEvent), SERIAL_COMM_CONNECT, (LPOVERLAPPED)pEvent);

	while(bContinue)
	{
		BOOL abRet = ::WaitCommEvent(pParent->m_hCommPort, &dwEventMask, &ov);
		if ( !abRet )
		{
		}

		arHandles[1] = ov.hEvent;

		dwResult = ::WaitForMultipleObjects(2, arHandles, FALSE, INFINITE);

		if(dwResult == WAIT_OBJECT_0)	
		{
			bContinue = FALSE;
			continue;
		}
		else if(dwResult == WAIT_OBJECT_0 + 1)
		{
			DWORD dwMask;
			if (GetCommMask(pParent->m_hCommPort, &dwMask) )
			{
				if (dwMask == EV_TXEMPTY)
				{
					TRACE(_T("Data sent"));
					::ResetEvent (ov.hEvent);
					continue;
				}

				if((dwMask & EV_RXCHAR) == EV_RXCHAR)
				{
					BYTE InData[MAX_RXBLOCK + 1];
					int  nLength ;

					do
					{
						if(nLength = pParent->ReadCommBlock((LPBYTE)&InData, MAX_RXBLOCK))
						{
						}
					} while(nLength > 0);
				}  
			}
		}

		::ResetEvent(ov.hEvent);
	}

	::CloseHandle(ov.hEvent);
	TRACE(_T("CSerialComm: ListenProc Thread Stop!"));

	return 0;
}