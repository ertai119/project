#pragma once

#include <Hash_Map>

#include "..\\Object\\MyObject.h"

using namespace std;

typedef stdext::hash_map< unsigned int, CWnd* > mapBtnGroup;

class cBtnGrouping : public cMyObject
{
private:
protected:

	CWnd		   *m_ClickedBtn;
	mapBtnGroup		m_BtnList;

public:

	void	Insert( unsigned int UID, CWnd *pClass );
	void	Delete( unsigned int UID);
	CWnd*	Find( unsigned int UID);
	int		Size(){return (int) m_BtnList.size(); }

	CWnd*	GetActive();
	BOOL	SetActive( unsigned int UID );

	cBtnGrouping();
	~cBtnGrouping();

};

