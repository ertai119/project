#include "stdafx.h"

#include "GroupingButton.h"
#include "XenButton.h"

//-------------------------------------------------------------------------------------------------------------

cBtnGrouping::cBtnGrouping()
{
	m_ClickedBtn = NULL;
}
//-------------------------------------------------------------------------------------------------------------

cBtnGrouping::~cBtnGrouping()
{

}
//-------------------------------------------------------------------------------------------------------------

void cBtnGrouping::Insert( unsigned int UID, CWnd *pClass )
{
	mapBtnGroup::iterator ip = m_BtnList.find( UID );

	if( ip != m_BtnList.end() )
	{
		::MessageBox( NULL, _T("Exist Same UID So Try with any key"), _T("Insert Failed"), MB_OK );
		return ;
	}

	m_BtnList.insert( mapBtnGroup::value_type(UID, pClass) );
}
//-------------------------------------------------------------------------------------------------------------

void cBtnGrouping::Delete( unsigned int UID)
{
	m_BtnList.erase( UID );
}
//-------------------------------------------------------------------------------------------------------------

CWnd* cBtnGrouping::Find( unsigned int UID)
{
	mapBtnGroup::iterator ip = m_BtnList.find( UID );

	if( ip != m_BtnList.end() )
		return ip->second;

	return NULL;
}
//-------------------------------------------------------------------------------------------------------------

CWnd* cBtnGrouping::GetActive()
{
	return m_ClickedBtn;
}
//-------------------------------------------------------------------------------------------------------------

BOOL cBtnGrouping::SetActive( unsigned int UID )
{
	cXenButton* pClass = (cXenButton*)Find( UID );

	if( !pClass )
		return FALSE;

	// Patrick Modified ------------------------
	if( m_ClickedBtn )
	{
		if(((cXenButton *)m_ClickedBtn)->IsWindowEnabled())
		{
			((cXenButton*)m_ClickedBtn)->MySetStat( XEN_BTN_ENABLE );
			((cXenButton*)m_ClickedBtn)->Invalidate();
		}
		((cXenButton*)m_ClickedBtn)->SetChecked( false );
		if( ((cXenButton*)m_ClickedBtn)->GetActivePage() )
			((cXenButton*)m_ClickedBtn)->GetActivePage()->ShowWindow( SW_HIDE );
	}
	// -----------------------------------------

	m_ClickedBtn = pClass;
	pClass->MySetStat( XEN_BTN_CLICK );
	pClass->SetChecked( true );
	pClass->Invalidate();
	if( pClass->GetActivePage() )
		pClass->GetActivePage()->ShowWindow( SW_SHOW );

	return TRUE;
}
//-------------------------------------------------------------------------------------------------------------