#include "stdafx.h"
#include "EditBox.h"


//-------------------------------------------------------------------------------------------------------------

IMPLEMENT_DYNAMIC(cXenEditBox, CEdit)

BEGIN_MESSAGE_MAP(cXenEditBox, CEdit)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_CONTROL_REFLECT(EN_SETFOCUS,   OnSetFocus)
	ON_CONTROL_REFLECT(EN_KILLFOCUS,  OnKillFocus)
	ON_CONTROL_REFLECT(EN_UPDATE, OnEditUpdate)
	ON_WM_SYSCOLORCHANGE()
	ON_MESSAGE(WM_MOUSELEAVE,OnMouseLeave)
END_MESSAGE_MAP()
//-------------------------------------------------------------------------------------------------------------

cXenEditBox::cXenEditBox()
{
	m_bHasFocus	= FALSE;
	m_Stat		= XEN_EDIT_ENABLE;
	m_style		= XEN_EDIT_DOTNET;
}
//-------------------------------------------------------------------------------------------------------------

cXenEditBox::~cXenEditBox()
{
}
//-------------------------------------------------------------------------------------------------------------

bool cXenEditBox::Create( DWORD dwStyle, RECT rect, CWnd *ParentWnd, unsigned int UID )
{
	m_This				= this;
	m_Owner				= ParentWnd;

	CEdit::Create( dwStyle, rect, ParentWnd, UID );

	return true;
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnMouseMove(UINT nFlags, CPoint point) 
{
	if( m_Stat == XEN_EDIT_ENABLE )
	{
		m_Stat = XEN_EDIT_OVER;
		Invalidate();
	}
	
	TRACKMOUSEEVENT t = { sizeof(TRACKMOUSEEVENT), TME_LEAVE, m_hWnd, 0 };
	TrackMouseEvent(&t);

	CEdit::OnMouseMove(nFlags, point);
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_Stat		= XEN_EDIT_CLICK;	
	CEdit::OnLButtonDown(nFlags, point);
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CRect rcItem;
	GetClientRect(&rcItem);

	if( m_bHasFocus )
	{
		m_Stat = XEN_EDIT_OVER;
		//Invalidate();
	}

	CEdit::OnLButtonUp(nFlags, point);
}
//-------------------------------------------------------------------------------------------------------------

HRESULT cXenEditBox::OnMouseLeave(WPARAM, LPARAM)
{	
	if ( !m_bHasFocus )
	{
		m_Stat	= XEN_EDIT_ENABLE;
		Invalidate();
		return 0;
	}
	else
	{
		m_Stat = XEN_EDIT_OVER;		 
	}
	return 0;
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnPaint() 
{
	//Default();
	CEdit::OnPaint();
	DrawEdit();
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::DrawEdit()
{
	CRect rcItem;
	GetClientRect(&rcItem);
	//GetWindowRect(&rcItem);
	CDC* pDC = GetDC();

	if( GetStyle() & ES_READONLY )
	{
		switch( m_style )
		{
		case XEN_EDIT_FLAT:
			pDC->Draw3dRect( &rcItem, m_clrBtnShadow, m_clrBtnHilite );
			break;
		case XEN_EDIT_DOTNET:
			pDC->Draw3dRect( &rcItem, m_clrBtnHighlight, m_clrBtnHighlight );
			break;
		case XEN_EDIT_3D:
			break;
		}
		// Patrick Added ------
		ReleaseDC(pDC);
		// --------------------
		return;
	}
	else
	{
		pDC->Draw3dRect(rcItem, m_clrBtnHilite, m_clrBtnHilite );
	}

	switch( m_style )
	{
	case XEN_EDIT_FLAT:
		break;
	case XEN_EDIT_DOTNET:
		break;
	case XEN_EDIT_3D:
		break;
	}

	switch( m_Stat )
	{
	case XEN_EDIT_DISABLE:
	break;
	case XEN_EDIT_ENABLE:
	break;
	case XEN_EDIT_CLICK:
	case XEN_EDIT_OVER:
		switch( m_style )
		{
		case XEN_EDIT_FLAT:
			pDC->Draw3dRect( &rcItem, m_clrBtnShadow, m_clrBtnHilite );
			break;
		case XEN_EDIT_DOTNET:
			pDC->Draw3dRect( &rcItem, m_clrBtnHighlight, m_clrBtnHighlight );
			break;
		case XEN_EDIT_3D:
			break;
		}
	break;
	}

	ReleaseDC(pDC);
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnSetFocus()
{
	/*
	if( GetStyle() & ES_READONLY )
	{
		((CWnd*)GetParent())->SetFocus();
	}
	*/

	m_bHasFocus = TRUE;
	m_Stat		= XEN_EDIT_CLICK;
	DrawEdit();
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnKillFocus() 
{
	m_bHasFocus = FALSE;
	m_Stat		= XEN_EDIT_ENABLE;
	DrawEdit();
}
//-------------------------------------------------------------------------------------------------------------

BOOL cXenEditBox::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_SYSCHAR)
		return TRUE;
		
	return CEdit::PreTranslateMessage(pMsg);
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnEditUpdate() 
{
	CString str;
	GetWindowText(str);
	int nLength = str.GetLength();
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::OnSysColorChange() 
{
	CEdit::OnSysColorChange();

	m_clrBtnHilite  = ::GetSysColor(COLOR_BTNHILIGHT);
	m_clrBtnShadow  = ::GetSysColor(COLOR_BTNSHADOW);
	m_clrBtnFace    = ::GetSysColor(COLOR_BTNFACE);
}
//-------------------------------------------------------------------------------------------------------------

HRESULT	cXenEditBox::Save( TCHAR *pFileName )
{
	CFile File( pFileName, CFile::modeCreate  | CFile::modeWrite  );

    int nLineCount = GetLineCount();
	
#ifdef _UNICODE
	USES_CONVERSION;
#endif
   
    for (int i=0;i < nLineCount;i++)
    {
		CString strLine;
		int len = LineLength( LineIndex(i) );
		
		GetLine( i, strLine.GetBuffer( len ), len );
		strLine.ReleaseBuffer(len);

#ifdef _UNICODE

		char *buf = new char[len*2+2];
		ZeroMemory( buf, len*2+2 );

		int pos = 0;

		for( int k=0; k<len; k++ )
		{
			char *cmp = (char*)&strLine.GetBuffer()[k];

			if( cmp[1] == NULL )
			{
				memcpy( &buf[pos], (char*)&strLine.GetBuffer()[k], 1 );
				pos++;
			}
			else
			{
				memcpy( &buf[pos], T2A(&strLine.GetBuffer()[k]), 2 );
				pos += 2;
			}
		}

		buf[pos++] = '\r';
		buf[pos++] = '\n';

		File.SeekToEnd();
		File.Write( buf, pos );

		delete []buf;

#else 
		File.Write( strLine.GetString(), len );
#endif

	}

	File.Close();

	return 0;
}
//-------------------------------------------------------------------------------------------------------------

HRESULT	cXenEditBox::LoadFromFile( TCHAR *pFileName )
{
	CFile File;
	
	if( !File.Open( pFileName, CFile::modeRead ) )
		return 1;

	char *buf = NULL;
	UINT size = (UINT)File.SeekToEnd();

#ifdef _UNICODE
	USES_CONVERSION;
#endif
   
	buf = new char[(UINT)size+1];

	ZeroMemory( buf, (UINT)size );

	if( !buf )
		return 2;
	
	File.SeekToBegin();
	File.Read( buf, (UINT)size );
	buf[size] = NULL;

	char buf1[2];

	buf1[0] = buf[1];
	buf1[1] = buf[0];

#ifdef _UNICODE
	AddLine( A2T(buf) );
#else 
	AddLine( buf );
#endif

	delete []buf;

	File.Close();

	return 0;
}
//-------------------------------------------------------------------------------------------------------------

int	cXenEditBox::AddLine( TCHAR *pStr )
{
	int end = LineIndex( GetLineCount() - 1 ) + LineLength(-1) ;

	CEdit::SetSel( end, -1 );
	ReplaceSel( pStr );

	return  GetLineCount();
}
//-------------------------------------------------------------------------------------------------------------

void cXenEditBox::Clear()
{
	CEdit::SetWindowText( _T("") );
}
//-------------------------------------------------------------------------------------------------------------