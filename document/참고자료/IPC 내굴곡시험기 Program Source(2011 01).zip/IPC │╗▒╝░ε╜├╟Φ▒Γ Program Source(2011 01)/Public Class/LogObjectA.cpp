
#include "stdafx.h"
#include "LogObjectA.h"
#include <time.h>

#ifdef	_UNICODE
#include "StringConversion.h"
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define __IOPORT_INNER_LOGMSG__	502348

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLogObject::CLogObject()
{
	m_hIOPORT = NULL; 
	m_hThread = NULL;
	m_IDThread = 0;
	m_long_StartFlag = 0;

	m_LogPath = _T("");
	m_Log_prefix = _T("");

	m_CurrentFileName.Empty();
	m_curpos = 0;
}

CLogObject::~CLogObject() {}

void CLogObject::Start(LPCTSTR logpath, LPCTSTR prefix)
{
	if(Get_StartFlag() == FALSE)
	{
		if(logpath && lstrlen(logpath) > 0)
		{
			m_LogPath = logpath;
			if(logpath[lstrlen(logpath) - 1] != '\\')		m_LogPath += (LPCTSTR)_T("\\");
		}
		else		m_LogPath = _T("C:\\");
		m_Log_prefix = prefix;
#ifndef	_WIN32_WINDOWS_ 
		m_hIOPORT = ::CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);	
#endif
		m_hThread = ::CreateThread(NULL, 0, CLogObject::LogInterface, this, 0, &m_IDThread);
	}
}

void CLogObject::Stop()
{
	if(Get_StartFlag() == TRUE && m_hThread)
	{
#ifdef	_WIN32_WINDOWS_ 
		::PostThreadMessage(m_IDThread, WM_IOPORT_NOTIFY, IOPORT_SHUTDOWN, NULL);
#else				
		::PostQueuedCompletionStatus(m_hIOPORT, 0, IOPORT_SHUTDOWN, NULL);	
#endif
	//	::WaitForSingleObject(m_hThread, 1000 * 3);
		::WaitForSingleObject(m_hThread, INFINITE);
		::CloseHandle(m_hThread);

#ifndef	_WIN32_WINDOWS_ 
		::CloseHandle(m_hIOPORT);
#endif

		m_hIOPORT = NULL;
		m_hThread = NULL;
		m_IDThread = 0;

		Set_StartFlag(FALSE);
	}
}

void CLogObject::LogHelper(short opcode, LPCTSTR plog)
{
	int length = 0;
	if(Get_StartFlag() && plog)
	{
		length = lstrlen(plog);
		if(length < 1)	return;

		if(length >= MAX_LOGSIZE) length = MAX_LOGSIZE - 1;
		if(opcode == 0 || opcode == 1 || opcode == 2)
		{
			if (m_curpos > MAX_LOGCOUNT-1) 
				m_curpos = 0;

			//__InnerLogParam__* pParam = new __InnerLogParam__;
			ZeroMemory(&InnerLogparam[m_curpos], sizeof(__InnerLogParam__));
			__InnerLogParam__* pParam = &InnerLogparam[m_curpos];
			if (pParam)
			{
				pParam->m_opcode = opcode;
				pParam->m_length = length;
				lstrcpyn(pParam->pLog, plog, length+1);
				//pParam->pLog[length] = NULL;

#ifdef	_WIN32_WINDOWS_ 
				::PostThreadMessage(m_IDThread, WM_IOPORT_NOTIFY, __IOPORT_INNER_LOGMSG__, (LPARAM)pParam);
#else
				::PostQueuedCompletionStatus(m_hIOPORT, sizeof(__InnerLogParam__), __IOPORT_INNER_LOGMSG__, (LPOVERLAPPED)pParam);
#endif
				m_curpos++;
			}
		}
	}
}

DWORD WINAPI CLogObject::LogInterface(LPVOID lp)
{
	HANDLE  hPort;
	CLogObject* Log = (CLogObject*)lp;

#ifdef	_WIN32_WINDOWS_ 
    MSG		Msg;
#else
	DWORD UserKey;
	DWORD NumberOfBytesTransferred;
	LPOVERLAPPED lpOverlapped;
#endif

	BOOL bContinue = TRUE;
	BOOL bStatus;
	TCHAR *pnewline = _T("\r\n");
	time_t currenttime;
	int saveday = 0;
	int flushlimit = 0;
	HANDLE hFile = NULL;
	TCHAR CurrentFileName[MAX_PATH];

	hPort = Log->Get_IOPORT();
	
	{
		struct tm* newtime = NULL;
		::time(&currenttime);
		newtime = localtime(&currenttime);
		saveday = newtime->tm_mday;

		LPSTR tempPath;

		TCHAR logPath[1024];
		lstrcpy(logPath, (LPCTSTR)Log->m_LogPath);

		while(tempPath = (LPSTR)strchr((LPCSTR)logPath, '/')) tempPath[0] = '\\';

		while(tempPath = (LPSTR)strchr((LPCSTR)logPath, '\\'))
		{
			tempPath[0] = NULL;
			::CreateDirectory(logPath, NULL);
			tempPath[0] = '/';
		}

		::CreateDirectory(Log->m_LogPath, NULL);
		::wsprintf(CurrentFileName, _T("%s%s_%04d%02d%02d.log"), 
							Log->m_LogPath.GetString(), Log->m_Log_prefix.GetString(), 
							(newtime->tm_year + 1900), (newtime->tm_mon + 1), newtime->tm_mday);
		Log->SetCurrentLogFileName(CurrentFileName);
	}
	hFile = ::CreateFile(CurrentFileName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	if(hFile != INVALID_HANDLE_VALUE)		::SetFilePointer(hFile, 0, NULL, (DWORD)FILE_END);
	else		
	{
		CString _FILENAME_(__FILE__);
		theApp.ErrorLog(_T("Cannot create LOGFILE [FI(%s),LI(%ld)][WIN32ERRCD(%lu)]"), _FILENAME_, __LINE__, ::GetLastError());
		return FALSE;
	}
	
	Log->Set_StartFlag(TRUE);
	while(bContinue)
	{
#ifdef	_WIN32_WINDOWS_ 
		bStatus = ::GetMessage(&Msg, NULL, 0, 0);
		if(bStatus == -1)
#else
		bStatus = GetQueuedCompletionStatus(hPort, &NumberOfBytesTransferred, &UserKey, &lpOverlapped, INFINITE);
		if(bStatus == FALSE)
#endif
		{
#ifdef	_WIN32_WINDOWS_ 
			bContinue = FALSE;
#else 
			if(lpOverlapped != NULL)	
			{
				theApp.Log(FALSE, _T("CLogObject::InterfaceThread GetQueuedCompletionStatus Error(%ld)"), GetLastError());
				//bContinue = FALSE;
			}
			else{ }
#endif
		}
		else
		{
#ifdef	_WIN32_WINDOWS_ 
			switch(Msg.wParam)
#else
			switch(UserKey)
#endif
			{
			case IOPORT_SHUTDOWN:
				bContinue = FALSE;
				break;

			case __IOPORT_INNER_LOGMSG__:
				{
					TCHAR timeprefix[100];
					TCHAR midstr[20];
					DWORD writen = 0;

					//LPTSTR pLogStr = NULL;
					__InnerLogParam__* pParam;
					int allocationsize = 0;
					{
						struct tm* newtime = NULL;
						::time(&currenttime);
						newtime = localtime(&currenttime);
						wsprintf(timeprefix, _T("%04d:%02d:%02d %02d:%02d:%02d->"), (newtime->tm_year + 1900), (newtime->tm_mon+1), 
							newtime->tm_mday, newtime->tm_hour, newtime->tm_min, newtime->tm_sec);
						if(saveday != newtime->tm_mday)
						{	
							if(hFile!= INVALID_HANDLE_VALUE)	::CloseHandle(hFile);
							::wsprintf(CurrentFileName, _T("%s%s_%04d%02d%02d.log"), Log->m_LogPath, Log->m_Log_prefix, (newtime->tm_year + 1900), (newtime->tm_mon + 1), newtime->tm_mday);
							Log->SetCurrentLogFileName(CurrentFileName);
							hFile = ::CreateFile(CurrentFileName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, NULL);
							if(hFile != INVALID_HANDLE_VALUE)	::SetFilePointer(hFile, 0, NULL, (DWORD)FILE_END);
							else	
							{
								CString _FILENAME_(__FILE__);
								theApp.ErrorLog(_T("Cannot create LOGFILE [FI(%s),LI(%ld)][WIN32ERRCD(%lu)]"), _FILENAME_, __LINE__, ::GetLastError());
							}
						}
						saveday = newtime->tm_mday;
					}
#ifdef	_WIN32_WINDOWS_ 
					pParam = (__InnerLogParam__*)Msg.lParam;
#else				
					pParam = (__InnerLogParam__*)lpOverlapped;
#endif
					if(pParam && hFile != INVALID_HANDLE_VALUE)
					{
						if(pParam->m_opcode == 0)	lstrcpy(midstr, _T("MSG : "));
						else if(pParam->m_opcode == 1)	lstrcpy(midstr, _T("ERROR : "));
						else lstrcpy(midstr, _T("WARNING : "));
						
						allocationsize = lstrlen(timeprefix);
						allocationsize += lstrlen(midstr);
						allocationsize += 2;	// CRLF
						allocationsize += pParam->m_length;

						if (allocationsize+2+1 < MAX_LOGSIZE)
						{ 
							CString sLogStr;
							sLogStr.Empty();
							sLogStr.Format(_T("%s%s%s%s"), timeprefix, midstr, pParam->pLog, pnewline);

#ifdef	_UNICODE
							CStringA szLog;
							szLog.Empty();
							szLog = StrToUtf8(sLogStr).GetString();
#else
							CString szLog(sLogStr);
#endif

							if(WriteFile(hFile, (LPCVOID)szLog.GetString(), szLog.GetLength(), &writen, NULL) == FALSE)
							{
								DWORD errstr = ::GetLastError();
							}

							if(flushlimit >= 10)
							{
								FlushFileBuffers(hFile);
								flushlimit = 0;
							}
							else	flushlimit++;


						}
					}
				}
				break;
			}
		}
#ifdef	_WIN32_WINDOWS_ 
		TranslateMessage(&Msg); 
		DispatchMessage(&Msg); 
#endif
	}
	
	FlushFileBuffers(hFile);
	if(hFile != INVALID_HANDLE_VALUE)	::CloseHandle(hFile);
	
	return 0;
}