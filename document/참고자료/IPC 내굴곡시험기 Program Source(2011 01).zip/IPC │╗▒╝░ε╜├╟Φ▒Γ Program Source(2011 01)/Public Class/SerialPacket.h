#ifndef __PACKET_DEFINE__
#define __PACKET_DEFINE__


#define ACCT_COM_PORT		1	
#define RMI_COM_PORT		2	

#define	FRAME_STX	 0xFF			
#define	FRAME_ETX	 0xFE			


enum ID_DEFINE_METHOD
{
	method_NONE = 0,

	method_BFTMD_SELECT_MT_IND	=	1,		
	method_BFTMD_SELECT_MT_CFM,				

	method_BFTMD_SRT_AMPTEST_IND,			
	method_BFTMD_SRT_AMPTEST_CFM,			

	method_BFTMD_AMP_DATA_REQ,				
	method_BFTMD_AMP_DATA_RES,				

	method_BFTMD_END_AMPTEST_IND,			
	method_BFTMD_END_AMPTEST_CFM,			
	
	method_BFTMD_MTTEST_IND,				
	method_BFTMD_MTTEST_CFM,				

	method_BFTMD_TEMP_DATA_REQ,				
	method_BFTMD_TEMP_DATA_RES,				

	method_BFTMD_READY_BFT_IND,				
	method_BFTMD_READY_BFT_CFM,				

	method_BFTMD_PARAM_INFO_IND,			
	method_BFTMD_PARAM_INFO_CFM,			

	method_BFTMD_SRT_BFT_IND,				
	method_BFTMD_SRT_BFT_CFM,				

	method_BFTMD_END_BFT_IND,				
	method_BFTMD_END_BFT_CFM,				

	method_BFTMD_PAUSE_BFT_IND,				
	method_BFTMD_PAUSE_BFT_CFM,				

};

struct _protocolHead
{
	byte		stx;				
	byte		paylodLen;			
	byte		messageID;			
};


#endif