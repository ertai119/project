#pragma once
#include "SerialComm.h"

#define __INNERP_SERIAL_WRAPPER				10011
#define __INNERP_SERIAL_SEND				10012
#define __INNERP_SERIAL_SETUPCONNECTION		10013
#define __INNERP_SERIAL_CLOSECONNECTION		10014

struct _SerialPacket 
{
	long			nSize;
	byte*			lpbuffer;
	short			nSend;
};


typedef std::map<short, _SerialPacket* >	SERIALPACKET_OBJECT;


class CSerialCommWrapper
{
	struct __InnerSerialWrapper__
	{
		__InnerSerialWrapper__() { ZeroMemory(this, sizeof(__InnerSerialWrapper__)); }
		~__InnerSerialWrapper__() { if(lpbuffer) delete[] lpbuffer; }

		TCHAR			dev[20];
		unsigned short	port;

		long			nSize;
		byte*			lpbuffer;
	};

public:
	CSerialCommWrapper(void);
	virtual ~CSerialCommWrapper(void);


	virtual BOOL Start(LPTTYSTRUCT lpTTY, LPCTSTR pDevName, DWORD timeout = INFINITE);
	virtual void Stop();

	virtual BOOL SendData(long nSize, byte* lpbuffer);
	virtual void CloseConnection();

	BOOL GetStartFlag() { return (m_long_StartFlag == 1) ? TRUE : FALSE; }

	HANDLE Get_IOPORT() { return m_hIOPORT; }
	HANDLE Get_hThread() { return m_hThread; }
	DWORD Get_IDThread() { return m_IDThread; }

	long IsConnection()	{ return bConnectFlag; }

	void SetConnectionInfo(LPTTYSTRUCT lpTTY);

	void SetConnection(BOOL flag)		{ ::InterlockedExchange(&bConnectFlag, (flag == TRUE ? 1 : 0)); }

	bool IsSerialPacket()				{ return (m_serialPacket.size())? true : false; }
	void AddSerialPacket(short id, long nSize, byte* lpbuffer);
	void RemoveSerialPacket(short id);
	void RemoveAllSerialPacket();
	BOOL SendSerialPacket();


protected:	
	HANDLE	m_hIOPORT;
	HANDLE	m_hThread;
	DWORD	m_IDThread;

	long	bConnectFlag;

	long	m_long_StartFlag;
	DWORD	m_TimeOut;

	TTYSTRUCT		m_TTYInfo;
	TCHAR			m_DevName[255];

	SERIALPACKET_OBJECT		m_serialPacket;
	short			m_sendCount;

protected:
	virtual BOOL Error(HRESULT code, CSerialComm& Connector) = 0;
	virtual void LogStr(BOOL eventviewerflag, LPCTSTR pFormat, ...) = 0;
	virtual void ErrorLogStr(LPCTSTR pFormat, ...) = 0;
	virtual void WarningLogStr(LPCTSTR pFormat, ...) = 0;

	virtual void TimeOutFunction(CSerialComm& Connector) = 0;

	virtual void OnStart(CSerialComm& Connector) = 0;
	virtual void OnConnect(TTYEvent* pEvent, CSerialComm& Connector) = 0;
	virtual void OnReceive(TTYEvent* pEvent, CSerialComm& Connector) = 0;
	virtual BOOL OnClose(TTYEvent* pEvent, CSerialComm& Connector) = 0;

	virtual void OnUnknownMsg(DWORD userkey, void* pParam, CSerialComm& Connector) = 0;

	virtual void ShutDownService() = 0;

	void SetStartFlag(BOOL flag)	{ ::InterlockedExchange(&m_long_StartFlag, (flag == TRUE ? 1 : 0));}

	static DWORD WINAPI InterfaceThread(LPVOID lpParameter);

};
