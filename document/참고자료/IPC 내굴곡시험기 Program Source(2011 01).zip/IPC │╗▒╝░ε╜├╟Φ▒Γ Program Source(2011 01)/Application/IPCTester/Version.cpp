#include "StdAfx.h"
#include "Version.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT CIPCTesterApp::m_nVersionMjr = VERSION_MJR;
const UINT CIPCTesterApp::m_nVersionMin = VERSION_MIN;
const UINT CIPCTesterApp::m_nVersionUpd = VERSION_UPDATE;
const UINT CIPCTesterApp::m_nVersionBld = VERSION_BUILD;
