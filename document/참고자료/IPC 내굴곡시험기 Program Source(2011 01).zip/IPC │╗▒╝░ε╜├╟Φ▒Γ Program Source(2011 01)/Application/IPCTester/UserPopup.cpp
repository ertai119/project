// UserPopup.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "UserPopup.h"


// CUserPopup ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CUserPopup, CDialog)

CUserPopup::CUserPopup(CWnd* pParent /*=NULL*/)
	: CDialog(CUserPopup::IDD, pParent)
	, m_stMessage(_T(""))
{
	m_clrText = PALETTERGB(0, 0, 0);
}

CUserPopup::~CUserPopup()
{
	m_fontMessage.DeleteObject();
}

void CUserPopup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CUserPopup::InitControl()
{
	CRect	rcTemp(0,0,0,0);

	// Set Font & Color
	//////////////////////////////////////////////////////////////////////////
	LOGFONT lf;
	CFont	*pFont, *pBoldFont;

	pFont = thePrefs.GetGUIDefault();

	pBoldFont = thePrefs.GetGUIDefaultBold();
	pFont->GetLogFont(&lf);

	// Create Font for Title Text
	//////////////////////////////////////////////////////////////////////////
	const int PointSize = 10;

	HDC hDC = ::GetDC(NULL);
	lf.lfHeight = -::MulDiv(PointSize, ::GetDeviceCaps(hDC, LOGPIXELSY), 72);
	//lf.lfWeight = FW_BOLD;

	m_fontMessage.CreateFontIndirect(&lf);

	// Main Windows Position
	CRect rcClient;
	GetClientRect(&rcClient);

	m_ctrlMessage.Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, rcTemp, this, IDC_STATIC_MESSAGE);
	m_ctrlMessage.SetAlign(DT_CENTER | DT_VCENTER /*| DT_SINGLELINE*/);
	m_ctrlMessage.SetTransparent();

	m_ctrlMessage.SetFont(&m_fontMessage);
	m_ctrlMessage.SetFontColor(m_clrText);
}

void CUserPopup::InitPos()
{
	if (m_ctrlMessage.m_hWnd)
	{
		int nCtrlWidth = 200;
		int	nCtrlHeight = 90;

		CRect	rcClient, rcTemp(0, 0, 0, 0);
		int		nCtrlIntv = 30, nLineIntv = 10;

		GetClientRect(&rcClient);

		// Set Message Pos
		/////////////////////////////////////////////////////////
		rcTemp.left		= IPC_USERPOPUP_TOP;
		rcTemp.right	= rcClient.right - IPC_USERPOPUP_LEFT;
		rcTemp.top		= IPC_USERPOPUP_TOP;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;

		m_ctrlMessage.MoveWindow(&rcTemp, FALSE);
		m_ctrlMessage.SetCaption(_T(""));
		if(!m_stMessage.IsEmpty())
			m_ctrlMessage.SetCaption(m_stMessage);

		m_ctrlMessage.ShowWindow( SW_SHOW );
	}
}

BEGIN_MESSAGE_MAP(CUserPopup, CDialog)
	ON_WM_CLOSE()
	ON_WM_CREATE()
END_MESSAGE_MAP()


// CUserPopup �޽��� ó�����Դϴ�.
void CUserPopup::OnOK()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	CWnd*	pMainWnd = theApp.GetMainWnd();
	if(pMainWnd)
		::PostMessage(pMainWnd->m_hWnd, UM_IPC_USERDIALOG_OK, 0, 0);

	CDialog::OnOK();
}

void CUserPopup::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CWnd*	pMainWnd = theApp.GetMainWnd();
	if(pMainWnd)
		::PostMessage(pMainWnd->m_hWnd, UM_IPC_USERDIALOG_OK, 0, 0);

	CDialog::OnClose();
}

int CUserPopup::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  ���⿡ Ư��ȭ�� �ۼ� �ڵ带 �߰��մϴ�.
	InitControl();
	InitPos();

	return 0;
}
