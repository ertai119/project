// IPCLoad.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "IPCLoad.h"


// CIPCLoad ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CIPCLoad, CDialog)

CIPCLoad::CIPCLoad(CWnd* pParent /*=NULL*/)
	: CDialog(CIPCLoad::IDD, pParent)
{
	m_clrText = PALETTERGB(0, 0, 255);		// blue
	m_limitText = PALETTERGB(255, 0, 0);	// Red
	m_curTotalCount = 0;
}

CIPCLoad::~CIPCLoad()
{
}

void CIPCLoad::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CIPCLoad::InitControl()
{
	CRect	rcTemp(0,0,0,0);

	// Set Font & Color
	//////////////////////////////////////////////////////////////////////////
	LOGFONT lf;
	CFont	*pFont, *pBoldFont;

	pFont = thePrefs.GetGUIDefault();
	pFont->GetLogFont(&lf);

	pBoldFont = thePrefs.GetGUIDefaultBold();

	// Main Windows Position
	CRect rcClient;
	GetClientRect(&rcClient);

	m_stBFTotal.Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, rcTemp, this);
	m_stBFTotal.SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	m_stBFTotal.SetTransparent();

	for(int i = 0; i < 2; i++)
	{
		m_stIPCLoad[i].Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, rcTemp, this);
		m_stIPCLoad[i].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		m_stIPCLoad[i].SetTransparent();
	}

	m_btnOK.SetImageList(theResMan.GetImageListRes(IPC_RESMAN_BTN_OK), 0);
	m_btnOK.Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
					rcTemp, this, IDOK);	
	m_btnOK.SetTransparent();

	m_stBFTotal.SetFont(pBoldFont);
	m_stBFTotal.SetFontColor(m_clrText);

	m_stIPCLoad[0].SetFont(pFont);
	m_stIPCLoad[1].SetFont(pBoldFont);
	m_stIPCLoad[1].SetFontColor(m_limitText);

	//::ReleaseDC(NULL, hDC);

	SetWindowText(GetResString(IDS_IPC_LOAD_CAPTION));
}

void CIPCLoad::InitPos()
{
	if (m_stIPCLoad[0].m_hWnd && m_stBFTotal.m_hWnd && m_btnOK.m_hWnd)
	{
		int nCtrlWidth = 200;
		int	nCtrlHeight = 20;

		CRect	rect, rcTemp(0,0,0,0);
		int		nCtrlIntv=4, nLineIntv=4, nOffSet=10;

		GetClientRect(&rect);

		rcTemp.left		= nOffSet;
		rcTemp.right	= rcTemp.left + nCtrlWidth;
		rcTemp.top		= nOffSet;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;

		m_stIPCLoad[0].MoveWindow(&rcTemp, FALSE);
		m_stIPCLoad[0].SetCaption(GetResString(IDS_IPC_CURRENT_BFCOUNT));
		m_stIPCLoad[0].ShowWindow( SW_SHOW );


		rcTemp.left = rcTemp.right + 5;
		rcTemp.right = rect.right - nOffSet;

		m_stBFTotal.MoveWindow(&rcTemp, FALSE);

		CString strCount = theApp.ConvertStrValue(m_curTotalCount);
		m_stBFTotal.SetCaption(strCount);
		m_stBFTotal.ShowWindow( SW_SHOW );

		rcTemp.left		= nOffSet;
		rcTemp.right	= rect.right - nOffSet;
		rcTemp.top		= rcTemp.bottom + 10;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;

		m_stIPCLoad[1].MoveWindow(&rcTemp, FALSE);
		m_stIPCLoad[1].SetCaption(GetResString(IDS_IPC_LIMIT_BFCOUNT));
		m_stIPCLoad[1].ShowWindow( SW_SHOW );

		CRect	rcImg;
		IMAGEINFO	ImgInfo;
		CImageList* pImgList = theResMan.GetImageListRes(IPC_RESMAN_BTN_OK);
		pImgList->GetImageInfo(0, &ImgInfo);
		rcImg = ImgInfo.rcImage;

		int nLeft = (rect.Width() - rcImg.Width()) / 2;

		rcTemp.bottom	= rect.bottom - nOffSet;
		rcTemp.top		= rcTemp.bottom - rcImg.Height();
		rcTemp.left		= nLeft;
		rcTemp.right = rcTemp.left + rcImg.Width();

		m_btnOK.MoveWindow(&rcTemp, FALSE);
		m_btnOK.ShowWindow( SW_SHOW );
	}
}

BEGIN_MESSAGE_MAP(CIPCLoad, CDialog)
	ON_WM_NCACTIVATE()
END_MESSAGE_MAP()


// CIPCLoad �޽��� ó�����Դϴ�.

BOOL CIPCLoad::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	InitControl();

	HDC hDC		  = ::GetDC( ::GetDesktopWindow() );
	int	scrWidth  = ::GetDeviceCaps(hDC,HORZRES);
	int scrHeight = ::GetDeviceCaps(hDC,VERTRES);
	::ReleaseDC( ::GetDesktopWindow(), hDC );
	
	CRect rcClient;
	GetClientRect(&rcClient);

	MoveWindow(scrWidth/2 - rcClient.Width()/2, scrHeight/2 - rcClient.Height()/2, 
				rcClient.Width(), rcClient.Height());

	InitPos();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BOOL CIPCLoad::OnNcActivate(BOOL bActive)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CRect rcLoad;
	GetWindowRect(&rcLoad);

	SetWindowPos(&CWnd::wndTopMost, rcLoad.left, rcLoad.top, rcLoad.Width(), rcLoad.Height(), 0);
	SetForegroundWindow();
	BringWindowToTop();

	return CDialog::OnNcActivate(bActive);
}
