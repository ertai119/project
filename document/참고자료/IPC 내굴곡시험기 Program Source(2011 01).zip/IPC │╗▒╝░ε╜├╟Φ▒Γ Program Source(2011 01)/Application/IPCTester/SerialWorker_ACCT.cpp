#include "StdAfx.h"
#include "SerialWorker_ACCT.h"

CSerialWorker_ACCT::CSerialWorker_ACCT(void)
{
	m_ConnectionFlag = 0;
	m_status = ACCTSTATUS_NONE;

	m_pSaveBuffer = NULL;
	ClearVariable(TRUE);
}

CSerialWorker_ACCT::~CSerialWorker_ACCT(void) 
{
}

BOOL CSerialWorker_ACCT::Error(HRESULT code, CSerialComm& Connector)
{
	AtlTrace("SerialComm Error!! Please Check!!");

	long ret = 0;
	CString Description;
	BOOL retval = TRUE;

	CWnd*	pMainWnd = theApp.GetMainWnd();
	if(pMainWnd == NULL)
		return retval;

	UINT	idMessage = 0;

	if(code == TTY_ERROR_12)	
		idMessage = IDS_TTY_ERROR_CONNECTION;
	else if(code == TTY_ERROR_8)	
		idMessage = IDS_TTY_ERROR_CONNECTION_CLOSE;
	else if(code == TTY_ERROR_9)	
		idMessage = IDS_TTY_ERROR_SEND_DATA;

	if(idMessage)
	{
		struct tm* ctime = NULL;
		time_t	ti;
		time(&ti);
		ctime = localtime(&ti);

		CString strMessage;
		strMessage.Format(_T("%s\r\n\r\n(%4d/%02d/%02d %02d:%02d:%02d)"), 
						GetResString(idMessage),
						ctime->tm_year + 1900, ctime->tm_mon + 1, ctime->tm_mday,
						ctime->tm_hour, ctime->tm_min, ctime->tm_sec);

		TCHAR*	pParam = (LPTSTR) new TCHAR[strMessage.GetLength() + 1];
		if(pParam)
		{
			lstrcpy(pParam, strMessage);
			::PostMessage(pMainWnd->m_hWnd, UM_IPC_USERDIALOG, 0, (LPARAM)pParam);
		}
	}

	return retval;	
}

void CSerialWorker_ACCT::LogStr(BOOL eventviewerflag, LPCTSTR pFormat, ...)
{
	LPTSTR pLog = NULL;
	int argumentcount = 0;
	va_list pArg;

	va_start(pArg, pFormat);
	argumentcount = theApp.Count_argumentlists(pFormat, pArg);
	if(argumentcount == 0)
	{
		va_end(pArg);	
		return;
	}
	pLog = new TCHAR[argumentcount+1];
	wvsprintf(pLog, pFormat, pArg);
	va_end(pArg);

	theApp.Log(eventviewerflag, pLog);
	delete[] pLog;
}

void CSerialWorker_ACCT::ErrorLogStr(LPCTSTR pFormat, ...)
{
	LPTSTR pLog = NULL;
	int argumentcount = 0;
	va_list pArg;
	
	va_start(pArg, pFormat);
	argumentcount = theApp.Count_argumentlists(pFormat, pArg);
	if(argumentcount == 0)
	{
		va_end(pArg);	
		return;
	}
	pLog = new TCHAR[argumentcount+1];
	wvsprintf(pLog, pFormat, pArg);
	va_end(pArg);
	
	theApp.ErrorLog(pLog);
	delete[] pLog;
}

void CSerialWorker_ACCT::WarningLogStr(LPCTSTR pFormat, ...)
{
	LPTSTR pLog = NULL;
	int argumentcount = 0;
	va_list pArg;
	
	va_start(pArg, pFormat);
	argumentcount = theApp.Count_argumentlists(pFormat, pArg);
	if(argumentcount == 0)
	{
		va_end(pArg);	
		return;
	}
	pLog = new TCHAR[argumentcount+1];
	wvsprintf(pLog, pFormat, pArg);
	va_end(pArg);
	
	theApp.WarningLog(pLog);
	delete[] pLog;
}

void CSerialWorker_ACCT::TimeOutFunction(CSerialComm& Connector)
{	
	AtlTrace(_T("CSerialWorker_ACCT::TimeOutFunction called\n"));

	if(IsSerialPacket())
	{
		BOOL ret = SendSerialPacket();
		if(ret == FALSE)
		{
			CWnd*	pMainWnd = theApp.GetMainWnd();
			if(pMainWnd)
			{
				struct tm* ctime = NULL;
				time_t	ti;
				time(&ti);
				ctime = localtime(&ti);

				CString strMessage;
				strMessage.Format(_T("��Ż� ������ �����Ǿ����ϴ�!\r\n\r\nSerial ���ӻ��¸� Ȯ�ιٶ��ϴ�.\r\n\r\n(%4d/%02d/%02d %02d:%02d:%02d)"), 
								ctime->tm_year + 1900, ctime->tm_mon + 1, ctime->tm_mday,
								ctime->tm_hour, ctime->tm_min, ctime->tm_sec);

				TCHAR*	pParam = (LPTSTR) new TCHAR[strMessage.GetLength() + 1];
				if(pParam)
				{
					lstrcpy(pParam, strMessage);
					::PostMessage(pMainWnd->m_hWnd, UM_IPC_USERDIALOG, 0, (LPARAM)pParam);
				}
			}
		}
	}
}

void CSerialWorker_ACCT::ShutDownService()
{	
	AtlTrace("ShutDown!! Please Check!!");
}

void CSerialWorker_ACCT::OnUnknownMsg(DWORD userkey, void* pParam, CSerialComm& Connector)
{
	switch(userkey)
	{
		case __INNERP_ACCT_SELECT_MT__ :			
		{
			WORKINFO_INDICATION*	pInfo = (WORKINFO_INDICATION*)pParam;
			if(pInfo)
			{
				SelectMTRequest(pInfo->m_mtNum);
				delete pInfo;
			}
			break;
		}

		default :
			break;
	}
}

void CSerialWorker_ACCT::ClearVariable(BOOL callingflag/* = FALSE*/)
{
	m_connecttime = m_last_rcvtime = m_last_sndtime = 0;
	m_requiredNext = FALSE;
	m_SavedMethod = method_NONE;
	m_ReceivedSize = 0;
	m_RequiredReceiveSize = 0;
	if(callingflag == false)	delete[] m_pSaveBuffer;
	m_pSaveBuffer = NULL;
}

void CSerialWorker_ACCT::OnStart(CSerialComm& Connector)
{
	AtlTrace(_T("CSerialWorker_ACCT::OnStart called\n"));
}

void CSerialWorker_ACCT::OnConnect(TTYEvent*pEvent, CSerialComm& Connector)
{	
	AtlTrace("CSerialWorker_ACCT::OnConnect\n");
	::InterlockedExchange(&m_ConnectionFlag, 1);

#ifdef _DEBUG
	CString comdev(pEvent->commdev);
	theApp.Log(TRUE, _T("OnConnect Event from ACCT SerialComm [(%s)]"), comdev.GetString());
#endif
}

BOOL CSerialWorker_ACCT::OnClose(TTYEvent* pEvent, CSerialComm& Connector)
{	
	ClearVariable();
	::InterlockedExchange(&m_ConnectionFlag, 0);
	if(pEvent) 
	{
#ifdef _DEBUG
		CString commdev(pEvent->commdev);
		theApp.WarningLog(_T("OnClose Event From ACCT SerialComm [(%s)]"), commdev);
#endif
	}

	return FALSE;
}

void CSerialWorker_ACCT::OnReceive(TTYEvent* pEvent, CSerialComm& Connector)
{
	_protocolHead* pbasic = NULL;
	unsigned long size = 0;	
	unsigned long nSize = 0;
	LPCSTR	pBuffer = NULL;
	BOOL	bRet = TRUE;

#ifdef	_IPC_SIMULATOR_
	char strMsg[1024];
	strcpy(strMsg, "  RECV=");

	for(int i = 0; i < (int)pEvent->datasize; i++)
		sprintf(strMsg, _T("%s0x%02X "), strMsg, pEvent->pdata[i]);

//	TRACE(strMsg);
	LogStr(1, strMsg);
#endif

	byte* lpBuffer		= pEvent->pdata;
	unsigned long lLen	= pEvent->datasize;

	if(m_requiredNext == REQUIRED_NONE)
	{
		if(lLen >= sizeof(_protocolHead))
		{
			bRet = PacketParsing(pEvent, lpBuffer, lLen, Connector);
		}
		else		
		{
			m_requiredNext = REQUIRED_HEADER;		
			m_pSaveBuffer = new byte[sizeof(_protocolHead)];
			m_RequiredReceiveSize = sizeof(_protocolHead);
			m_ReceivedSize = lLen;
			if(m_pSaveBuffer) 
			{
				ZeroMemory(m_pSaveBuffer, sizeof(_protocolHead));
				CopyMemory(m_pSaveBuffer, lpBuffer, m_ReceivedSize);
			}
		}
	}
	else	
	{
		if(lLen >= (m_RequiredReceiveSize - m_ReceivedSize))
		{	
			unsigned long m_CurrentRecvSize = m_RequiredReceiveSize - m_ReceivedSize;
	
			CopyMemory(&(m_pSaveBuffer[m_ReceivedSize]), lpBuffer, m_CurrentRecvSize);
			m_ReceivedSize += m_CurrentRecvSize;

			if(m_requiredNext == REQUIRED_HEADER)	
			{
				long size = sizeof(_protocolHead) + lLen - m_CurrentRecvSize;
				byte* temp = new byte[size];
				if(temp)
				{
					CopyMemory(temp, m_pSaveBuffer, sizeof(_protocolHead));
					CopyMemory(temp + sizeof(_protocolHead), lpBuffer + m_CurrentRecvSize, lLen - m_CurrentRecvSize);
				}

				ClearVariable();

				bRet = PacketParsing(pEvent, temp, size, Connector);
				if(temp) delete[] temp;
			}
			else		
			{
				pbasic = (_protocolHead*)m_pSaveBuffer;

				short etxpos = sizeof(_protocolHead) + pbasic->paylodLen;
				if(pbasic->stx == FRAME_STX && m_pSaveBuffer[etxpos - 1] == FRAME_ETX)
				{
					pBuffer = (LPCSTR)&(m_pSaveBuffer[sizeof(_protocolHead)]);						
					bRet = MethodParsing(m_SavedMethod, pBuffer, pbasic->paylodLen, pEvent, Connector);
				}

				ClearVariable();

				if(lLen > m_CurrentRecvSize)
					bRet = PacketParsing(pEvent, &lpBuffer[m_CurrentRecvSize], lLen - m_CurrentRecvSize, Connector);
			}
		}
		else		
		{
			CopyMemory(&(m_pSaveBuffer[m_ReceivedSize]), lpBuffer, lLen);
			m_ReceivedSize += lLen;
		}
	}
}

BOOL CSerialWorker_ACCT::PacketParsing(TTYEvent* pEvent, byte *lpBuffer, long lLen, CSerialComm& Connector)
{
	long size = 0;
	_protocolHead* pbasic = NULL;
	LPCSTR pBuffer = NULL;

	if(lLen >= sizeof(_protocolHead))	
	{
		pbasic = (_protocolHead*)lpBuffer;

		if(pbasic->stx != FRAME_STX)
			return FALSE;

		size = sizeof(_protocolHead) + pbasic->paylodLen;

		if(lLen >= size)		
		{
			if(lpBuffer[size - 1] == FRAME_ETX)
			{
				pBuffer = (LPCSTR)&(lpBuffer[sizeof(_protocolHead)]);	
				MethodParsing(pbasic->messageID, pBuffer, pbasic->paylodLen, pEvent, Connector);
			}

			if(lLen > size)		
				PacketParsing(pEvent, &lpBuffer[size], lLen - size, Connector);
		}
		else 
		{
			m_requiredNext = REQUIRED_BODY;			
			m_SavedMethod = pbasic->messageID;
			m_pSaveBuffer = new byte[size];
			m_RequiredReceiveSize = size;

			m_ReceivedSize = lLen;
			if(m_pSaveBuffer) 
			{
				ZeroMemory(m_pSaveBuffer, size);
				CopyMemory(m_pSaveBuffer, lpBuffer, m_ReceivedSize);
			}
		}
	}
	else
	{
		m_requiredNext = REQUIRED_HEADER;		
		m_pSaveBuffer = new byte[sizeof(_protocolHead)];
		m_RequiredReceiveSize = sizeof(_protocolHead);
		m_ReceivedSize = lLen;
		if(m_pSaveBuffer) 
		{
			ZeroMemory(m_pSaveBuffer, sizeof(_protocolHead));
			CopyMemory(m_pSaveBuffer, lpBuffer, m_ReceivedSize);
		}
	}

	return TRUE;
}

BOOL CSerialWorker_ACCT::MethodParsing(int methodid, LPCSTR pBuffer, int addsize, TTYEvent* pEvent, CSerialComm& Connector)
{
														
	if(methodid == method_BFTMD_MTTEST_CFM				|| 	
	   methodid == method_BFTMD_SELECT_MT_CFM)				
	{
		MaterialTPreTest(pBuffer, addsize, methodid, Connector);
	}													
	else if(methodid == method_BFTMD_SRT_AMPTEST_CFM	||	
			methodid == method_BFTMD_AMP_DATA_RES		||	
			methodid == method_BFTMD_END_AMPTEST_CFM)		
	{
		AmplitudeAdjustTest(pBuffer, addsize, methodid, Connector);
	}													
	else if(methodid == method_BFTMD_PARAM_INFO_CFM		||	
			methodid == method_BFTMD_READY_BFT_CFM		||	
			methodid == method_BFTMD_TEMP_DATA_RES		||	
			methodid == method_BFTMD_SRT_BFT_CFM		||	
			methodid == method_BFTMD_PAUSE_BFT_CFM		||	
			methodid == method_BFTMD_END_BFT_CFM)			
	{
			BendingFatigueTest(pBuffer, addsize, methodid, Connector);
	}
	else	
	{
		theApp.ErrorLog(_T("CSerialWorker_ACCT::Unknown Method(%d) [SIZE(%lu)]"), methodid, addsize);
		return FALSE;
	}

	RemoveAllSerialPacket();

	return TRUE;
}

BOOL CSerialWorker_ACCT::SelectMTRequest(short mtNum)
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_SELECT_MT_IND;	
	basic.paylodLen = 2;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	lpbuffer[sizeof(_protocolHead)] = 0x30 + mtNum;
	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::StartAmpTest(short amp, int m_bendingSpeed)
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_SRT_AMPTEST_IND;	
	basic.paylodLen = 1 + 2 + 4;					

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));

	char	str[10];
	sprintf(str, "%02d", amp);
	::CopyMemory(&lpbuffer[sizeof(_protocolHead)], str, 2);
	sprintf(str, "%04d", m_bendingSpeed);
	::CopyMemory(&lpbuffer[sizeof(_protocolHead) + 2], str, 4);

	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::AmpDataRequest()
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_AMP_DATA_REQ;	
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));

	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::EndAmpTest()
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_END_AMPTEST_IND;	
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));

	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::MTPreTest()
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_MTTEST_IND;		
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::TempDataRequest()
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_TEMP_DATA_REQ;	
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::ReadyBFT()
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_READY_BFT_IND;	
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::SetParamInfo(void* pParam)
{
	WORKINFO_INDICATION* pWork = (WORKINFO_INDICATION*)pParam;
	if(pWork == NULL) return FALSE;

	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_PARAM_INFO_IND;	
	basic.paylodLen = 1 + 4 + 2 + 4 + 1 + 3;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	::memset(&lpbuffer[sizeof(_protocolHead)], 0x30, 4);	
	for(int i = 0; i < 4; i++)								
	{
		if(pWork->m_mtInfo[i])
			lpbuffer[sizeof(_protocolHead) + i] = 0x31;		
	}
	char	str[10];
	sprintf(str, "%02d", pWork->m_amplitude);				
	::CopyMemory(&lpbuffer[sizeof(_protocolHead) + 4], str, 2);
	sprintf(str, "%04d", pWork->m_bendingSpeed);			
	::CopyMemory(&lpbuffer[sizeof(_protocolHead) + 6], str,4);
	lpbuffer[sizeof(_protocolHead) + 10] = 0x30 + pWork->m_autoStart;	
	sprintf(str, "%03d", pWork->m_temp);					
	::CopyMemory(&lpbuffer[sizeof(_protocolHead) + 11], str,3);

	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::StartBFTRequest()
{
		_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_SRT_BFT_IND;		
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

BOOL CSerialWorker_ACCT::PauseBFTRequest()
{
		_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_PAUSE_BFT_IND;	
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}


BOOL CSerialWorker_ACCT::EndBFTRequest()
{
	_protocolHead	basic;
	byte* lpbuffer = NULL;
	int pos = sizeof(_protocolHead);
	unsigned long nSize = 0;
	nSize = sizeof(_protocolHead);

	::ZeroMemory(&basic, sizeof(_protocolHead));
	basic.stx = FRAME_STX;
	basic.messageID = method_BFTMD_END_BFT_IND;		
	basic.paylodLen = 1;							

	nSize += basic.paylodLen;

	lpbuffer = new byte[nSize];
	::ZeroMemory(lpbuffer, nSize);

	::CopyMemory(lpbuffer, &basic, sizeof(_protocolHead));
	lpbuffer[nSize - 1] = FRAME_ETX;

	BOOL nResult = SendData(nSize, lpbuffer);
	if(nResult)
		AddSerialPacket(basic.messageID, nSize, lpbuffer);
	delete[] lpbuffer;

	return nResult;
}

void CSerialWorker_ACCT::MaterialTPreTest(LPCSTR pBuffer, int addsize, int methodid, CSerialComm& Connector)
{
	HRESULT result = pBuffer[0] - 0x30;

	if(methodid == method_BFTMD_MTTEST_CFM) 	
	{
		::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_CONFIRM, result);
	}
	else if(methodid == method_BFTMD_SELECT_MT_CFM)	
	{
		short reason = pBuffer[1] - 0x30;	
#ifndef	_IPC_TEST_
		if(reason == 0)	
			::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_INITIALIZE_CONFIRM, result);
		else
#endif
			::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_SELECT_CONFIRM, result);
	}
}

void CSerialWorker_ACCT::AmplitudeAdjustTest(LPCSTR pBuffer, int addsize, int methodid, CSerialComm& Connector)
{
	if(methodid == method_BFTMD_SRT_AMPTEST_CFM)	
	{
		HRESULT result = pBuffer[0] - 0x30;

		::PostMessage(m_hWnd, UM_IPC_AMPTEST, ID_IPC_AMPTEST_START_CONFIRM, result);
	}
	else if(methodid == method_BFTMD_AMP_DATA_RES)	
	{
		char strVal[5];
		::ZeroMemory(strVal, 5);
		strncpy(strVal, pBuffer, 2);	
		strVal[2] = '.';
		strVal[3] = pBuffer[2];

		::SendMessage(m_hWnd, UM_IPC_AMPTEST, ID_IPC_AMPTEST_DATA, (LPARAM)strVal);
	}
	else if(methodid == method_BFTMD_END_AMPTEST_CFM)		
	{
		HRESULT result = pBuffer[0] - 0x30;
		::PostMessage(m_hWnd, UM_IPC_AMPTEST, ID_IPC_AMPTEST_END_CONFIRM, result);
	}
}

void CSerialWorker_ACCT::BendingFatigueTest(LPCSTR pBuffer, int addsize, int methodid, CSerialComm& Connector)
{
	if(	methodid == method_BFTMD_PARAM_INFO_CFM		||	
		methodid == method_BFTMD_READY_BFT_CFM		||	
		methodid == method_BFTMD_SRT_BFT_CFM		||	
		methodid == method_BFTMD_PAUSE_BFT_CFM		||	
		methodid == method_BFTMD_END_BFT_CFM)			
	{
		HRESULT result = pBuffer[0] - 0x30;

		if(methodid == method_BFTMD_PARAM_INFO_CFM)
			::PostMessage(m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_PARAM_CONFIRM, result);
		else if(methodid == method_BFTMD_READY_BFT_CFM)
			::PostMessage(m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_READY_CONFIRM, result);
		else if(methodid == method_BFTMD_SRT_BFT_CFM)
			::PostMessage(m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_START_CONFIRM, result);
		else if(methodid == method_BFTMD_PAUSE_BFT_CFM)
			::PostMessage(m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_PAUSE_CONFIRM, result);
		else if(methodid == method_BFTMD_END_BFT_CFM)
			::PostMessage(m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_END_CONFIRM, result);
	}
	else if(methodid == method_BFTMD_TEMP_DATA_RES) 
	{
		char strVal[10];
		::ZeroMemory(strVal, 10);
		strncpy(strVal, pBuffer, 3);	
		strVal[3] = '.';
		strVal[4] = pBuffer[3];			

		CIPCTesterDlg*	pDlg = (CIPCTesterDlg*)theApp.GetMainWnd();
		if(pDlg)
		{
			CWnd* pWnd = pDlg->GetStatusWindow();
			if(pWnd)
				::SendMessage(pWnd->m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_TEMPDATA, (LPARAM)strVal);
			else
				::SendMessage(m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_TEMPDATA, (LPARAM)strVal);
		}
	}


}

