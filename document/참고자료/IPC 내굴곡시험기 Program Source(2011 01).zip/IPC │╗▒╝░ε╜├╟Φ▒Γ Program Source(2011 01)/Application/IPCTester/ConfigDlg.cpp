// ConfigDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "ConfigDlg.h"

#include "Preferences.h"
#include "FolderDialog.h"
#include "AmplitudeDlg.h"

// CConfigDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CConfigDlg, CDialog)

CConfigDlg::CConfigDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConfigDlg::IDD, pParent)
{
	//Initialize CheckBox Infos
	for (int i = 0; i < EN_CHECK_MAX; i++)
		m_bCheckInfo[i] = FALSE;

	//Initial Boolean Variables
	m_bInitConfig = FALSE;
	m_bAutoStart = true;
	bDisable = FALSE;

	m_clrBack		= IPC_BACKGROUND_COLOR;
	m_clrText		= PALETTERGB(0,0,0);			// BLACK
	m_clrValue		= PALETTERGB(255, 0, 0);		// RED
	m_clrMask		= PALETTERGB(255,0,255);		// PINK
}

CConfigDlg::~CConfigDlg()
{
	m_ImgConfig.DeleteImageList();
//	chkFont.DeleteObject();
}

void CConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	for(int i = EN_EDIT_TEMP; i < EN_EDIT_MAX; i++)
	{
		DDX_Control(pDX, IDC_CONFIG_EDIT_TEMP + i, m_editConfig[i]);
		if(i < EN_SPIN_MAX)
			DDX_Control(pDX, IDC_CONFIG_SPIN_TEMP + i, m_spinConfig[i]);
	}

	for(int i = EN_EDIT_TEMP; i < (EN_SPIN_MAX - 1); i++)
		DDX_Text(pDX, IDC_CONFIG_EDIT_TEMP + i, m_iRange[i]);

	DDX_Text(pDX, IDC_CONFIG_EDIT_INTERVAL, m_fInterval);
	DDX_Text(pDX, IDC_CONFIG_EDIT_TESTCOUNT, m_iStopCount);

	for(int i = EN_EDIT_S1; i < EN_EDIT_MAX; i++)
		DDX_Text(pDX, IDC_CONFIG_EDIT_TEMP + i, m_strEdit[i]);

	for(int i = EN_CHECK_S1; i < EN_CHECK_MAX; i++)
		DDX_Check(pDX, IDC_CONFIG_CHECK_S1 + i, m_bCheckInfo[i]);
}


void CConfigDlg::Localize()
{
	// Set Preference Dialog Caption
	SetWindowText(GetResString(IDS_PREF_DLG_CAPTION));

	CString strPath;
	strPath.Format(_T("%s"), thePrefs.m_folderPath);
	m_stConfig[EN_STATIC_FOLDER].SetCaption(strPath);
	m_ToolTipCtrl.UpdateTipText(strPath, (CWnd *)&m_stConfig[EN_STATIC_FOLDER]);

}

void CConfigDlg::LocalizeFont()
{
	CFont *pFont = thePrefs.GetGUIDefault();
	CFont*	m_fontBold = thePrefs.GetGUIDefaultBold();

	// Set Font Info to EditBox 
	for(int  i= 0; i < EN_EDIT_MAX; i++)
		m_editConfig[i].SetFont(pFont);		

	for (int i = 0; i < EN_STATIC_MAX; i++)
		m_stConfig[i].SetFont(pFont);	
}

void CConfigDlg::InitConfig()
{
	// Preference Value Setting
	//////////////////////////////////
	for(int i = 0; i < (EN_CHECK_MAX - 1); i++)
		m_bCheckInfo[i] = thePrefs.m_materialInfo[i];
	m_bCheckInfo[EN_CHECK_USED] = thePrefs.m_bUsed;

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		m_fResistance[i] = 0.0f;

	m_iRange[EN_EDIT_TEMP]		= thePrefs.m_temp;
	m_iRange[EN_EDIT_ALLOWABLE] = thePrefs.m_allowable;
	m_iRange[EN_EDIT_BENDING]	= thePrefs.m_bendingSpeed;
	m_iRange[EN_EDIT_AMP]		= thePrefs.m_amplitude;
	m_iRange[EN_EDIT_FAIL]		= thePrefs.m_failPercent;

	m_fInterval		= thePrefs.m_interval;
	m_iStopCount	= thePrefs.m_stopCount;
	m_bAutoStart	= thePrefs.m_bAutoStart;

	for(int i = EN_EDIT_S1; i < (EN_EDIT_MAX - 1); i++)
		m_strEdit[i] = thePrefs.m_materialName[i - EN_EDIT_S1];
	m_strEdit[EN_EDIT_FILENAME] = thePrefs.m_fileName;

	for (int i = 0; i < (EN_STATIC_MAX - 1); i++)
	{
		CString	strTest;
		strTest.Format(_T("%.2f"), m_fResistance[i]);
		m_stConfig[i].SetCaption( strTest );
	}

	m_stConfig[EN_STATIC_FOLDER].SetCaption( thePrefs.m_folderPath ); 

	UpdateData(FALSE);

	for ( int i = 0; i < EN_CHECK_MAX; i++)
		m_chkConfig[i].SetCheck(m_bCheckInfo[i]);

	m_spinConfig[EN_EDIT_TEMP].SetRange32(0, 90);		
	m_spinConfig[EN_EDIT_ALLOWABLE].SetRange32(0, 9);	
	m_spinConfig[EN_EDIT_BENDING].SetRange32(0, 3500);	
	m_spinConfig[EN_EDIT_AMP].SetRange32(0, 30);		
	m_spinConfig[EN_EDIT_FAIL].SetRange32(0, 100);		
	m_spinConfig[EN_EDIT_INTERVAL].SetRange32(0, 60);	

	if(bDisable)
	{
		for(int i = 0; i < EN_EDIT_MAX; i++)
			m_editConfig[i].EnableWindow(FALSE);

		for(int i = 0; i < EN_SPIN_MAX; i++)
			m_spinConfig[i].EnableWindow(FALSE);

		for(int i = 0; i < EN_BTN_MAX; i++)
			m_btnConfig[i].EnableWindow(FALSE);

		for(int i = 0; i < EN_CHECK_MAX; i++)
			m_chkConfig[i].EnableWindow(FALSE);
			
	}

	m_bInitConfig = TRUE;
}

void CConfigDlg::InitPos()
{
	CRect	rcClient;
	GetClientRect(&rcClient);

	if (m_editConfig[0].m_hWnd	&& 
		m_chkConfig[0].m_hWnd	&& 
		m_stConfig[0].m_hWnd	&& 
		m_btnConfig[0].m_hWnd)
	{
		int nCtrlTop = IPC_CONFIG_EDIT_STARTY;

		int nCtrlWidth = 60;
		int	nCtrlHeight = 20;
		int	nCtrlIntv = 10, nLineIntv = 9, nOffSet = 10;

		CRect	rcTemp(0,0,0,0);

		// Set Temp Define Pos
		/////////////////////////////////////////////////////////
		rcTemp.left		= IPC_CONFIG_EDIT_STARTX;
		rcTemp.right	= rcTemp.left + nCtrlWidth;
		rcTemp.top		= nCtrlTop;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_editConfig[EN_EDIT_TEMP].MoveWindow(&rcTemp, FALSE);

		// Set Spin Control
		// EditCtrl �� Child SpinCtrl �� Add �Ѵ�.
		CWnd *pBuddy;
		pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcTemp.left + 1, rcTemp.top + 1), CWP_SKIPINVISIBLE);
		m_spinConfig[EN_EDIT_TEMP].SetBuddy(pBuddy);

		{
			CRect rcBtn;
			m_btnConfig[EN_BTN_AUTOSTART].GetWindowRect(&rcBtn);
		
			int w = rcBtn.Width();
			int h = rcBtn.Height();

			rcBtn.left = rcTemp.right + 170;
			rcBtn.right = rcBtn.right + w;
			rcBtn.top = rcTemp.top + 1;
			rcBtn.bottom = rcBtn.top + h;

			m_btnConfig[EN_BTN_AUTOSTART].MoveWindow(&rcBtn, FALSE);
			m_btnConfig[EN_BTN_NOTSTART].MoveWindow(&rcBtn, FALSE);
			m_btnConfig[EN_BTN_AUTOSTART].Invalidate(FALSE);
			m_btnConfig[EN_BTN_NOTSTART].Invalidate(FALSE);
			m_btnConfig[EN_BTN_AUTOSTART].ShowWindow(SW_SHOW);
			m_btnConfig[EN_BTN_NOTSTART].ShowWindow(SW_HIDE);

			UpdateAutoStart();
		}

		rcTemp.top		= rcTemp.bottom + nLineIntv;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_editConfig[EN_EDIT_ALLOWABLE].MoveWindow(&rcTemp, FALSE);

		pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcTemp.left + 1, rcTemp.top + 1), CWP_SKIPINVISIBLE);
		m_spinConfig[EN_EDIT_ALLOWABLE].SetBuddy(pBuddy);

		rcTemp.top		= rcTemp.bottom + nLineIntv * 5;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_editConfig[EN_EDIT_BENDING].MoveWindow(&rcTemp, FALSE);

		pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcTemp.left + 1, rcTemp.top + 1), CWP_SKIPINVISIBLE);
		m_spinConfig[EN_EDIT_BENDING].SetBuddy(pBuddy);

		{
			CRect rcBtn;
			m_btnConfig[EN_BTN_BFSTART].GetWindowRect(&rcBtn);
		
			int w = rcBtn.Width();
			int h = rcBtn.Height();

			int nLeft = rcTemp.right + 27;
			rcBtn.top = rcTemp.top + 1;
			rcBtn.bottom = rcBtn.top + h;

			nLeft = rcTemp.right + 20 + (w + nCtrlIntv);
			for(int i = EN_BTN_BFSTART; i < EN_BTN_BFSTOP; i++)
			{
				rcBtn.left = nLeft + (i * (w + nCtrlIntv));
				rcBtn.right = rcBtn.left + w;

				m_btnConfig[i].MoveWindow(&rcBtn, FALSE);
				m_btnConfig[i].Invalidate(FALSE);
				m_btnConfig[i].ShowWindow(SW_SHOW);
			}
			m_btnConfig[EN_BTN_BFSTOP].ShowWindow(SW_HIDE);
		}
		/////////////////////////////////////////////////////////

		rcTemp.top		= rcTemp.bottom + nLineIntv;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_editConfig[EN_EDIT_AMP].MoveWindow(&rcTemp, FALSE);

		pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcTemp.left + 1, rcTemp.top + 1), CWP_SKIPINVISIBLE);
		m_spinConfig[EN_EDIT_AMP].SetBuddy(pBuddy);

		rcTemp.left		= IPC_CONFIG_EDIT_STARTX - 25;
		rcTemp.top		= rcTemp.bottom + nLineIntv * 5 + 3;
		rcTemp.right	= rcTemp.left + nCtrlWidth;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_editConfig[EN_EDIT_FAIL].MoveWindow(&rcTemp, FALSE);

		pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcTemp.left + 1, rcTemp.top + 1), CWP_SKIPINVISIBLE);
		m_spinConfig[EN_EDIT_FAIL].SetBuddy(pBuddy);

		rcTemp.top		= rcTemp.bottom + nLineIntv;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_editConfig[EN_EDIT_INTERVAL].MoveWindow(&rcTemp, FALSE);

		pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcTemp.left + 1, rcTemp.top + 1), CWP_SKIPINVISIBLE);
		m_spinConfig[EN_EDIT_INTERVAL].SetBuddy(pBuddy);

		rcTemp.left		= IPC_CONFIG_EDIT_STARTX + 90;
		rcTemp.right	= rcTemp.left + nCtrlWidth * 2;
		m_editConfig[EN_EDIT_TESTCOUNT].MoveWindow(&rcTemp, FALSE);

		rcTemp.left		= rcTemp.right + nCtrlIntv;
		rcTemp.right	= rcTemp.left + 15;
		m_chkConfig[EN_CHECK_USED].MoveWindow(&rcTemp, FALSE);

		int tempPos = rcTemp.bottom;

		rcTemp.left		= IPC_CONFIG_EDIT_STARTX + 135;
		rcTemp.top		= rcTemp.bottom + nLineIntv * 3 + 5;
		rcTemp.right	= rcTemp.left + nCtrlWidth * 3 - 20;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			m_editConfig[EN_EDIT_S1 + i].MoveWindow(&rcTemp, FALSE);

			rcTemp.top		= rcTemp.bottom + nLineIntv - 2;
			rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		}

		rcTemp.left		= IPC_CONFIG_EDIT_STARTX - 75;
		rcTemp.top		= tempPos + nLineIntv * 9 + 5;
		rcTemp.right	= rcTemp.left + 15;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			m_chkConfig[EN_CHECK_S1 + i].MoveWindow(&rcTemp, FALSE);
			rcTemp.left		= rcTemp.right + nCtrlIntv * 2 + 3;
			rcTemp.right	= rcTemp.left + 15;
		}

		rcTemp.left		= IPC_CONFIG_EDIT_STARTX - 91;
		rcTemp.top		= rcTemp.top + 108;
		rcTemp.right	= rcTemp.left + nCtrlWidth;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			m_stConfig[i].MoveWindow(&rcTemp, FALSE);

			rcTemp.left		= rcTemp.right + 5;
			rcTemp.right	= rcTemp.left + nCtrlWidth;
		}

		{
			CRect rcBtn;
			m_btnConfig[EN_BTN_PRETEST].GetWindowRect(&rcBtn);
		
			int w = rcBtn.Width();
			int h = rcBtn.Height();

			rcBtn.left = rcTemp.left + 20;
			rcBtn.top = rcTemp.top - 20;
			rcBtn.right = rcBtn.right + w;
			rcBtn.bottom = rcBtn.top + h;

			m_btnConfig[EN_BTN_PRETEST].MoveWindow(&rcBtn, FALSE);
			m_btnConfig[EN_BTN_PRETEST].Invalidate(FALSE);
			m_btnConfig[EN_BTN_PRETEST].ShowWindow(SW_SHOW);
		}

		rcTemp.left		= IPC_CONFIG_EDIT_STARTX - 91;
		rcTemp.top		= rcTemp.bottom + nLineIntv * 5;
		rcTemp.right	= rcTemp.left + nCtrlWidth * 4 + 30;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_stConfig[EN_STATIC_FOLDER].MoveWindow(&rcTemp, FALSE);

		{
			CRect rcBtn;
			m_btnConfig[EN_BTN_FOLDER].GetWindowRect(&rcBtn);
		
			int w = rcBtn.Width();
			int h = rcBtn.Height();

			rcBtn.left = rcTemp.right + 10;
			rcBtn.top = rcTemp.top + 1;
			rcBtn.right = rcBtn.right + w;
			rcBtn.bottom = rcBtn.top + h;

			m_btnConfig[EN_BTN_FOLDER].MoveWindow(&rcBtn, FALSE);
			m_btnConfig[EN_BTN_FOLDER].Invalidate(FALSE);
			m_btnConfig[EN_BTN_FOLDER].ShowWindow(SW_SHOW);
		}

		rcTemp.left		= IPC_CONFIG_EDIT_STARTX - 25;
		rcTemp.top		= rcTemp.bottom + 5;
		rcTemp.right	= rcTemp.left + nCtrlWidth * 3 + 25;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		m_editConfig[EN_EDIT_FILENAME].MoveWindow(&rcTemp, FALSE);

	}
}

void CConfigDlg::InitControl()
{
	// Create ToolTip Control
	m_ToolTipCtrl.Create(this);
	m_ToolTipCtrl.Activate(TRUE);

	CRect	rcTemp(0,0,0,0);

	// Create Check Button Ctrls
	//////////////////////////////////////////////////////
	for (int i = 0; i < EN_CHECK_MAX; i++)
		m_chkConfig[i].Create(NULL, WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX | BS_NOTIFY, 
							rcTemp, this, IDC_CONFIG_CHECK_S1 + i, XEN_BTN_CHECK);

	// Create Config Buttons 
	//////////////////////////////////////////////////////////////////////////////////
	CImageList*	pImageList = NULL;
	for (int i = 0; i < EN_BTN_MAX; i++)
	{
		if(i == EN_BTN_BFSTART)
			pImageList = theResMan.GetImageListRes(IPC_RESMAN_BTN_TEST_START);
		else if( i == EN_BTN_BFSTOP)
			pImageList = theResMan.GetImageListRes(IPC_RESMAN_BTN_TEST_STOP);
		else
			pImageList = theResMan.GetImageListRes(IPC_RESMAN_BTN_AUTOSTART + (i - EN_BTN_AUTOSTART));

		IMAGEINFO	imgInfo;
		CRect	rcRect;
		pImageList->GetImageInfo(1, &imgInfo);
		rcRect = imgInfo.rcImage;

		m_btnConfig[i].SetImageList(pImageList, 0);
		m_btnConfig[i].Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
							rcRect, this, IDC_CONFIG_BTN_BFSTART + i);
		m_btnConfig[i].SetTransparent();
	}

	m_ToolTipCtrl.AddTool((CWnd *)&m_btnConfig[EN_BTN_AUTOSTART], _T("�ڵ����� ON"));
	m_ToolTipCtrl.AddTool((CWnd *)&m_btnConfig[EN_BTN_NOTSTART], _T("�ڵ����� OFF"));

	short pwidth = 60;
	for (int i = EN_STATIC_S1; i < (EN_STATIC_MAX - 1); i++)
	{
		m_stConfig[i].Create(NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | SS_OWNERDRAW, 
							CRect(0, 0, pwidth, 20), this, IDC_CONFIG_STATIC_S1 + i);
		m_stConfig[i].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		m_stConfig[i].SetFontColor( m_clrValue );	
		m_stConfig[i].SetCaption( _T("") );
	}
	m_stConfig[EN_STATIC_FOLDER].Create( _T(""),  WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, rcTemp, this, IDC_CONFIG_STATIC_FOLDER);
	m_stConfig[EN_STATIC_FOLDER].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
	m_stConfig[EN_STATIC_FOLDER].SetTransparent();
	m_stConfig[EN_STATIC_FOLDER].SetFontColor( m_clrText );	
	m_ToolTipCtrl.AddTool((CWnd *)&m_stConfig[EN_STATIC_FOLDER], thePrefs.m_folderPath);

	/*
	 *	Load Image & Set Config Dialog Size and Pos
	 */
	CBitmap		bmp;
	BITMAP		bmpInfo;
	IMAGEINFO	ImgInfo;
	CRect		rcImg;
	int			nHeight = IPC_CONFIG_HEIGHT;

	// Load Config Title Image
	//////////////////////////////////////////////////////
	bmp.LoadBitmap(IDB_CONFIG_TITLE);
	bmp.GetBitmap(&bmpInfo);
	m_ImgConfig.Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
	m_ImgConfig.Add(&bmp, m_clrMask);
	bmp.DeleteObject();

	// Set Config Window Size & Pos
	//////////////////////////////////////////////////////
	HDC hDC		  = ::GetDC( ::GetDesktopWindow() );
	int	scrWidth  = ::GetDeviceCaps(hDC, HORZRES);
	int scrHeight = ::GetDeviceCaps(hDC, VERTRES);
	::ReleaseDC( ::GetDesktopWindow(), hDC );

	m_ImgConfig.GetImageInfo(0, &ImgInfo);
	rcImg = ImgInfo.rcImage;

	MoveWindow( (scrWidth - rcImg.Width()) / 2, (scrHeight - rcImg.Height()) / 2, rcImg.Width(), rcImg.Height() );

	// Windows Close button Create
	//////////////////////////////////////////////////////////////////////////////////
	CRect	rectWin;
	GetClientRect(&rectWin);
	int nStartPos = rectWin.right - IPC_MAIN_RIGHT * 3 + 2;

	CImageList* pImgList = theResMan.GetImageListRes( IPC_RESMAN_WINDOW_CLOSE);
	m_btnWindowClose.SetImageList( pImgList, 0 );
	pImgList->GetImageInfo( 0, &ImgInfo );
	CRect rectBtn = ImgInfo.rcImage;

	m_btnWindowClose.Create( NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
							rectBtn, this, IDC_WINDOW_CLOSE );

	m_btnWindowClose.SetTransparent( );
	m_ToolTipCtrl.AddTool((CWnd *)&m_btnWindowClose, _T("ȯ�漳�� ���� �� ����"));


	int nTop	= rectWin.top + (IPC_CONFIG_TITLEBAR_HEIGHT - rectBtn.Height()) / 2; 
	int nLeft	= nStartPos - (rectBtn.Width() + 2);
	m_btnWindowClose.MoveWindow(nLeft, nTop, rectBtn.Width(), rectBtn.Height());
}

void CConfigDlg::UpdatePreference()
{
	USES_CONVERSION;

	for(int i = 0; i < (EN_CHECK_MAX - 1); i++)
		thePrefs.m_materialInfo[i] = (m_bCheckInfo[i])? true : false;

	thePrefs.m_bUsed = (m_bCheckInfo[EN_CHECK_USED])? true : false;

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		thePrefs.m_preTest[i] = m_fResistance[i];

	thePrefs.m_temp = m_iRange[EN_EDIT_TEMP];
	thePrefs.m_allowable = m_iRange[EN_EDIT_ALLOWABLE];
	thePrefs.m_bendingSpeed = m_iRange[EN_EDIT_BENDING];
	thePrefs.m_amplitude = m_iRange[EN_EDIT_AMP];
	thePrefs.m_failPercent = m_iRange[EN_EDIT_FAIL];

	thePrefs.m_interval = m_fInterval;
	thePrefs.m_stopCount = m_iStopCount;
	thePrefs.m_bAutoStart = m_bAutoStart;

	for(int i = EN_EDIT_S1; i < (EN_EDIT_MAX - 1); i++)
		 thePrefs.m_materialName[i - EN_EDIT_S1] = m_strEdit[i];
	thePrefs.m_fileName = m_strEdit[EN_EDIT_FILENAME];

	thePrefs.m_folderPath = m_stConfig[EN_STATIC_FOLDER].GetCaption();

	thePrefs.Save();
}

void CConfigDlg::UpdateAutoStart()
{
	if(m_bAutoStart)	
	{
		m_btnConfig[EN_BTN_NOTSTART].ShowWindow(SW_HIDE);
		m_btnConfig[EN_BTN_AUTOSTART].ShowWindow(SW_SHOW);
	}
	else
	{
		m_btnConfig[EN_BTN_AUTOSTART].ShowWindow(SW_HIDE);
		m_btnConfig[EN_BTN_NOTSTART].ShowWindow(SW_SHOW);
	}
}

void CConfigDlg::DrawTitleBar( CDC *pDC )
{
	CDC		dcMemory;
	CRect	rc_Client;
	IMAGEINFO	ImgInfo;

	GetClientRect( rc_Client );

	// Window Title Image Draw
	CImageList	*pImgList = theResMan.GetImageListRes( IPC_RESMAN_IPC_CONFIGLOGO );
	pImgList->Draw( pDC, 0, CPoint( 5, 7 ), ILD_TRANSPARENT );

	// Window Title DrawText
	//////////////////////////////////////////
	pImgList->GetImageInfo(0, &ImgInfo);
	CRect imgRrect = ImgInfo.rcImage;

	CRect rcItem(imgRrect.Width() + 15, 7, rc_Client.right, imgRrect.Height() + 10);

	CFont*	pFont;
	//pFont = thePrefs.GetGUIDefaultBold();
	pFont = thePrefs.GetGUIDefault();

    CFont* pOldFont = pDC->SelectObject(pFont);
	
	pDC->SetTextColor(PALETTERGB(255,255,255));
	pDC->SetBkMode(TRANSPARENT);
	pDC->DrawText(GetResString(IDS_PREF_DLG_CAPTION), rcItem, DT_SINGLELINE | DT_LEFT | DT_VCENTER );

	pDC->SelectObject(pOldFont);
	//
}

BEGIN_MESSAGE_MAP(CConfigDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_NCHITTEST()

	ON_MESSAGE(UM_IPC_AMPTEST,	OnAMPTest)
	ON_MESSAGE(UM_IPC_PRETEST,	OnPreTest)

	ON_BN_CLICKED(IDC_WINDOW_CLOSE, OnCancel)

	ON_CONTROL_RANGE(BN_CLICKED, IDC_CONFIG_BTN_BFSTART, IDC_CONFIG_BTN_FOLDER, OnBnClickedCommand)
	ON_NOTIFY(UDN_DELTAPOS, IDC_CONFIG_SPIN_INTERVAL, OnDeltaposSpinInterval)

	ON_CONTROL_RANGE(EN_KILLFOCUS, IDC_CONFIG_EDIT_TEMP, IDC_CONFIG_EDIT_TESTCOUNT, OnEnKillFocusEdit)

END_MESSAGE_MAP()


// CConfigDlg �޽��� ó�����Դϴ�.

BOOL CConfigDlg::OnInitDialog()
{
	/*
	 *	Create Preference Controls & Set Properties	
	 *  Note: DDX/DDV�� �����Ǳ� ���� User Created Control�� �����Ѵ�.
	 */
	InitControl();

	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	LocalizeFont();	//Initialize Font Info
	Localize();		//Initialize Control Captions
	InitConfig();	//Set Initial Value

	InitPos();

	
	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BOOL CConfigDlg::PreTranslateMessage(MSG* pMsg )
{
	if (pMsg->message == WM_MOUSEMOVE) m_ToolTipCtrl.RelayEvent(pMsg);	
	return CDialog::PreTranslateMessage(pMsg);
}

void CConfigDlg::OnOK()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	UpdateData();
	UpdatePreference();

	CDialog::OnOK();
}

void CConfigDlg::OnCancel()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	UpdateData();
	UpdatePreference();

	CDialog::OnCancel();
}

void CConfigDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialog::OnPaint()��(��) ȣ������ ���ʽÿ�.
	CRect rect;
	GetClientRect(rect);

	IMAGEINFO	ImgInfo;
	CRect		rcImg;
	CPoint		pt;
	// Draw Title Image
	//////////////////////////////////////////////////////
	if(m_ImgConfig.GetImageInfo(0, &ImgInfo))
	{
		CPoint point = rect.TopLeft();
		m_ImgConfig.Draw(&dc, 0, point, ILD_TRANSPARENT);
	}

	DrawTitleBar(&dc);
}

LRESULT CConfigDlg::OnNcHitTest(CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	//return CDialog::OnNcHitTest(point);
	UINT ret =  CDialog::OnNcHitTest(point);

	CRect rect;
	GetClientRect(rect);
	ClientToScreen(rect);

	int interval = 3;

	if(rect.left + interval > point.x && rect.top + interval > point.y)
		return HTTOPLEFT;
	else if(rect.right - interval < point.x && rect.top+interval > point.y)
		return HTTOPRIGHT;
	else if(rect.left + interval > point.x && rect.bottom-interval < point.y)
		return HTBOTTOMLEFT;
	else if(rect.right - interval < point.x && rect.bottom-interval < point.y)
		return HTBOTTOMRIGHT;
	else if(rect.right - interval < point.x)
		return HTRIGHT;
	else if(rect.left + interval > point.x)
		return HTLEFT;
	else if(rect.top + interval > point.y)
		return HTTOP;
	else if(rect.bottom - interval < point.y)
		return HTBOTTOM;
	else if(ret == HTCLIENT && ( rect.top + IPC_CONFIG_TITLEBAR_HEIGHT ) > point.y)
	{
		return HTCAPTION;
	}
	return ret;
}

void CConfigDlg::OnDeltaposSpinInterval(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData();

	m_fInterval = (float)(m_fInterval + pNMUpDown->iDelta * 0.5f);
	if(m_fInterval < 0.5)		m_fInterval = 0.5f;
	if(m_fInterval > 60.0)	m_fInterval = 60.0f;

	UpdateData(FALSE);

	*pResult = 1;
}


void CConfigDlg::OnEnKillFocusEdit(UINT ID)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData();

	switch(ID)
	{
		case IDC_CONFIG_EDIT_TEMP :
			if(m_iRange[EN_EDIT_TEMP] < 0 || m_iRange[EN_EDIT_TEMP] > 90.0f)
			{
				AfxMessageBox(_T("�µ� ������ ���� �ʰ�! (0 ~ 90)"), MB_OK);
				m_iRange[EN_EDIT_TEMP] = 90.0f;
				UpdateData(FALSE);
				m_editConfig[EN_EDIT_TEMP].SetSel(0, -1, TRUE);
				m_editConfig[EN_EDIT_TEMP].SetFocus();
			}
			break;

		case IDC_CONFIG_EDIT_PERMISSIBLE :
			if(m_iRange[EN_EDIT_ALLOWABLE] < 0 || m_iRange[EN_EDIT_ALLOWABLE] > 9)
			{
				AfxMessageBox(_T("���µ� ������ ���� �ʰ�! (0 ~ 9)"), MB_OK);
				m_iRange[EN_EDIT_ALLOWABLE] = 9;
				UpdateData(FALSE);
				m_editConfig[EN_EDIT_ALLOWABLE].SetSel(0, -1, TRUE);
				m_editConfig[EN_EDIT_ALLOWABLE].SetFocus();
			}
			break;

		case IDC_CONFIG_EDIT_BENDING :
			if(m_iRange[EN_EDIT_BENDING] < 0 || m_iRange[EN_EDIT_BENDING] > 3500)
			{
				AfxMessageBox(_T("Bending �ӵ� ������ ���� �ʰ�! (0 ~ 3500)"), MB_OK);
				m_iRange[EN_EDIT_BENDING] = 3500;
				UpdateData(FALSE);
				m_editConfig[EN_EDIT_BENDING].SetSel(0, -1, TRUE);
				m_editConfig[EN_EDIT_BENDING].SetFocus();
			}
			break;

		case IDC_CONFIG_EDIT_AMP :
			if(m_iRange[EN_EDIT_AMP] < 0 || m_iRange[EN_EDIT_AMP] > 30)
			{
				AfxMessageBox(_T("����� ������ ���� �ʰ�! (0 ~ 30)"), MB_OK);
				m_iRange[EN_EDIT_AMP] = 30;
				UpdateData(FALSE);
				m_editConfig[EN_EDIT_AMP].SetSel(0, -1, TRUE);
				m_editConfig[EN_EDIT_AMP].SetFocus();
			}
			break;

		case IDC_CONFIG_EDIT_FAIL :
			if(m_iRange[EN_EDIT_FAIL] < 0 || m_iRange[EN_EDIT_FAIL] > 100)
			{
				AfxMessageBox(_T("Fail Margin ������ ���� �ʰ�! (0 ~ 100)"), MB_OK);
				m_iRange[EN_EDIT_FAIL] = 100.0;
				UpdateData(FALSE);
				m_editConfig[EN_EDIT_FAIL].SetSel(0, -1, TRUE);
				m_editConfig[EN_EDIT_FAIL].SetFocus();
			}
			break;

		case IDC_CONFIG_EDIT_INTERVAL :
			if(m_fInterval < 0.5 || m_fInterval > 60.0f)
			{
				AfxMessageBox(_T("�������� ������ ���� �ʰ�! (0.5 ~ 60��)"), MB_OK);
				m_fInterval = 60.0f;
				UpdateData(FALSE);
				m_editConfig[EN_EDIT_INTERVAL].SetSel(0, -1, TRUE);
				m_editConfig[EN_EDIT_INTERVAL].SetFocus();
			}
			break;

		case IDC_CONFIG_EDIT_TESTCOUNT :
			if(m_iStopCount < 0 || m_iStopCount > 99999999)
			{
				AfxMessageBox(_T("������ ���� �ʰ�! (0 ~ 99999999)"), MB_OK);
				m_iStopCount  = 99999999;
				UpdateData(FALSE);
				m_editConfig[EN_EDIT_TESTCOUNT].SetSel(0, -1, TRUE);
				m_editConfig[EN_EDIT_TESTCOUNT].SetFocus();
			}
			break;

		default:
			break;
	}
}


//
// Config Button Click Message �� ó�� Function
/////////////////////////////////////////////////////
void CConfigDlg::OnBnClickedCommand(UINT ID)
{
	// �������� Test
	if(ID == IDC_CONFIG_BTN_BFSTART ||		// ���� ���� : BFTest Start
	   ID == IDC_CONFIG_BTN_BFSTOP )		// ���� ����
	{
		UpdateData();

		CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
		if(pAcct && pAcct->IsConnection())
		{
			pAcct->SetWindowHandle(m_hWnd);

			if(ID == IDC_CONFIG_BTN_BFSTART)
				pAcct->StartAmpTest(m_iRange[EN_EDIT_AMP], m_iRange[EN_EDIT_BENDING]);
			else
				pAcct->EndAmpTest();
		}
	}
	else if(ID == IDC_CONFIG_BTN_AUTOSTART ||	// �ڵ�����
			ID == IDC_CONFIG_BTN_NOTSTART)		// NOT �ڵ�����
	{
			m_bAutoStart = !m_bAutoStart;	
			UpdateAutoStart();
	}
	else if(ID == IDC_CONFIG_BTN_PRETEST)	// ��������
	{
		UpdateData();

		CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
		if(pAcct && pAcct->IsConnection())
		{
			pAcct->SetWindowHandle(m_hWnd);
			pAcct->MTPreTest();				// method_BFTMD_MTTEST_IND
		}
	}
	else if(ID == IDC_CONFIG_BTN_FOLDER)	// ��������
	{
		CString strTitle;
		strTitle = GetResString(IDS_PREF_SELECTFOLDER_CAPTION);

		// TODO: Add your control notification handler code here
		CFolderDialog dlg(NULL, CSIDL_DRIVES, strTitle, thePrefs.GetFileDir(), BIF_EDITBOX | BIF_NEWDIALOGSTYLE);
		if(dlg.DoModal() == IDOK) 
		{
			thePrefs.SetFileDir(dlg.GetFolderPath());
			m_stConfig[EN_STATIC_FOLDER].SetCaption(dlg.GetFolderPath());
			m_ToolTipCtrl.UpdateTipText(thePrefs.GetFileDir(), (CWnd *)&m_stConfig[EN_STATIC_FOLDER]);
		}	
	}
}


HRESULT CConfigDlg::OnAMPTest( WPARAM wParam, LPARAM lParam )
{
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
	
	switch(wParam)
	{	
		case ID_IPC_AMPTEST_START_CONFIRM :			// ���� �׽�Ʈ ���� Confirm
			{

				if(lParam == S_OK)
				{
					// CAmpTestDlg Popup
					CWnd* pMainWnd = theApp.GetMainWnd();
					::PostMessage(pMainWnd->m_hWnd, UM_IPC_AMPTESTDIALOG, 0, m_iRange[EN_EDIT_AMP]);	

					// ���� �� ��û
				//	pAcct->AmpDataRequest();

					////AMPTest â ����
					//CAmplitudeDlg	pAmpTest(this);
					//pAmpTest.SetAmplitude(m_iRange[EN_EDIT_AMP]);
					//pAmpTest.DoModal();

					//pAcct->SetWindowHandle(m_hWnd);
				}
			}
			break;
		case ID_IPC_AMPTEST_END_CONFIRM :
			break;

		case ID_IPC_AMPTEST_DATA :
			{
				char* pStr = (char*)lParam;
				float pVal = atof(pStr);

			}
			break;

		default :
			break;
	}

	return 0;

}

HRESULT CConfigDlg::OnPreTest( WPARAM wParam, LPARAM lParam )
{
	static short	m_selectMT = 0;			// �������� ��ȣ
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;

	switch(wParam)
	{
		case ID_IPC_PRETEST_CONFIRM :				// ���� ���� Pre-Test Confirm
			{
				// �������� (ù��° ���� ã��)
				m_selectMT = 0;
				bool	bSelect = false;
				for(int i = 0; i < IPC_MAX_MATERIAL; i++)
				{
					if(m_bCheckInfo[i])
					{
						m_selectMT = i + 1;
						pAcct->SelectMTRequest(m_selectMT);
						bSelect = true;
						break;
					}
				}

				if(!bSelect)
					theApp.IPCMessageBox(_T("���õ� ������ �����ϴ�"), 
										GetResString(IDS_PREF_DLG_CAPTION), 
										MB_OK);
			}
			break;

		case ID_IPC_PRETEST_INITIALIZE_CONFIRM :		// ���� �ʱ�ȭ
			{
				// ��� �������� �Ϸ� Chck ?
				// 1. �Ϸ�		: �� ���� ���� �� ȭ�鿡 ǥ��
				// 2. �� �Ϸ�	: �������� ( 2 ~ 4) �ݺ�
				//////////////////////////////////////////
				bool	bSelect = false;
				for(int i = m_selectMT; i < IPC_MAX_MATERIAL; i++)
				{
					if(m_bCheckInfo[i])
					{
						m_selectMT = i + 1;
						pAcct->SelectMTRequest(m_selectMT);
						bSelect = true;
						break;
					}
				}

				if(!bSelect)	// 1. �Ϸ� : �� ���� ���� �� ȭ�鿡 ǥ��
					theApp.IPCMessageBox(_T("���� Pre-Test �Ϸ�Ǿ����ϴ�."),
										GetResString(IDS_PREF_DLG_CAPTION), 
										MB_OK | MB_ICONINFORMATION);
			}
			break;

		case ID_IPC_PRETEST_SELECT_CONFIRM :		// �������� / �������� �ʱ�ȭ Confirm
			{
				// ���õ� ������ ���װ� ��û  To RMI(������)
				CRMIInterface* pRMI = theApp.m_pRMI;
				if(pRMI)
				{
					pRMI->SetWindowHandle(m_hWnd);
					pRMI->RequestResistData();
				}
			}
			break;

		case ID_IPC_PRETEST_RESISTANCE :			// ���װ� ����
			{
				char* pStr = (char*)lParam;
				float lfResist = atof(pStr);
				delete pStr;

				// yoonmijin �ӽ� Comment PostMessage ��ü
				// �������� �ʱ�ȭ(0)
#ifdef	_IPC_TEST_
				::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_INITIALIZE_CONFIRM, 0);
#else
				pAcct->SelectMTRequest(0);
#endif
				////////////////////////////////////////////////////////

				// ���װ� ���� �� Display
				m_fResistance[m_selectMT - 1] = lfResist;

				CString	strTest;
				strTest.Format(_T("%.4f"), m_fResistance[m_selectMT - 1]);
				m_stConfig[m_selectMT - 1].SetCaption( strTest );
			}
			break;
		default :
			break;
	}
	return 0;

}



