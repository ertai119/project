// MeasReportDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "MeasReportDlg.h"

#include "FileManager.h"

// CMeasReportDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CMeasReportDlg, CDialog)

CMeasReportDlg::CMeasReportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMeasReportDlg::IDD, pParent)
{
	m_clrBack		= IPC_BACKGROUND_COLOR;	
	m_clrText		= PALETTERGB(0,0,0);			// BLACK
	m_clrBlue		= PALETTERGB(0, 0, 255);		// BLUE
	m_clrOutline	= PALETTERGB( 194, 193, 193);
	m_clrMask		= PALETTERGB(255,0,255);		// PINK

	pHistoryWnd = (CMeasHistoryDlg*)pParent;
}

CMeasReportDlg::~CMeasReportDlg()
{
	m_listFont.DeleteObject();
	m_imgList.DeleteImageList();
}

void CMeasReportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	for(int i = 0; i < EN_EDIT_MAX; i++)
	{
		DDX_Control(pDX, IDC_EDIT_REPORT_DOC + i, m_editReportEx[i]);
		DDX_Text(pDX, IDC_EDIT_REPORT_DOC + i, m_strReport[i]);
	}

}

void CMeasReportDlg::Localize()
{
	for (int i = 0; i < EN_STATIC_MAX; i++)
		m_stStatic[i].SetCaption(GetResString(IDS_REPORT_STATIC_1 + i));

	for (int i = 0; i < TRESULT_SITEM_MAX; i++)
	{
		m_ResultListCtrl.InsertColumn(	i, 
										GetResString(colDataResult[i].nColHdrId), 
										colDataResult[i].nFormat, 
										colDataResult[i].nWidth);
	}

	for (int i = 0; i < MEASURE_SITEM_MAX; i++)
	{
		m_MeasureListCtrl.InsertColumn(	i, 
										GetResString(colDataMeasure[i].nColHdrId), 
										colDataMeasure[i].nFormat, 
										colDataMeasure[i].nWidth);
	}

	{
		CHeaderCtrl* pHeaderCtrl = m_ResultListCtrl.GetHeaderCtrl();
		HDITEM hdi;
		hdi.mask = HDI_TEXT;
		CString strRes;

		for (int icol = 0; icol < pHeaderCtrl->GetItemCount(); icol++) 
		{
			switch (icol) 
			{
				case TRESULT_SITEM_NAME:		strRes = GetResString(IDS_REPORT_TRESULT_NAME);	break;
				case TRESULT_SITEM_INITRESIST:	strRes = GetResString(IDS_REPORT_TRESULT_INITRESIST);	break;
				case TRESULT_SITEM_FAILCOUNT:	strRes = GetResString(IDS_REPORT_TRESULT_FAILCOUNT);	break;
				case TRESULT_SITEM_TOTALCOUNT:	strRes = GetResString(IDS_REPORT_TRESULT_TOTALCOUNT);	break;
			}
		
			hdi.pszText = strRes.GetBuffer();
			pHeaderCtrl->SetItem(icol, &hdi);
			strRes.ReleaseBuffer();
		}

		pHeaderCtrl->SetImageList(&m_imgList);
	}

	// MeasureListCtrl HeaderCtrl
	{
		CHeaderCtrl* pHeaderCtrl = m_MeasureListCtrl.GetHeaderCtrl();
		HDITEM hdi;
		hdi.mask = HDI_TEXT;
		CString strRes;

		for (int icol = 0; icol < pHeaderCtrl->GetItemCount(); icol++) 
		{
			switch (icol) 
			{
				case MEASURE_SITEM_COUNT:	strRes = GetResString(IDS_REPORT_MEASURE_COUNT);	break;
				case MEASURE_SITEM_S1:		strRes = GetResString(IDS_REPORT_MEASURE_S1);	break;
				case MEASURE_SITEM_S2:		strRes = GetResString(IDS_REPORT_MEASURE_S2);	break;
				case MEASURE_SITEM_S3:		strRes = GetResString(IDS_REPORT_MEASURE_S3);	break;
				case MEASURE_SITEM_S4:		strRes = GetResString(IDS_REPORT_MEASURE_S4);	break;
				case MEASURE_SITEM_TEMP:	strRes = GetResString(IDS_REPORT_MEASURE_TEMP);	break;
			}
		
			hdi.pszText = strRes.GetBuffer();
			pHeaderCtrl->SetItem(icol, &hdi);
			strRes.ReleaseBuffer();
		}
		pHeaderCtrl->SetImageList(&m_imgList);
	}
}

void CMeasReportDlg::LocalizeFont()
{
	CFont *pFont = thePrefs.GetGUIDefault();
	CFont*	m_fontBold = thePrefs.GetGUIDefaultBold();

	// Set Font for CheckBox
	/////////////////////////////////////
	LOGFONT lf;
	pFont->GetLogFont(&lf);

	HDC hDC = ::GetDC(NULL);
	lf.lfHeight = -::MulDiv(10, ::GetDeviceCaps(hDC, LOGPIXELSY), 72);
	lf.lfWeight = FW_NORMAL;
	m_listFont.CreateFontIndirect(&lf);

	for (int i = 0; i < EN_STATIC_MAX; i++)
		m_stStatic[i].SetFont(pFont);

	m_editReportEx[EN_EDIT_DOCUMENT].SetFont(&m_listFont);
	m_editReportEx[EN_EDIT_HEADER].SetFont(&m_listFont);

	m_ResultListCtrl.SetFont(&m_listFont);
	m_MeasureListCtrl.SetFont(&m_listFont);

	{
		CHeaderCtrl* pHeaderCtrl = m_ResultListCtrl.GetHeaderCtrl();
		pHeaderCtrl->SetFont(m_fontBold);
	}
	{
		CHeaderCtrl* pHeaderCtrl = m_MeasureListCtrl.GetHeaderCtrl();
		pHeaderCtrl->SetFont(m_fontBold);
	}

}

void CMeasReportDlg::InitControl()
{
	// Create ToolTip Control
	m_ToolTipCtrl.Create(this);
	m_ToolTipCtrl.Activate(TRUE);

	CRect	rcTemp(0,0,0,0);

	// Image Create
	////////////////////////
	m_imgList.Create(1, 18 , ILC_COLOR4, 1, 1);			//  height 15

	// Create Static 
	//////////////////////////////////////////////////////////////////////////////////
	short pwidth = 70;
	for (int i = 0; i < EN_STATIC_MAX; i++)
	{
		m_stStatic[i].Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, 
							CRect(0, 0, pwidth, 20), this, IDC_HISTORY_STATIC_SCALEY + i);
		m_stStatic[i].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		if(i <= EN_STATIC_HEADER)
			m_stStatic[i].SetFontColor( m_clrBlue );
		else
			m_stStatic[i].SetFontColor( m_clrText );

		m_stStatic[i].SetCaption( _T("") );
	}

	m_ResultListCtrl.Create(WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS
		, rcTemp, this, IDC_REPORT_TRESULTLISTCTRL);

	m_ResultListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_ResultListCtrl.SetImageList(&m_imgList, LVSIL_SMALL);		

	m_MeasureListCtrl.Create(WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS
		, rcTemp, this, IDC_REPORT_TRESULTLISTCTRL);

	m_MeasureListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_MeasureListCtrl.SetImageList(&m_imgList, LVSIL_SMALL);	
}

void CMeasReportDlg::SetPosition()
{
	CRect	rcClient;
	GetClientRect(&rcClient);

	if (m_stStatic[0].m_hWnd && m_ResultListCtrl.m_hWnd != NULL &&
        m_MeasureListCtrl.m_hWnd != NULL )
	{
		int nCtrlWidth = 100;
		int	nCtrlHeight = 20;
		int	nCtrlIntv = 10, nLineIntv = 3, nOffSet = 10;

		CRect	rcTemp(0,0,0,0);

		// Set Static Pos
		/////////////////////////////////////////////////////
		rcTemp.left		= IPC_REPORT_LEFT;
		rcTemp.right	= rcTemp.left + nCtrlWidth;
		rcTemp.top		= IPC_REPORT_TOP;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;

		for(int i = 0; i < EN_STATIC_MAX; i++)
		{
			rcTemp.left		= IPC_REPORT_LEFT;
			rcTemp.right	= rcTemp.left + nCtrlWidth;

			// Title Static
			m_stStatic[i].MoveWindow(&rcTemp, FALSE);
			m_stStatic[i].Invalidate();
			m_stStatic[i].ShowWindow(SW_SHOW);

			// Edit or Control pos
			rcTemp.top		= rcTemp.bottom + nLineIntv;
			rcTemp.bottom	= rcTemp.top + IPC_REPORT_EDIT_HEIGHT;
			
			if(i <= EN_STATIC_HEADER)
			{
				// Edit Control pos
				rcTemp.right = rcTemp.left + IPC_REPORT_EDIT_WIDTH;

				m_editReportEx[i].MoveWindow(rcTemp.left, rcTemp.top, rcTemp.Width(), rcTemp.Height(), FALSE);
				m_editReportEx[i].Invalidate();
				m_editReportEx[i].ShowWindow(SW_SHOW);

				rcTemp.top		= rcTemp.bottom + nLineIntv * 2;
				rcTemp.bottom	= rcTemp.top + nCtrlHeight;
			}
			else
			{
				// ResultListCtrl
				rcTemp.right = rcTemp.left + IPC_REPORT_EDIT_WIDTH;
				rcTemp.bottom	= rcTemp.top + IPC_REPORT_EDIT_HEIGHT - 50;

				rcTemp.DeflateRect(1,1);

				m_ResultListCtrl.MoveWindow(rcTemp);				
				m_ResultListCtrl.Invalidate(FALSE);
			}
		}

		// MeasureListCtrl
		{
			rcTemp.left = IPC_REPORT_MEAS_STARTX;
			rcTemp.top = IPC_REPORT_TOP;
			rcTemp.right = rcClient.right - IPC_REPORT_LEFT;
			rcTemp.bottom = rcClient.bottom - IPC_REPORT_BOTTOM;

			rcTemp.DeflateRect(1,1);

			m_MeasureListCtrl.MoveWindow(rcTemp);	
			m_MeasureListCtrl.Invalidate(FALSE);

			int nWidth = rcTemp.Width() - 
						(	IPC_MEASURE_COLUMN_COUNT + 
							IPC_MEASURE_COLUMN_S1 +
							IPC_MEASURE_COLUMN_S2 +
							IPC_MEASURE_COLUMN_S3 +
							IPC_MEASURE_COLUMN_S4 +
							IPC_MEASURE_COLUMN_TEMP );

			nWidth = (nWidth - 20) / MEASURE_SITEM_MAX;

			m_MeasureListCtrl.SetColumnWidth(MEASURE_SITEM_COUNT,	IPC_MEASURE_COLUMN_COUNT + nWidth);
			m_MeasureListCtrl.SetColumnWidth(MEASURE_SITEM_S1,		IPC_MEASURE_COLUMN_S1 + nWidth);
			m_MeasureListCtrl.SetColumnWidth(MEASURE_SITEM_S2,		IPC_MEASURE_COLUMN_S2 + nWidth);
			m_MeasureListCtrl.SetColumnWidth(MEASURE_SITEM_S3,		IPC_MEASURE_COLUMN_S3 + nWidth);
			m_MeasureListCtrl.SetColumnWidth(MEASURE_SITEM_S4,		IPC_MEASURE_COLUMN_S4 + nWidth);
			m_MeasureListCtrl.SetColumnWidth(MEASURE_SITEM_TEMP,	IPC_MEASURE_COLUMN_TEMP + nWidth);

			m_MeasureListCtrl.Invalidate(FALSE);
		}
	}
}

void CMeasReportDlg::RedrawOutline(CDC* pDC)
{
	// Get Dialog Rect
	CRect rcClient;
	GetClientRect(&rcClient);

	// BackGround Color �� (Main Window Left, Right, Bottom ������ ä���
	CRect rcTemp(0, 0, 0, 0);

	CBrush brBack(m_clrBack);
	CBrush* pOldBrush = pDC->SelectObject(&brBack);

	// Top Area
	rcTemp.SetRect( rcClient.left, rcClient.top, rcClient.right, IPC_REPORT_TOP );	
	pDC->FillRect(rcTemp, &brBack);
	// Left Area
	rcTemp.SetRect( rcClient.left, rcClient.top, rcClient.left + IPC_REPORT_LEFT, rcClient.bottom );	
	pDC->FillRect(rcTemp, &brBack);
	// Right Area
	rcTemp.SetRect( rcClient.right - IPC_REPORT_LEFT, rcClient.top, rcClient.right, rcClient.bottom );
	pDC->FillRect(rcTemp, &brBack);
	// Bottom Area
	rcTemp.SetRect( rcClient.left, rcClient.bottom - IPC_REPORT_BOTTOM, rcClient.right, rcClient.bottom );
	pDC->FillRect(rcTemp, &brBack);
	// Bottom Area2
	rcTemp.SetRect( rcClient.left, rcClient.bottom, rcClient.right, rcClient.bottom + IPC_REPORT_BOTTOM );
	pDC->FillRect(rcTemp, &brBack);


	// Draw the OutLine of List Controls
	////////////////////////////////////////////////
	CBrush brOutline(m_clrOutline);
	CRect rcOutline;

	pDC->SelectObject(&brOutline);

	if (m_ResultListCtrl.m_hWnd != NULL && 
		m_MeasureListCtrl.m_hWnd != NULL )
	{
		// Draw Result List Outline
		m_ResultListCtrl.GetWindowRect(&rcOutline);
		ScreenToClient(&rcOutline);

		rcOutline.InflateRect(1,1);
		pDC->FrameRect(&rcOutline, &brOutline);

		m_MeasureListCtrl.GetWindowRect(&rcOutline);
		ScreenToClient(&rcOutline);

		rcOutline.InflateRect(1,1);
		pDC->FrameRect(&rcOutline, &brOutline);

	}

	pDC->SelectObject(pOldBrush);
}

void CMeasReportDlg::LoadReportHeader()
{
	if(pHistoryWnd)
	{
		CFileManager*	pManager = (CFileManager*)theApp.m_pFileManager;
		TCHAR	buffer[256];
		if(pManager)
		{
			CString	strHeader;
			strHeader.Empty();

			for(int i = 1; i <= IPC_HISTORY_FAILMARGIN_DATALINE; i++)
			{
				if(pManager->ReadLine((LPTSTR)pHistoryWnd->m_strFilePath.GetString(), 
										buffer, 
										i) != S_OK)
					return;

				CString	strLine = buffer;

				if(i == IPC_HISTORY_PRETEST_NAMELINE)
				{
					for(int num = 0; num < IPC_MAX_MATERIAL; num++)
					{
						strLine.Format(_T("\t%s\t: %.06lf\r\n"), 
										pHistoryWnd->m_resultData[num].strName,
										pHistoryWnd->m_resultData[num].lfResist);

						strHeader += strLine;
					}	
					i++;
				}
				else
				{
					strLine.Replace(_T(","), _T("\t"));
					strHeader += strLine;
				}
			}
		
			m_strReport[EN_EDIT_HEADER] = strHeader;
		}
	}
}

void CMeasReportDlg::LoadResultList()
{	
	m_strReport[EN_EDIT_DOCUMENT] = _T("");

	if(pHistoryWnd)
	{
		// ResultList ���� ����
		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			AddResultList(	i, 
							pHistoryWnd->m_resultData[i].strName,
							pHistoryWnd->m_resultData[i].lfResist,
							pHistoryWnd->m_resultData[i].failCount,
							pHistoryWnd->m_resultData[i].totalCount
							);
		}

		BFTFILE_MAP::iterator iter;
		SBFTFileData*	pBFT = NULL;
		int item = 0;
		for (iter = pHistoryWnd->m_BFTList.begin(); iter != pHistoryWnd->m_BFTList.end(); iter++)
		{
			pBFT = (SBFTFileData*)(*iter).second;
			if(pBFT)
			{
				for(int i = 0; i < IPC_MAX_MATERIAL; i++)
					pBFT->lfResist[i] = 0.0f;

				MATERIALDATA_MAP::iterator	iter2;
				SResistanceData* pdata = NULL;
				for(iter2 = pBFT->dataList.begin(); iter2 != pBFT->dataList.end(); iter2++)
				{
					pdata = (SResistanceData*)(*iter2).second;
					if(pdata)
						pBFT->lfResist[pdata->m_material - 1] = pdata->m_lfResist;
				}

				AddMeasureList(item++, pBFT->testTotalCount, pBFT->lfResist, pBFT->lfTemp);
			}
		}
	}

	UpdateData(FALSE);
}

BOOL CMeasReportDlg::AddResultList(short num, LPTSTR name, float lfResist, int failCount, long totalCount)
{
	CString	str[TRESULT_SITEM_MAX];

	str[TRESULT_SITEM_NAME] = name;
	str[TRESULT_SITEM_INITRESIST].Format(_T("%.6f"), lfResist);
	str[TRESULT_SITEM_FAILCOUNT].Format(_T("%ld"), failCount);
	str[TRESULT_SITEM_TOTALCOUNT].Format(_T("%ld"), totalCount);


	m_ResultListCtrl.InsertItem(num, str[TRESULT_SITEM_NAME]); 

	for(int i = TRESULT_SITEM_INITRESIST; i < TRESULT_SITEM_MAX; i++)
		m_ResultListCtrl.SetItemText(num, i, str[i]); 

	return S_OK;
}

BOOL CMeasReportDlg::AddMeasureList(int item, long totalcount, float* lfResist, float lfTemp)
{
	CString	str[MEASURE_SITEM_MAX];

	str[MEASURE_SITEM_COUNT].Format(_T("%ld"), totalcount);
	str[MEASURE_SITEM_S1].Format(_T("%.06f"), *(lfResist));
	str[MEASURE_SITEM_S2].Format(_T("%.06f"), *(lfResist + 1));
	str[MEASURE_SITEM_S3].Format(_T("%.06f"), *(lfResist + 2));
	str[MEASURE_SITEM_S4].Format(_T("%.06f"), *(lfResist + 3));
	str[MEASURE_SITEM_TEMP].Format(_T("%.01f"), lfTemp);

	m_MeasureListCtrl.InsertItem(item, str[MEASURE_SITEM_COUNT]); 

	for(int i = MEASURE_SITEM_S1; i < MEASURE_SITEM_MAX; i++)
		m_MeasureListCtrl.SetItemText(item, i, str[i]); 

	return S_OK;
}

BEGIN_MESSAGE_MAP(CMeasReportDlg, CDialog)
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_CLOSE()
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CMeasReportDlg �޽��� ó�����Դϴ�.

BOOL CMeasReportDlg::OnInitDialog()
{
	/*
	 *	Create Preference Controls & Set Properties	
	 *  Note: DDX/DDV�� �����Ǳ� ���� User Created Control�� �����Ѵ�.
	 */
	InitControl();

	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	CRect rcIpc;

	INT screenX = GetSystemMetrics(SM_CXSCREEN);
	INT screenY = GetSystemMetrics(SM_CYSCREEN);
	
	rcIpc.top = ( screenY - IPC_MAIN_MAX_HEIGHT ) / 2;
	rcIpc.left = ( screenX - IPC_MAIN_MAX_WIDTH ) / 2;
	rcIpc.bottom = rcIpc.top + IPC_MAIN_MAX_HEIGHT;
	rcIpc.right = rcIpc.left + IPC_MAIN_MAX_WIDTH;

	SetWindowPos(NULL, rcIpc.left, rcIpc.top, rcIpc.Width(), rcIpc.Height(), SWP_HIDEWINDOW);

	Localize();			//Initialize Control Captions
	LocalizeFont();		//Initialize Font Info

	SetPosition();

	LoadReportHeader();
	LoadResultList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CMeasReportDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	SetPosition();
	CDC*	pDC = GetDC();
	RedrawOutline(pDC);
	ReleaseDC(pDC);
}

void CMeasReportDlg::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialog::OnSizing(fwSide, pRect);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	int nFixedWidth = IPC_REPORT_MIN_WIDTH;
	int nFixedHeight = IPC_REPORT_MIN_HEIGHT;

	int nWidth, nHeight;
	nWidth = abs(pRect->right - pRect->left);
	nHeight = abs(pRect->bottom - pRect->top);
	switch(fwSide) 
	{
	case 2: 
	case 6: 
	case 8: 
		if (nWidth < nFixedWidth)
			pRect->right = pRect->left + nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->bottom = pRect->top + nFixedHeight;
		break;
	case 1: 
	case 3: 
	case 4: 
		if (nWidth < nFixedWidth)
			pRect->left = pRect->right - nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->top = pRect->bottom - nFixedHeight;
		break;
	case 5: 
		if (nWidth < nFixedWidth)
			pRect->right = pRect->left + nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->top = pRect->bottom - nFixedHeight;
		break;
	case 7: 
		if (nWidth < nFixedWidth)
			pRect->left = pRect->right - nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->bottom = pRect->top + nFixedHeight;
		break;
	default:
		return;
	}

	if (nWidth < nFixedWidth || nHeight < nFixedHeight)
		SetWindowPos(NULL, pRect->left, pRect->right, nWidth, nHeight, SWP_NOSIZE | SWP_NOMOVE);
}

void CMeasReportDlg::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialog::OnClose();
}

BOOL CMeasReportDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if (pMsg->message == WM_MOUSEMOVE) 
		m_ToolTipCtrl.RelayEvent(pMsg);	

	return CDialog::PreTranslateMessage(pMsg);
}

void CMeasReportDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialog::OnPaint()��(��) ȣ������ ���ʽÿ�.
	RedrawOutline(&dc);
	m_ResultListCtrl.RedrawWindow( );
	m_MeasureListCtrl.RedrawWindow( );
}
