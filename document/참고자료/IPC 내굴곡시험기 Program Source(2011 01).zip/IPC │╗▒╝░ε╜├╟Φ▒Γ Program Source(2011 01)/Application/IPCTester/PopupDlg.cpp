// PopupDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "PopupDlg.h"


// CPopupDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CPopupDlg, CDialog)

CPopupDlg::CPopupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPopupDlg::IDD, pParent)
{
	m_clrText = PALETTERGB(255, 0, 0);		// red

	m_idCaption = 0;
	m_idMessage = 0;
	m_idOK = 0;
	m_idCancel = 0;

}

CPopupDlg::~CPopupDlg()
{
	m_fontMessage.DeleteObject();
}

void CPopupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CPopupDlg::InitControl()
{
	CRect	rcTemp(0,0,0,0);

	// Set Font & Color
	//////////////////////////////////////////////////////////////////////////
	LOGFONT lf;
	CFont	*pFont, *pBoldFont;

	pFont = thePrefs.GetGUIDefault();

	pBoldFont = thePrefs.GetGUIDefaultBold();
	pFont->GetLogFont(&lf);


	// Create Font for Title Text
	//////////////////////////////////////////////////////////////////////////
	const int PointSize = 11;

	HDC hDC = ::GetDC(NULL);

	lf.lfHeight = -::MulDiv(PointSize, ::GetDeviceCaps(hDC, LOGPIXELSY), 72);
	lf.lfWeight = FW_BOLD;

	m_fontMessage.CreateFontIndirect(&lf);

	// Main Windows Position
	CRect rcClient;
	GetClientRect(&rcClient);

	m_stMessage.Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, rcTemp, this);
	m_stMessage.SetAlign(DT_CENTER | DT_VCENTER /*| DT_SINGLELINE*/);
	m_stMessage.SetTransparent();

	// OK Button
	m_btnOK.SetImageList(theResMan.GetImageListRes(IPC_RESMAN_BTN_OK), 0);
	m_btnOK.Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
					rcTemp, this, IDOK);	
	m_btnOK.SetTransparent();

	// Cancel Button
	m_btnCancel.SetImageList(theResMan.GetImageListRes(IPC_RESMAN_BTN_CANCEL), 0);
	m_btnCancel.Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
					rcTemp, this, IDCANCEL);	
	m_btnCancel.SetTransparent();

	m_stMessage.SetFont(&m_fontMessage);
	m_stMessage.SetFontColor(m_clrText);

	if(m_idCaption)
		SetWindowText(GetResString(m_idCaption));
}

void CPopupDlg::InitPos()
{
	if (m_stMessage.m_hWnd && m_btnOK.m_hWnd && m_btnCancel.m_hWnd)
	{
		int nCtrlWidth = 200;
		int	nCtrlHeight = 60;

		CRect	rcClient, rcTemp(0, 0, 0, 0);
		int		nCtrlIntv = 30, nLineIntv = 10;

		GetClientRect(&rcClient);

		// Set Message Pos
		/////////////////////////////////////////////////////////
		rcTemp.left		= IPC_POPUP_LEFT;
		rcTemp.right	= rcClient.right - IPC_POPUP_LEFT;
		rcTemp.top		= IPC_POPUP_TOP;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;

		m_stMessage.MoveWindow(&rcTemp, FALSE);
		m_stMessage.SetCaption(_T(""));
		if(m_idMessage)
			m_stMessage.SetCaption(GetResString(m_idMessage));

		m_stMessage.ShowWindow( SW_SHOW );


		// Set OK Button Ctrl Pos
		/////////////////////////////////////////////////////////
		{
		CRect	rcImg;
		IMAGEINFO	ImgInfo;
		CImageList* pImgList = theResMan.GetImageListRes(IPC_RESMAN_BTN_OK);
		if(m_idOK)
			pImgList = theResMan.GetImageListRes(m_idOK);
		pImgList->GetImageInfo(0, &ImgInfo);
		rcImg = ImgInfo.rcImage;

		int nLeft = (rcClient.Width() - (rcImg.Width() * 2 + nCtrlIntv)) / 2;

		rcTemp.bottom	= rcClient.bottom - IPC_POPUP_BOTTOM;
		rcTemp.top		= rcTemp.bottom - rcImg.Height();
		rcTemp.left		= nLeft;
		rcTemp.right = rcTemp.left + rcImg.Width();

		m_btnOK.SetImageList(pImgList, 0);
		m_btnOK.MoveWindow(&rcTemp, FALSE);
		m_btnOK.ShowWindow( SW_SHOW );
		}

		// Set Cancel Button Ctrl Pos
		/////////////////////////////////////////////////////////
		{
		CRect	rcImg;
		IMAGEINFO	ImgInfo;
		CImageList* pImgList = theResMan.GetImageListRes(IPC_RESMAN_BTN_CANCEL);
		if(m_idCancel)
			pImgList = theResMan.GetImageListRes(m_idCancel);
		pImgList->GetImageInfo(0, &ImgInfo);
		rcImg = ImgInfo.rcImage;

		int nLeft = (rcClient.Width() - (rcImg.Width() * 2 + nCtrlIntv)) / 2;

		rcTemp.bottom	= rcClient.bottom - IPC_POPUP_BOTTOM;
		rcTemp.top		= rcTemp.bottom - rcImg.Height();
		rcTemp.left		= rcClient.right - (rcImg.Width() + nLeft);
		rcTemp.right	= rcTemp.left + rcImg.Width();

		m_btnCancel.SetImageList(pImgList , 0);
		m_btnCancel.MoveWindow(&rcTemp, FALSE);
		m_btnCancel.ShowWindow( SW_SHOW );
		}
	}
}

BEGIN_MESSAGE_MAP(CPopupDlg, CDialog)
END_MESSAGE_MAP()


// CPopupDlg �޽��� ó�����Դϴ�.

BOOL CPopupDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	InitControl();

	HDC hDC		  = ::GetDC( ::GetDesktopWindow() );
	int	scrWidth  = ::GetDeviceCaps(hDC,HORZRES);
	int scrHeight = ::GetDeviceCaps(hDC,VERTRES);
	::ReleaseDC( ::GetDesktopWindow(), hDC );
	
	CRect rcClient;
	GetClientRect(&rcClient);

	MoveWindow(scrWidth/2 - rcClient.Width()/2, scrHeight/2 - rcClient.Height()/2, 
				rcClient.Width(), rcClient.Height());

	InitPos();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}
