#pragma once
#include "ctrl/static/static.h"

#define IPC_USERPOPUP_TOP				15
#define IPC_USERPOPUP_LEFT				15
#define IPC_USERPOPUP_BOTTOM			15

// CUserPopup ��ȭ �����Դϴ�.

class CUserPopup : public CDialog
{
	DECLARE_DYNAMIC(CUserPopup)

public:
	CUserPopup(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CUserPopup();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_USERPOPUP };

	void	SetMessage(CString msg)		{ 
											m_stMessage = msg; 
											m_ctrlMessage.SetCaption(m_stMessage);
										}

	void	InitControl();
	void	InitPos();

public:
	COLORREF	m_clrText;
	CFont		m_fontMessage;
	cXenStatic	m_ctrlMessage;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CString m_stMessage;
protected:
	virtual void OnOK();
public:
	afx_msg void OnClose();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};
