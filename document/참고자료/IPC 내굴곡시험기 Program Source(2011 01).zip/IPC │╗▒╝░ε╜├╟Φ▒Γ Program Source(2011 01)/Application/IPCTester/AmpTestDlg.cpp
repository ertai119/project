// AmpTestDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "AmpTestDlg.h"


// CAmpTestDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CAmpTestDlg, CDialog)

CAmpTestDlg::CAmpTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAmpTestDlg::IDD, pParent)
{
	m_clrBack		= PALETTERGB(254,254,246);	
	m_clrText		= PALETTERGB(0,0,0);			// BLACK
	m_clrValue		= PALETTERGB(255, 0, 0);		// RED
	m_clrMask		= PALETTERGB(255,0,255);		// PINK

}

CAmpTestDlg::~CAmpTestDlg()
{
}

//void CAmpTestDlg::DoDataExchange(CDataExchange* pDX)
//{
//	CDialog::DoDataExchange(pDX);
//}

//void CAmpTestDlg::Localize()
//{
//}
//
//void CAmpTestDlg::LocalizeFont()
//{
//	CFont *pFont = thePrefs.GetGUIDefault();
//	CFont*	m_fontBold = thePrefs.GetGUIDefaultBold();
//
//	for (int i = 0; i < EN_STATIC_MAX; i++)
//		m_stAmp[i].SetFont(pFont);	
//}
//
//void CAmpTestDlg::InitPos()
//{
//	CRect	rcClient;
//	GetClientRect(&rcClient);
//
//	if (m_stConfig[0].m_hWnd && m_btnStop.m_hWnd)
//	{
//		int nCtrlWidth = 60;
//		int	nCtrlHeight = 20;
//		int	nCtrlIntv = 10, nLineIntv = 9, nOffSet = 10;
//
//		CRect	rcTemp(0,0,0,0);
//
//
//		// ���� Static Pos
//		rcTemp.left		= IPC_CONFIG_EDIT_STARTX - 91;
//		rcTemp.top		= rcTemp.top + 108;
//		rcTemp.right	= rcTemp.left + nCtrlWidth;
//		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
//		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
//		{
//			m_stConfig[i].MoveWindow(&rcTemp, FALSE);
//
//			rcTemp.left		= rcTemp.right + 5;
//			rcTemp.right	= rcTemp.left + nCtrlWidth;
//		}
//
//		// �������� Button Position
//		//////////////////////////////
//		{
//			CRect rcBtn;
//			m_btnStop.GetWindowRect(&rcBtn);
//		
//			int w = rcBtn.Width();
//			int h = rcBtn.Height();
//
//			rcBtn.left = rcTemp.left + 20;
//			rcBtn.top = rcTemp.top - 20;
//			rcBtn.right = rcBtn.right + w;
//			rcBtn.bottom = rcBtn.top + h;
//
//			m_btnStop.MoveWindow(&rcBtn, FALSE);
//			m_btnStop.Invalidate(FALSE);
//			m_btnStop.ShowWindow(SW_SHOW);
//		}
//	}
//}
//
//void CAmpTestDlg::InitControl()
//{
//	CRect	rcTemp(0,0,0,0);
//
//	// Create Stop Buttons 
//	//////////////////////////////////////////////////////////////////////////////////
//	CImageList*	pImageList = NULL;
//	pImageList = theResMan.GetImageListRes(IPC_RESMAN_BTN_TEST_STOP);
//
//	IMAGEINFO	imgInfo;
//	CRect	rcRect;
//	pImageList->GetImageInfo(1, &imgInfo);
//	rcRect = imgInfo.rcImage;
//
//	m_btnStop.SetImageList(pImageList, 0);
//	m_btnStop.Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
//						rcRect, this, IDC_AMPTEST_BTN_STOP);
//	m_btnStop.SetTransparent();
//
//
//	short pwidth = 60;
//	for (int i = EN_STATIC_AMP; i < EN_STATIC_MAX; i++)
//	{
//		m_stAmp[i].Create(NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | SS_OWNERDRAW, 
//							CRect(0, 0, pwidth, 20), this, IDC_AMPTEST_STATIC_AMP + i);
//		m_stAmp[i].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
//		m_stAmp[i].SetFontColor( m_clrText );	
//		m_stAmp[i].SetCaption( _T("") );
//	}
//}
//
//void CAmpTestDlg::DrawGraphicArea(CDC* pDC)
//{
//
//}


BEGIN_MESSAGE_MAP(CAmpTestDlg, CDialog)
	ON_WM_CLOSE()
END_MESSAGE_MAP()


//// CAmpTestDlg �޽��� ó�����Դϴ�.
//
//BOOL CAmpTestDlg::OnInitDialog()
//{
//	CDialog::OnInitDialog();
//
//	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
//	// Set Config Window Size & Pos
//	//////////////////////////////////////////////////////
//	HDC hDC		  = ::GetDC( ::GetDesktopWindow() );
//	int	scrWidth  = ::GetDeviceCaps(hDC, HORZRES);
//	int scrHeight = ::GetDeviceCaps(hDC, VERTRES);
//	::ReleaseDC( ::GetDesktopWindow(), hDC );
//
//	CRect rcClient;
//	GetClientRect(&rcClient);
//
//	MoveWindow(scrWidth/2 - rcClient.Width()/2, scrHeight/2 - rcClient.Height()/2, 
//		rcClient.Width(), rcClient.Height(), FALSE);
//
//	return TRUE;  // return TRUE unless you set the focus to a control
//	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
//}
//
//void CAmpTestDlg::OnOK()
//{
//	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
//
//	CDialog::OnOK();
//}

//void CAmpTestDlg::OnClose()
//{
//	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
//
//	CDialog::OnClose();
//}
