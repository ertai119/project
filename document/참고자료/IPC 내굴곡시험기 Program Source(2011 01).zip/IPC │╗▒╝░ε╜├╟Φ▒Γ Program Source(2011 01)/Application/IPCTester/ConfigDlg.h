#pragma once
#include "Ctrl/static/static.h"
#include "Ctrl/Button/XenButton.h"

#define IPC_CONFIG_TITLEBAR_HEIGHT	30

#define IPC_CONFIG_WIDTH			648
#define IPC_CONFIG_HEIGHT			435

#define IPC_CONFIG_VINTERVAL		10
#define IPC_CONFIG_HINTERVAL		10

#define IPC_CONFIG_TOP				IPC_CONFIG_TITLEBAR_HEIGHT
#define IPC_CONFIG_LEFT				20
#define IPC_CONFIG_BOTTOM			20

#define IPC_CONFIG_EDIT_STARTX		120
#define IPC_CONFIG_EDIT_STARTY		63


// CConfigDlg ��ȭ �����Դϴ�.

class CConfigDlg : public CDialog
{
	DECLARE_DYNAMIC(CConfigDlg)

public:
	CConfigDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CConfigDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_CONFIGDLG };

	// Check Box
	enum {	EN_CHECK_S1 = 0, 
			EN_CHECK_S2, 
			EN_CHECK_S3, 
			EN_CHECK_S4, 
			EN_CHECK_USED, 
			EN_CHECK_MAX 
		};
	// Text Edit
	enum {	EN_EDIT_TEMP	= 0, 
			EN_EDIT_ALLOWABLE, 
			EN_EDIT_BENDING, 
			EN_EDIT_AMP, 
			EN_EDIT_FAIL, 
			EN_EDIT_INTERVAL,
			EN_SPIN_MAX,						// 6
			EN_EDIT_TESTCOUNT = EN_SPIN_MAX,	// 6
			EN_EDIT_S1,
			EN_EDIT_S2,
			EN_EDIT_S3,
			EN_EDIT_S4,
			EN_EDIT_FILENAME,
			EN_EDIT_MAX 
		};
	// Define Button ID Enum
	enum {	EN_BTN_BFSTART = 0,
			EN_BTN_BFSTOP,
			EN_BTN_AUTOSTART,
			EN_BTN_NOTSTART,
			EN_BTN_PRETEST,
			EN_BTN_FOLDER,
			EN_BTN_MAX
		};
	// Define Static Enum
	enum {	EN_STATIC_S1	= 0,
			EN_STATIC_S2,
			EN_STATIC_S3,
			EN_STATIC_S4,
			EN_STATIC_FOLDER,
			EN_STATIC_MAX
		};

	int		GetInitTemp()			{ return m_iRange[EN_EDIT_TEMP]; }	
	short	GetAllowableTemp()		{ return m_iRange[EN_EDIT_ALLOWABLE]; }
	int		GetBendingSpeed()		{ return m_iRange[EN_EDIT_BENDING]; }
	short	GetAmplitude()			{ return m_iRange[EN_EDIT_AMP]; }	
	int		GetFailPercent()		{ return m_iRange[EN_EDIT_FAIL]; }	
	float	GetTestInterval()		{ return m_fInterval; }				

	int		GetTestStopCount();			

	BOOL	IsUsedTestCount()		{ return m_bCheckInfo[EN_CHECK_USED]; }

	void	SetDisable()			{ bDisable = TRUE; }
protected:
	COLORREF	m_clrBack, m_clrText, m_clrValue, m_clrMask;

	// Config Image
	CImageList		m_ImgConfig;
	BOOL			m_bInitConfig;

	cXenButton		m_btnConfig[EN_BTN_MAX], m_chkConfig[EN_CHECK_MAX];
	cXenStatic		m_stConfig[EN_STATIC_MAX];
	CEdit			m_editConfig[EN_EDIT_MAX];
	CSpinButtonCtrl m_spinConfig[EN_SPIN_MAX];

	cXenButton		m_btnWindowClose;

	BOOL			bDisable;

	bool			m_bAutoStart;
	BOOL			m_bCheckInfo[EN_CHECK_MAX];
	float			m_fResistance[IPC_MAX_MATERIAL];

	CToolTipCtrl	m_ToolTipCtrl;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL PreTranslateMessage( MSG* pMsg );
	virtual void OnOK();
	virtual void OnCancel();

	afx_msg void OnBnClickedCommand(UINT ID);
	afx_msg void OnEnKillFocusEdit(UINT ID);

	afx_msg HRESULT OnAMPTest( WPARAM wParam, LPARAM lParam );
	afx_msg HRESULT OnPreTest( WPARAM wParam, LPARAM lParam );

	void	Localize();
	void	LocalizeFont();
	void	InitControl();
	void	InitConfig();
	void	InitPos();
	void	DrawTitleBar( CDC *pDC );

	void	UpdatePreference();
	void	UpdateAutoStart();

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();

	float			m_iRange[EN_SPIN_MAX - 1];
	float			m_fInterval;
	DWORD			m_iStopCount;
	CString			m_strEdit[EN_EDIT_MAX];

	afx_msg void OnPaint();
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnDeltaposSpinInterval(NMHDR *pNMHDR, LRESULT *pResult);
};
