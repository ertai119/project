#pragma once
#include "Ctrl/Button/XenButton.h"
#include "Ctrl/static/static.h"

#define IPC_AMPTEST_TOP				15
#define IPC_AMPTEST_LEFT			15
#define IPC_AMPTEST_BOTTOM			10

#define IPC_AMPTEST_GRAPH_STARTX	73

#define IPC_AMPTEST_GRAPH_WIDTH		330
#define IPC_AMPTEST_GRAPH_HEIGHT	170

#define IPC_AMPTEST_BUTTON_TOP		215

#define IPC_AMPTEST_GRAPH_XPOINTS		33
//#define	IPC_AMPTEST_GRAPH_YPOINTS		30
#define	IPC_AMPTEST_GRAPH_YPOINTS		35


// CAmplitudeDlg ��ȭ �����Դϴ�.

class CAmplitudeDlg : public CDialog
{
	DECLARE_DYNAMIC(CAmplitudeDlg)

public:
	CAmplitudeDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CAmplitudeDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_AMPLITUDEDLG };
	// Define Static Enum
	enum {	EN_STATIC_DEF_AMP = 0,
			EN_STATIC_DEF_CURRAMP,
			EN_STATIC_AMP,
			EN_STATIC_AMP_CURRENT,
			EN_STATIC_MAX,
		};

	void	SetAmplitude(int val)		{ m_amplitude = val; }

protected:
	COLORREF	m_clrBack, m_clrText, m_clrValue, m_clrMask;

	cXenButton	m_btnStop;
	cXenStatic	m_stAmp[EN_STATIC_MAX];

	float		m_ampData[IPC_AMPTEST_GRAPH_XPOINTS + 1];
	CPoint		ptAmplitude[IPC_AMPTEST_GRAPH_XPOINTS + 1];
	long		m_testCount;
	LONGLONG	m_reqCount;

	int			m_amplitude;
	bool		m_bTestStop;
	bool		m_bStopCommand;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	afx_msg HRESULT OnAMPTest( WPARAM wParam, LPARAM lParam );

	void	Localize();
	void	LocalizeFont();
	void	InitControl();
	void	InitPos();

	void	DrawGraphicArea(CDC* pDC);
	void	OnTestStop();

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
