// IPCTesterDlg.h : ��� ����
//

#pragma once

#include "ConfigDlg.h"
#include "IPCLoad.h"			// Loading Window
#include "ResistanceWnd.h"
#include "StatusWnd.h"			// Status Window
#include "AmplitudeDlg.h"
#include "MeasHistoryDlg.h"

#include "UserPopup.h"

#include "ctrl/button/XenButton.h"

//	Windows Show Button Status ����
#define	MAX_WINDOW_SHOWBTN			3

#define IPC_WINDOW_TITLE_HEIGHT		25

#define IPC_MAIN_DISPLAY_TOP			IPC_WINDOW_TITLE_HEIGHT
#define IPC_MAIN_DISPLAY_HEIGHT			38
#define IPC_MAIN_DISPLAYLINE_HEIGHT		21

#define IPC_MAIN_LEFT				3		// Left 
#define IPC_MAIN_RIGHT				3		// Right
#define IPC_MAIN_TOP				1		// Top 
#define IPC_MAIN_HEIGHT				63		// Main Title Draw Area Height (25 + 38 + 21)

#define IPC_MAIN_BTN_INTERVAL		5		// Button ����

#define IPC_MAIN_MAX_WIDTH			1024	// Max Width Size
#define IPC_MAIN_MAX_HEIGHT			768

#define IPC_MAIN_MIN_WIDTH			850		// Min Width Size
#define IPC_MAIN_MIN_HEIGHT			750

// Menu ��ǥ 
#define IPC_MAIN_MENU_HEIGHT		60

// Main Window ��ǥ 
#define IPC_MAIN_WINDOW_LEFT		15
#define IPC_MAIN_WINDOW_TOP			IPC_MAIN_HEIGHT + 21
#define IPC_MAIN_WINDOW_BOTTOM		15			// Status Window Height

// Measurement Monitoring Window ��ǥ 
#define IPC_MEASURE_WINDOW_LEFT		15
#define IPC_MEASURE_WINDOW_TOP		IPC_MAIN_WINDOW_TOP + 3
#define IPC_MEASURE_WINDOW_BOTTOM	IPC_MAIN_WINDOW_BOTTOM + IPC_MAIN_MENU_HEIGHT


enum IPCMainMenu
{ 
	IPC_POPUP_BTN_TESTSTART = 0,		
	IPC_POPUP_BTN_TESTSTOP,				
	IPC_POPUP_BTN_TESTREPORT,			

	IPC_POPUP_BTN_PREFERENCES,			
	IPC_POPUP_BTN_EXIT,					

	IPC_MAX_POPUP_BTN
};

// CIPCTesterDlg ��ȭ ����
class CIPCTesterDlg : public CDialog
{
	friend class CIPCTesterApp;

// ����
public:
	CIPCTesterDlg(CWnd* pParent = NULL);	// ǥ�� ������
	~CIPCTesterDlg();


// ��ȭ ���� ������
	enum { IDD = IDD_IPCTESTER_DIALOG };

	enum { WS_NORMAL = 0, WS_DOING, WS_MAXIMIZED };
	enum { BFT_TEMP = 0, BFT_TOTAL, BFT_CURRENT, BFT_MAX };

	CStatusWnd*	GetStatusWindow()		{ return m_pStatusWnd; }

	int  ShowHistoryDlg(LPARAM pParam);
	bool IsHistoryDlgOpen() const;
	int  ShowPreferences();
	bool IsPreferencesDlgOpen() const;
	int  ShowAmpTestDlg(int amp);
	bool IsAmpTestDlgOpen() const;
	bool CanClose();

	int	 IPCMessageBox(UINT nIDPrompt, UINT nIDCaption, UINT nType=0, UINT nIDHelp=(UINT)-1);
	int  IPCMessageBox(LPCTSTR lpszText, LPCTSTR lpszCaption, UINT nType=0, UINT nIDHelp=(UINT)-1);

	//void OLEDBCompaction();		// DB Compaction

	CResistanceWnd* GetResistanceWnd(short index)	{ return m_pResistanceWnd[index]; }
	void SetMeasurementWndPosition();
	void SetStatusWndPosition();

	void StartConnection(bool remote = false);
	void CloseConnection(short exitflag = false);

	void OnStartSerialThread();
	void OnCloseSerialThread();


	void UpdateIPCCount();


	void SetTopMostWindow(BOOL bTopMost = FALSE);

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

	virtual void OnOK()  {};;
	virtual void OnCancel() {};

protected:
	CString			m_strTooltip;

	CToolTipCtrl	m_ToolTipCtrl;
	CWnd*			activewnd;

	ULONG			m_lTotalCount;
	ULONG			m_lCurrentCount;

	cXenStatic		m_stUpdate[BFT_MAX];	
	cXenStatic		m_stStatus[BFT_MAX];

	cXenButton		m_btnWindowShow[MAX_WINDOW_SHOWBTN];

	// Main Button Decralation
	cXenButton		m_btnMenuCtrl[IPC_MAX_POPUP_BTN];

	bool			m_bShowMessageBox;
	BOOL			m_bMax_status;
	bool			m_bGUIStart;

	CResistanceWnd*		m_pResistanceWnd[IPC_MAX_MATERIAL];
	CStatusWnd*			m_pStatusWnd;			// Status Window

	CFont			m_fontValue;

public:
	CMeasHistoryDlg*	m_pHistoryWnd;		
	CConfigDlg*			m_pPrefsWnd;		
	CAmplitudeDlg*		m_pAmpTestWnd;		

	CUserPopup*			m_pUserPopup;

// ����
protected:
	HICON m_hIcon;

	COLORREF	m_clrText, m_clrBack, m_clrValue, m_crMask, m_clrOutline; //Set Window Backgroud & Text Color

	void InitControl();
	void Localize();
	void LocalizeFont();

	void DrawTitleBar( CDC *pDC, BOOL bPaint = true );
	void DrawMenuButton( CDC *pDC, BOOL bPaint = true );

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnBnClickedMinimize( );
	afx_msg void OnBnClickedClose( );
	afx_msg void OnBnClickedMaximize( );

	afx_msg HRESULT OnIPCClose( WPARAM wParam, LPARAM lParam );
	afx_msg HRESULT ShowHistoryDialog(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT ShowPrefsDialog(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT ShowAmpTestDialog(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT OnTempDisplay(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT OnBFTestCountDisplay(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT OnPreTestResistance(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT OnBFTestCreateFile(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT OnBFTestResistance(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT OnBFTestDisplay(WPARAM wParam, LPARAM lParam);

	afx_msg HRESULT ShowUserPopup(WPARAM wParam, LPARAM lParam);
	afx_msg HRESULT UserPopupOK(WPARAM wParam, LPARAM lParam);

	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg BOOL OnNcActivate(BOOL bActive);
	afx_msg void OnNcLButtonDblClk(UINT nHitTest, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnClose();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
