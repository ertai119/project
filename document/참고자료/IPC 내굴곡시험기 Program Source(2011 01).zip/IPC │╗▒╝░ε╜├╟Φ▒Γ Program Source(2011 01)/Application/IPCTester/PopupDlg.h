#pragma once

#include "ctrl/static/static.h"
#include "ctrl/button/Xenbutton.h"

#define IPC_POPUP_TOP				15
#define IPC_POPUP_LEFT				15
#define IPC_POPUP_BOTTOM			15

// CPopupDlg ��ȭ �����Դϴ�.

class CPopupDlg : public CDialog
{
	DECLARE_DYNAMIC(CPopupDlg)

public:
	CPopupDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CPopupDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_POPUPDLG };

	void SetPopupParam(UINT idCaption, UINT idMessage, UINT idOK, UINT idCancel)
	{
		m_idCaption = idCaption;
		m_idMessage = idMessage;
		m_idOK		= idOK;
		m_idCancel	= idCancel;
	}

protected:
	COLORREF	m_clrText;

	cXenStatic	m_stMessage;

	cXenButton	m_btnOK;
	cXenButton	m_btnCancel;

	CFont		m_fontMessage;

	UINT		m_idCaption;
	UINT		m_idMessage;
	UINT		m_idOK;
	UINT		m_idCancel;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	void InitControl();
	void InitPos();

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};
