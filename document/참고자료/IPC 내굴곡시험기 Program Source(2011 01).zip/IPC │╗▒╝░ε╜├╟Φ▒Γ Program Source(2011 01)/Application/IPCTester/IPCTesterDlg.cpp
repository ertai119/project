// IPCTesterDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "IPCTester.h"
#include "IPCTesterDlg.h"

//#include "WaitDialog.h"
#include "PopupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� �ڵ� ����
extern HWND		g_IPCHandle;
extern TCHAR	g_sParam[];


#define IPC_STARTCONNECTION_TIMER		1001

// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ȭ ���� ������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ����

// ����
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CIPCTesterDlg ��ȭ ����



CIPCTesterDlg::CIPCTesterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIPCTesterDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_strTooltip = "BF Tester Monitoring System";

	// Dialog Background Color
	m_clrBack		= IPC_BACKGROUND_COLOR;		// BackGround Color

	m_clrText		= PALETTERGB( 255, 255, 255);
	m_clrValue		= PALETTERGB( 255, 0, 0);		// RED
	m_crMask		= PALETTERGB( 255, 0, 255 );
	m_clrOutline	= PALETTERGB( 194, 193, 193);

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		m_pResistanceWnd[i] = NULL;

	m_pStatusWnd = NULL;
	m_pPrefsWnd = NULL;
	m_pAmpTestWnd = NULL;
	m_pHistoryWnd = NULL;
	m_pUserPopup = NULL;

	activewnd = NULL;

	m_bGUIStart = false;
	m_bMax_status = WS_NORMAL;
	m_lTotalCount = 0;
	m_lCurrentCount = 0;

}

CIPCTesterDlg::~CIPCTesterDlg()
{
	m_fontValue.DeleteObject();
	if (m_pUserPopup)
	{
		if (::IsWindow(m_pUserPopup->GetSafeHwnd()))
			m_pUserPopup->EndDialog(IDCANCEL);

		delete m_pUserPopup;
	}
}

void CIPCTesterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CIPCTesterDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP

	ON_MESSAGE(UM_IPC_CLOSE,			OnIPCClose)
	ON_MESSAGE(UM_IPC_HISTORYDIALOG,	ShowHistoryDialog)
	ON_MESSAGE(UM_IPC_PREFSDIALOG,		ShowPrefsDialog)
	ON_MESSAGE(UM_IPC_AMPTESTDIALOG,	ShowAmpTestDialog)
	ON_MESSAGE(UM_IPC_USERDIALOG,		ShowUserPopup)
	ON_MESSAGE(UM_IPC_USERDIALOG_OK,	UserPopupOK)
	
	
	ON_MESSAGE(UM_IPC_MEAS_TEMP,		OnTempDisplay)
	ON_MESSAGE(UM_IPC_MEAS_CURRENTCOUNT,OnBFTestCountDisplay)
	ON_MESSAGE(UM_IPC_MEAS_TOTALCOUNT,	OnBFTestCountDisplay)
	ON_MESSAGE(UM_IPC_MEAS_PRETEST,		OnPreTestResistance)
	
	ON_MESSAGE(UM_IPC_MEAS_CREATEFILE,	OnBFTestCreateFile)
	ON_MESSAGE(UM_IPC_MEAS_RESISTANCE,	OnBFTestResistance)
	ON_MESSAGE(UM_IPC_MEAS_DISPLAY,		OnBFTestDisplay)

	ON_BN_CLICKED(IDC_WINDOW_CLOSE,		OnBnClickedClose)
	ON_BN_CLICKED(IDC_WINDOW_MIN,		OnBnClickedMinimize)
	ON_BN_CLICKED(IDC_WINDOW_MAX,		OnBnClickedMaximize)


	ON_WM_NCACTIVATE()
	ON_WM_NCLBUTTONDBLCLK()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_NCHITTEST()
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_CLOSE()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CIPCTesterDlg �޽��� ó����

BOOL CIPCTesterDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	// �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	// Window ���� Create 
	// set title
	//SetWindowText(GetResString(IDS_IPC_CAPTION));				// Window Title
	SetWindowText(GetResString(IDS_IPC_CAPTION) + _T(" v") + theApp.m_strCurVersionLong);

	CRect rcIpc;

	INT screenX = GetSystemMetrics(SM_CXSCREEN);
	INT screenY = GetSystemMetrics(SM_CYSCREEN);
	
	rcIpc.top = ( screenY - IPC_MAIN_MAX_HEIGHT ) / 2;
	rcIpc.left = ( screenX - IPC_MAIN_MAX_WIDTH ) / 2;
	rcIpc.bottom = rcIpc.top + IPC_MAIN_MAX_HEIGHT;
	rcIpc.right = rcIpc.left + IPC_MAIN_MAX_WIDTH;

#ifdef _DEBUG
	SetWindowPos(NULL, rcIpc.left, rcIpc.top, rcIpc.Width(), rcIpc.Height(), SWP_HIDEWINDOW);
#else
	SetWindowPos(&wndTopMost, rcIpc.left, rcIpc.top, rcIpc.Width(), rcIpc.Height(), SWP_HIDEWINDOW);
#endif

	theApp.m_appStatus = APPSTATUS_APPRUNNING;
	
	theApp.Log(FALSE, _T("BFT Monitoring System Start !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));

	CIPCLoad	ipcLoadDlg;
	ipcLoadDlg.SetBFTotalCount(thePrefs.GetTestTotalCount());
	ipcLoadDlg.DoModal();

	InitControl();
	Localize();
	LocalizeFont();

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
	{
		m_pResistanceWnd[i] = new CResistanceWnd;
		m_pResistanceWnd[i]->SetMaterialNum(i);		// zero base
		m_pResistanceWnd[i]->Create(NULL, NULL, WS_CHILD | WS_VISIBLE, CRect(0, 0, 0, 0), this, ID_IPC_WINDOW_RESISTANCE);
	}

	m_pStatusWnd = new CStatusWnd(this);
	m_pStatusWnd->Create(IDD_STATUSWND);

	SetStatusWndPosition();
	SetMeasurementWndPosition();


	SetTopMostWindow(TRUE);
	ShowWindow(SW_SHOW);

	activewnd = m_pStatusWnd;

	UpdateWindow();

	theApp.m_pFileManager->Start(this);

	OnStartSerialThread();

	m_bGUIStart = true;
	SetTopMostWindow(FALSE);

	StartConnection();

	return TRUE;  // ��Ʈ�ѿ� ���� ��Ŀ���� �������� ���� ��� TRUE�� ��ȯ�մϴ�.
}

void CIPCTesterDlg::Localize()
{
	SetWindowText(GetResString(IDS_IPC_CAPTION) + _T(" v") + theApp.m_strCurVersionLong);

	for( int i = 0; i < MAX_WINDOW_SHOWBTN; i++ )
	{
		m_ToolTipCtrl.UpdateTipText(IDS_MAIN_TOOLTIP_WINDOWCLOSE + i, (CWnd *)&m_btnWindowShow[i]);
	}

	for( int i = 0; i < BFT_MAX; i++ )
	{		
		m_stStatus[ i ].SetCaption( GetResString( IDS_MAIN_STATIC_TEMP + i ) );
		m_stUpdate[ i ].SetCaption(_T("0"));
	}

	CString strCount = theApp.ConvertStrValue(thePrefs.GetTestTotalCount());
	m_stUpdate[BFT_TOTAL].SetCaption(strCount);
}

void CIPCTesterDlg::LocalizeFont()
{
	LOGFONT lf;
	CFont*	pFont;

	pFont = thePrefs.GetGUIDefault();
	pFont->GetLogFont(&lf);

	SetFont(pFont);

	CFont *m_fontBold = thePrefs.GetGUIDefaultBold();

	const int PointSize = 10;

	HDC hDC = ::GetDC(NULL);
	lf.lfHeight = -::MulDiv(PointSize, ::GetDeviceCaps(hDC, LOGPIXELSY), 72);
	lf.lfWeight = FW_BOLD;
	m_fontValue.CreateFontIndirect(&lf);

	for (int i = 0; i < BFT_MAX; i++)
	{
		m_stStatus[i].SetFont( &m_fontValue );
		m_stUpdate[i].SetFont( &m_fontValue );
	}
}

void CIPCTesterDlg::InitControl()
{
	// Create ToolTip Control
	m_ToolTipCtrl.Create(this);
	m_ToolTipCtrl.Activate(TRUE);

	// Temp, TestCount Static Create
	////////////////////////////////////////////
	CImageList	*pImgList;
	IMAGEINFO	ImgInfo;

	CRect rectWin, rectBtn;
	GetClientRect(&rectWin);

	CRect	rcTemp(0, 0, 0, 0);

	// Create Static Ctrl 
	//////////////////////////////////////////////////////
	for (int i = 0; i < BFT_MAX; i++)
	{
		rcTemp.left = rcTemp.right;
		rcTemp.right = rcTemp.left + 40;

		m_stStatus[ i ].Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, rcTemp, this);
		m_stStatus[ i ].SetAlign(DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
		m_stStatus[ i ].SetTransparent( 1 );
		m_stStatus[ i ].SetFontColor( m_clrText );

		m_stUpdate[ i ].Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, rcTemp, this);
		m_stUpdate[ i ].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		m_stUpdate[ i ].SetTransparent( 1 );
		m_stUpdate[ i ].SetFontColor( m_clrValue );
	}

	// System Windows Close Button Create
	// MAX, MIN, TRAY, CLOSE Button
	//////////////////////////////////////////////////////////////////////////////////
	int nStartPos = rectWin.right - IPC_MAIN_RIGHT * 3 + 2;

	for( int i = 0; i < MAX_WINDOW_SHOWBTN; i++ )
	{
		pImgList = theResMan.GetImageListRes( IPC_RESMAN_WINDOW_CLOSE + i );
		m_btnWindowShow[ i ].SetImageList( pImgList, 0 );
		pImgList->GetImageInfo( 0, &ImgInfo );
		rectBtn = ImgInfo.rcImage;

		m_btnWindowShow[ i ].Create( NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
			rectBtn, this, IDC_WINDOW_CLOSE + i );

		m_btnWindowShow[ i ].SetTransparent( );

		int nTop	= rectWin.top + (INT) ( IPC_MAIN_BTN_INTERVAL ) - IPC_MAIN_TOP;  
		int nLeft	= nStartPos - (rectBtn.Width() + 2);
		nStartPos	= nLeft;

		m_btnWindowShow[ i ].MoveWindow(nLeft, nTop, rectBtn.Width(), rectBtn.Height());

		m_ToolTipCtrl.AddTool( (CWnd *)&m_btnWindowShow[ i ] , IDS_MAIN_TOOLTIP_WINDOWCLOSE + i );
	}
}

// Set Top Most Window Property
void CIPCTesterDlg::SetTopMostWindow(BOOL bTopMost)
{
#ifndef _DEBUG
	CRect rcCrazy;
	GetWindowRect(&rcCrazy);

	if (bTopMost)
	{
		SetWindowPos(&wndTopMost, rcCrazy.left, rcCrazy.top, rcCrazy.Width(), rcCrazy.Height(), 0);
		SetForegroundWindow();
		BringWindowToTop();
	}
	else
	{
		SetWindowPos(GetForegroundWindow(), rcCrazy.left, rcCrazy.top, rcCrazy.Width(), rcCrazy.Height(), SWP_NOACTIVATE);
		SetWindowPos(&wndNoTopMost, rcCrazy.left, rcCrazy.top, rcCrazy.Width(), rcCrazy.Height(), 0);
	}
#endif
}


int	CIPCTesterDlg::IPCMessageBox(UINT nIDPrompt, UINT nIDCaption, UINT nType/* =0 */, UINT nIDHelp/* = */)
{
	int nRet;
	m_bShowMessageBox = true;
	//nRet = AfxMessageBox(nIDPrompt, nType, nIDHelp);
	nRet = MessageBox(GetResString(nIDPrompt), GetResString(nIDCaption), nType);
	m_bShowMessageBox = false;
	return nRet;
}

int	CIPCTesterDlg::IPCMessageBox(LPCTSTR lpszText, LPCTSTR lpszCaption, UINT nType/* =0 */, UINT nIDHelp/* = */)
{
	int nRet;
	m_bShowMessageBox = true;
	//nRet = AfxMessageBox(lpszText, nType, nIDHelp);
	nRet = MessageBox(lpszText, lpszCaption, nType);
	m_bShowMessageBox = false;
	return nRet;
}

int CIPCTesterDlg::ShowHistoryDlg(LPARAM pParam)
{
	LPTSTR strPath = (LPTSTR)pParam;

	if (IsHistoryDlgOpen()) 
	{
		MessageBeep(MB_OK);
		m_pHistoryWnd->SetForegroundWindow();
		m_pHistoryWnd->BringWindowToTop();
		return -1;
	}

	m_pHistoryWnd = new CMeasHistoryDlg;
	m_pHistoryWnd->SetFilePath(strPath);

	delete strPath;

	m_pHistoryWnd->DoModal();

	delete m_pHistoryWnd;
	m_pHistoryWnd = NULL;

	return -1;
}

bool CIPCTesterDlg::IsHistoryDlgOpen() const
{
	return (m_pHistoryWnd != NULL);
}

int CIPCTesterDlg::ShowPreferences()
{
	m_pPrefsWnd = new CConfigDlg;

	if(	m_pStatusWnd->GetTestStatus() != TESTSTATUS_STOP)
		m_pPrefsWnd->SetDisable();
	else
		::SendMessage(m_pStatusWnd->m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_TEMPDATA_SCAN, 0);	// KillTimer

	m_pPrefsWnd->DoModal();

	delete m_pPrefsWnd;
	m_pPrefsWnd = NULL;

	::SendMessage(m_pStatusWnd->m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_TEMPDATA_SCAN, 1);	// SetTimer

	return -1;
}

bool CIPCTesterDlg::IsPreferencesDlgOpen() const
{
	return (m_pPrefsWnd != NULL);
}

HRESULT CIPCTesterDlg::ShowUserPopup(WPARAM wParam, LPARAM lParam)
{
	LPTSTR lpStr = NULL;
	CString strMessage;
	if(lParam)
	{
		lpStr = (LPTSTR)lParam;
		strMessage = lpStr;

		delete[] lpStr;
	}

	if (!m_pUserPopup)
		m_pUserPopup = new CUserPopup;
	
	if(!::IsWindow(m_pUserPopup->GetSafeHwnd()))
		m_pUserPopup->Create(IDD_USERPOPUP, this);

	if(wParam == 0)
		m_pUserPopup->SetMessage(strMessage);
	else
		m_pUserPopup->SetMessage(GetResString(wParam));

	m_pUserPopup->ShowWindow(SW_SHOW);

	return S_OK;
}

HRESULT CIPCTesterDlg::UserPopupOK(WPARAM wParam, LPARAM lParam)
{
	if(m_pStatusWnd)
		::PostMessage(m_pStatusWnd->m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_SERIAL_ERROR, 0);
	return S_OK;
}

int CIPCTesterDlg::ShowAmpTestDlg(int amp)
{
	if (IsAmpTestDlgOpen()) 
	{
		MessageBeep(MB_OK);
		m_pAmpTestWnd->SetForegroundWindow();
		m_pAmpTestWnd->BringWindowToTop();
		return -1;
	}

	m_pAmpTestWnd = new CAmplitudeDlg;
	m_pAmpTestWnd->SetAmplitude(amp);
	m_pAmpTestWnd->DoModal();

	delete m_pAmpTestWnd;
	m_pAmpTestWnd = NULL;

	return -1;
}

bool CIPCTesterDlg::IsAmpTestDlgOpen() const
{
	return (m_pAmpTestWnd != NULL);
}


bool CIPCTesterDlg::CanClose()
{
	CPopupDlg	popupDlg;
	popupDlg.SetPopupParam(	IDS_IPC_CAPTION,
							IDS_MAIN_EXIT,
							IPC_RESMAN_BTN_EXIT,
							IPC_RESMAN_BTN_CONTINUE);
	if(popupDlg.DoModal() == IDCANCEL)
		return false;

	//if (IPCMessageBox(IDS_MAIN_EXIT, IDS_IPC_CAPTION,
	//				MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) == IDNO)
	//	return false;

	// ���α׷� ����
	return true;
}

void CIPCTesterDlg::StartConnection(bool remote)
{
	if(theApp.m_pACCT)
	{
		TTYSTRUCT	TTY;
		LPTTYSTRUCT	lpTTY = &TTY;

		::ZeroMemory(lpTTY, sizeof(LPTTYSTRUCT));

		lpTTY->byCommPort	= thePrefs.GetPortACCT();
		lpTTY->dwBaudRate	= thePrefs.GetBaudRateACCT();
		lpTTY->byStopBits	= (thePrefs.GetStopBits() == 1)? ONESTOPBIT : thePrefs.GetStopBits();
		lpTTY->byByteSize	= thePrefs.GetDataBits();
		lpTTY->byParity		= thePrefs.GetParity();
		lpTTY->byFlowCtrl	= FC_XONXOFF;

		lpTTY->byCommPort	= thePrefs.GetPortACCT();
		lpTTY->dwBaudRate	= thePrefs.GetBaudRateACCT();

		if(!theApp.m_pACCT->GetStartFlag())
			theApp.m_pACCT->Start(lpTTY, _T("ACCT SerialComm"), 2 * 1000);
		else
		{
			theApp.m_pACCT->Stop();
			theApp.m_pACCT->Start(lpTTY, _T("ACCT SerialComm"), 2 * 1000);
		}
	}

	if(theApp.m_pRMI)
	{
		ASRLSTRUCT	ASRL;
		LPASRLSTRUCT lpASRL = &ASRL;

		lpASRL->asrlid		= thePrefs.GetPortRMI();
		lpASRL->dwBaudRate	= thePrefs.GetBaudRateRMI();
		lpASRL->byDataBits	= thePrefs.GetDataBits();
		lpASRL->byStopBits	= thePrefs.GetStopBits();
		lpASRL->byParity	= thePrefs.GetParity();

		theApp.m_pRMI->SetSessionSerialPort(lpASRL);
	}

	theApp.SetAppStatus(APPSTATUS_CONNECTION);
}

void CIPCTesterDlg::CloseConnection(short exitflag /*=false*/)
{
	if(theApp.GetAppStatus() == APPSTATUS_RUN) // Application ���� �� .... 
	{
		::SendMessage(m_pStatusWnd->m_hWnd, UM_IPC_TEST_END, 0, 0);
		SleepEx(1000, TRUE);
	}

	theApp.SerialDisconnect();	
	SleepEx(1000, TRUE);

	if(exitflag)	
		::PostMessage(m_hWnd, UM_IPC_CLOSE, 0, 0);
}

void CIPCTesterDlg::UpdateIPCCount()
{
	//CString strValue;
	//strTotal.Format(_T("%
	//m_stUpdate[ BFT_TOTAL ].SetCaption(GetResString(IDS_MAIN_STATIC_TEMP + i));

}

void CIPCTesterDlg::DrawTitleBar( CDC *pDC, BOOL bPaint)
{
	CDC		dcMemory;
	CRect	rc_Client;
	IMAGEINFO	ImgInfo;

	GetClientRect( rc_Client );

	if( dcMemory.CreateCompatibleDC(pDC) )
	{
		CBitmap *OldBitmap = dcMemory.SelectObject( theResMan.GetBitmapTitlebar() );


		pDC->StretchBlt( rc_Client.left, rc_Client.top, rc_Client.right - rc_Client.left, IPC_WINDOW_TITLE_HEIGHT, 
						&dcMemory, 
						0, 0, 1, IPC_WINDOW_TITLE_HEIGHT, 
						SRCCOPY );


		dcMemory.SelectObject(theResMan.GetBitmapBG(CResManager::EN_COUNT_BG));
		pDC->StretchBlt(0, IPC_WINDOW_TITLE_HEIGHT, rc_Client.right, IPC_MAIN_DISPLAY_HEIGHT, 
						&dcMemory, 
						0, 0, 1, IPC_MAIN_DISPLAY_HEIGHT, 
						SRCCOPY );


		BITMAP	BitmapInfo;
		CBitmap* bmpArea = theResMan.GetBitmapBG(CResManager::EN_COUNT_LINE);

		bmpArea->GetBitmap(&BitmapInfo);
		dcMemory.SelectObject(bmpArea);

		pDC->StretchBlt(0, IPC_MAIN_DISPLAY_TOP + IPC_MAIN_DISPLAY_HEIGHT, rc_Client.right, BitmapInfo.bmHeight,  
						&dcMemory, 
						0, 0, 1, BitmapInfo.bmHeight,  
						SRCCOPY );


		dcMemory.SelectObject( OldBitmap );
		dcMemory.DeleteDC();
	}

	// Window Title Image Draw
	CImageList	*pImgList = theResMan.GetImageListRes( IPC_RESMAN_IPC_LOGO );
	pImgList->Draw( pDC, 0, CPoint( 3, 0 ), ILD_TRANSPARENT );

	pImgList->GetImageInfo(0, &ImgInfo);
	CRect imgRrect = ImgInfo.rcImage;

	CRect rcItem(imgRrect.Width() + 5, 0, rc_Client.right, imgRrect.Height() + 1);

	CFont*	pFont;
	//pFont = thePrefs.GetGUIDefaultBold();
	pFont = thePrefs.GetGUIDefault();

    CFont* pOldFont = pDC->SelectObject(pFont);
	
	pDC->SetTextColor(PALETTERGB(255,255,255));
	pDC->SetBkMode(TRANSPARENT);
	CString strCaption;
	strCaption = GetResString(IDS_IPC_CAPTION) + _T(" v") + theApp.m_strCurVersionLong;
	pDC->DrawText(strCaption, rcItem, DT_SINGLELINE | DT_LEFT | DT_VCENTER );

	pDC->SelectObject(pOldFont);
	//

	int nStartPos = 0;
	int nCtrlWidth = 170;
	int nCtrlHeight = 30;

	int nInterval = (rc_Client.Width() - 50) / 3;

	int nTop	= rc_Client.top + (INT) ( IPC_WINDOW_TITLE_HEIGHT ) + IPC_MAIN_TOP * 3; 

	// Main Static Position
	for (int i = 0; i < BFT_MAX; i++)
	{
		int nLeft = nStartPos;
		if(m_stStatus[ i ].m_hWnd)
		{
			CRect stRect;
			stRect.left = nLeft;
			stRect.top = nTop;
			stRect.right = stRect.left + nCtrlWidth;
			stRect.bottom = stRect.top + nCtrlHeight;

			m_stStatus[ i ].MoveWindow(stRect, FALSE);
			m_stStatus[ i ].Invalidate( FALSE );
		}

		nLeft += nCtrlWidth + IPC_MAIN_BTN_INTERVAL * 2;

		if(m_stUpdate[ i ].m_hWnd)
		{
			CRect stRect;
			stRect.left = nLeft;
			stRect.top = nTop;
			stRect.right = stRect.left + nCtrlWidth;
			stRect.bottom = stRect.top + nCtrlHeight;

			if(i == BFT_CURRENT)
				stRect.right = rc_Client.right - 2;

			m_stUpdate[ i ].MoveWindow(stRect, FALSE);
			m_stUpdate[ i ].Invalidate( FALSE );
		}

		nStartPos	= nStartPos + nInterval;
	}

	// Windows System Menu Draw
	nStartPos = rc_Client.right - IPC_MAIN_RIGHT + 2;

	for( int i = 0; i < MAX_WINDOW_SHOWBTN; i++ )
	{
		if(m_btnWindowShow[ i ].m_hWnd)
		{
			CRect rectBtn;
			m_btnWindowShow[ i ].GetClientRect( &rectBtn );

			int nTop	= rc_Client.top + (INT) ( IPC_MAIN_BTN_INTERVAL ) + IPC_MAIN_TOP * 3; 
			int nLeft	= nStartPos - (rectBtn.Width() + 9 );			
			nStartPos	= nLeft;

			m_btnWindowShow[ i ].SetWindowPos(NULL, nLeft, nTop, rectBtn.Width(), rectBtn.Height(), SWP_NOSIZE | SWP_NOREDRAW);
			m_btnWindowShow[ i ].Invalidate( FALSE );
		}
	}
}

void CIPCTesterDlg::DrawMenuButton( CDC *pDC, BOOL bPaint )
{
	CRect rcClient;
	GetClientRect(&rcClient);

	// BackGround Color �� (Main Window Left, Right, Bottom ������ ä���
	CRect rcTemp(0, 0, 0, 0);

	CBrush brBack(m_clrBack), *pOldBrush;
	pOldBrush = pDC->SelectObject(&brBack);

	// Top Area
	rcTemp.SetRect( rcClient.left, IPC_MAIN_WINDOW_TOP, rcClient.right, IPC_MEASURE_WINDOW_TOP );	
	pDC->FillRect(rcTemp, &brBack);
	// Left Area
	rcTemp.SetRect( rcClient.left, IPC_MAIN_WINDOW_TOP, rcClient.left + IPC_MAIN_WINDOW_LEFT, rcClient.bottom );	
	pDC->FillRect(rcTemp, &brBack);
	// Right Area
	rcTemp.SetRect( rcClient.right - IPC_MAIN_WINDOW_LEFT, IPC_MAIN_WINDOW_TOP, rcClient.right, rcClient.bottom );
	pDC->FillRect(rcTemp, &brBack);
	// Bottom Area
	rcTemp.SetRect( rcClient.left, rcClient.bottom - IPC_MAIN_WINDOW_LEFT, rcClient.right, rcClient.bottom );
	pDC->FillRect(rcTemp, &brBack);

	pDC->SelectObject(pOldBrush);

	// BackGround Color �� (Main Window Left, Right, Bottom ������ ä���
	CPen pen;
	pen.CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
	CPen *pOldPen = pDC->SelectObject(&pen);

	// Windows Area �׵θ� (2 pixel)
//	CRect	rcTemp(0, 0, 0, 0);

	pDC->MoveTo(1, 0);
	pDC->LineTo(rcClient.left + 1, rcClient.bottom);

	pDC->MoveTo(rcClient.left, rcClient.bottom - 1);
	pDC->LineTo(rcClient.right, rcClient.bottom - 1);

	pDC->MoveTo(rcClient.right - 1, rcClient.bottom);
	pDC->LineTo(rcClient.right - 1, rcClient.top);

	pDC->SelectObject(pOldPen);

	// Status Resize Image ReDraw
	{
		CRect		rcClient;
		GetClientRect(&rcClient);

		CRect		rcImg;
		IMAGEINFO	ImgInfo;
		CImageList	*pImgList = theResMan.GetImageListRes(IPC_RESMAN_SATATUS_RESIZE);

		pImgList->GetImageInfo(0, &ImgInfo);
		rcImg = ImgInfo.rcImage;

		CPoint	ptImg;
		CSize	szImg;

		ptImg.x = rcClient.right - rcImg.Width() - IPC_MAIN_RIGHT;
		ptImg.y = rcClient.bottom - (rcImg.Height() + IPC_MAIN_RIGHT);
		szImg.cx = rcImg.Width();
		szImg.cy = rcImg.Height();

		pImgList->DrawEx(pDC, 0, ptImg, szImg, CLR_DEFAULT, CLR_DEFAULT, ILD_TRANSPARENT);
	}

//	// BackGround Color �� (Main Window Left, Right, Bottom ������ ä���
//	CPen pen;
//	pen.CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
//	CPen *pOldPen = pDC->SelectObject(&pen);
//
//	// Windows Area �׵θ� (2 pixel)
//	CRect	rcTemp(0, 0, 0, 0);
//
//	pDC->MoveTo(1, 0);
//	pDC->LineTo(rcClient.left + 1, rcClient.bottom);
//
//	pDC->MoveTo(rcClient.left, rcClient.bottom - 1);
//	pDC->LineTo(rcClient.right, rcClient.bottom - 1);
//
//	pDC->MoveTo(rcClient.right - 1, rcClient.bottom);
//	pDC->LineTo(rcClient.right - 1, rcClient.top);
//	// -------------------------------------------
//
	// Resistance Window  OutLine Draw
	if(m_pResistanceWnd[0])
	{
		CRect	rcStatus;
		m_pStatusWnd->GetWindowRect(&rcStatus);
		ScreenToClient(&rcStatus);

		// Measurement Window Area ����ϱ�
		CRect	rcMeas;
		rcMeas.left = IPC_MAIN_WINDOW_LEFT;
		rcMeas.top = IPC_MEASURE_WINDOW_TOP;
		rcMeas.right = rcClient.right - IPC_MAIN_WINDOW_LEFT;
		rcMeas.bottom = rcStatus.top;
		///////////////////////////////////////////

		CPen outpen;
		outpen.CreatePen(PS_SOLID, 2, m_clrOutline);
		pDC->SelectObject(&outpen);

		CRect rcOutline = rcMeas;

		pDC->MoveTo(rcOutline.left + 1, rcOutline.top);
		pDC->LineTo(rcOutline.left + 1, rcOutline.bottom - 1);

		pDC->MoveTo(rcOutline.left + 1, rcOutline.bottom - 1);
		pDC->LineTo(rcOutline.right - 1, rcOutline.bottom - 1);

		pDC->MoveTo(rcOutline.right - 1, rcOutline.bottom - 1);
		pDC->LineTo(rcOutline.right - 1, rcOutline.top + 1);

		pDC->MoveTo(rcOutline.left + 1, rcOutline.top + 1);
		pDC->LineTo(rcOutline.right - 1, rcOutline.top + 1);

		pDC->SelectObject(pOldPen);
	}
}

// Measurement Window Position Setting
void CIPCTesterDlg::SetMeasurementWndPosition()
{
	CRect	rcClient;
	GetClientRect( &rcClient );

	CRect	rcStatus;
	m_pStatusWnd->GetWindowRect(&rcStatus);
	ScreenToClient(&rcStatus);

	CRect	rcMeas;
	rcMeas.left = IPC_MAIN_WINDOW_LEFT;
	rcMeas.top = IPC_MEASURE_WINDOW_TOP;
	rcMeas.right = rcClient.right - IPC_MAIN_WINDOW_LEFT;
	rcMeas.bottom = rcStatus.top;

	int m_height = (rcMeas.Height() - (IPC_RESISTANCE_TOP * 2)) / 4;
	short ntop = rcMeas.Height() % 4;

	CRect	rcResist;
	rcResist.left = rcMeas.left + IPC_RESISTANCE_LEFT;
	rcResist.top = rcMeas.top + IPC_RESISTANCE_TOP;
	rcResist.right = rcMeas.right - IPC_RESISTANCE_LEFT;

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
	{
		rcResist.bottom = rcResist.top + m_height;
		// ntop ���� ������ �� ������ Graphc �� ���Ѵ�.
		if(i == (IPC_MAX_MATERIAL - 1))
			rcResist.bottom += ntop;

		if (m_pResistanceWnd[i] && m_pResistanceWnd[i]->m_hWnd != NULL)
		{
			m_pResistanceWnd[i]->MoveWindow(&rcResist, FALSE);
			m_pResistanceWnd[i]->Invalidate();
			m_pResistanceWnd[i]->ShowWindow(SW_SHOW);
		}
		rcResist.top += m_height;
	}
}

// Status Window Position Setting
void CIPCTesterDlg::SetStatusWndPosition()
{
	CRect	rcClient;
	GetClientRect(&rcClient);

	rcClient.top = rcClient.bottom - (m_pStatusWnd->m_orgRect.Height() + IPC_MAIN_WINDOW_BOTTOM);
	rcClient.bottom = rcClient.top + m_pStatusWnd->m_orgRect.Height() ;

	if(m_pStatusWnd)
		m_pStatusWnd->MoveWindow(rcClient.left + IPC_MAIN_LEFT * 4 , rcClient.top, 
								 rcClient.Width() - (IPC_MAIN_LEFT * 8), rcClient.Height(), FALSE);

	m_pStatusWnd->Invalidate();
	m_pStatusWnd->ShowWindow(SW_SHOW);
}

void CIPCTesterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸����� 
// �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
// �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CIPCTesterDlg::OnPaint() 
{
	CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ

	//if(IsWindowVisible())
	{
		DrawTitleBar( &dc );	
		DrawMenuButton( &dc );
	}

	if (IsIconic())
	{
		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
}


// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�. 
HCURSOR CIPCTesterDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CIPCTesterDlg::OnBnClickedClose()
{
	// ���� Close ��Ŀ� ���� ó�� �Ѵ�.
	if (CanClose()) 
	{
		thePrefs.Save();

		CloseConnection(true);

	//	ShowWindow(SW_HIDE);
	}
}

void CIPCTesterDlg::OnBnClickedMinimize()
{
	ShowWindow( SW_MINIMIZE);
}

#ifdef	_DEBUG
#define COMPILE_MULTIMON_STUBS
#endif
// Note : stdafx.h �� ���ǵ�
//#include <multimon.h>  

BOOL CALLBACK MonitorEnumProc( HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData )
{
	HMONITOR hCurrent_Monitor;
    MONITORINFOEX Current_mi;

    //
    // get the nearest monitor handle.
    //
    hCurrent_Monitor = MonitorFromWindow( theApp.m_pMainWnd->m_hWnd, MONITOR_DEFAULTTONEAREST);	

    //
    // get the work area or entire monitor rect.
    //


    Current_mi.cbSize = sizeof(Current_mi);
    GetMonitorInfo(hCurrent_Monitor, &Current_mi);	


	MONITORINFOEX mi;

	mi.cbSize = sizeof( MONITORINFO );
	GetMonitorInfo(hMonitor, &mi);

	if( ( mi.dwFlags == Current_mi.dwFlags ) )
	{
		( *( LPRECT )dwData ) = Current_mi.rcWork;
		return FALSE;
	}
	else
	{		
		return TRUE;
	}
}
// -----------------------------------------------------

void CIPCTesterDlg::OnBnClickedMaximize()
{
	static CRect preRect( 0, 0, 0, 0 );

	if( m_bMax_status )
	{
		m_bMax_status = WS_DOING;
		MoveWindow( preRect );
		m_bMax_status = WS_NORMAL;
	}
	else
	{
		m_bMax_status = WS_DOING;

		GetWindowRect( preRect );

		CRect rt;

		int cMon=GetSystemMetrics(SM_CMONITORS);

		if (cMon == 0) 
		{
			SystemParametersInfo( SPI_GETWORKAREA, 0, (void *) &rt, 0 );
		}
		else
		{
			EnumDisplayMonitors( NULL, NULL, (MONITORENUMPROC)MonitorEnumProc, (LPARAM)&rt );
		}

		MoveWindow( rt );
		m_bMax_status = WS_MAXIMIZED;
	}
	
}

BOOL CIPCTesterDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if (pMsg->message == WM_MOUSEMOVE) 
		m_ToolTipCtrl.RelayEvent(pMsg);	

	return CDialog::PreTranslateMessage(pMsg);
}

HRESULT CIPCTesterDlg::OnIPCClose( WPARAM wParam, LPARAM lParam )
{
	if(m_pStatusWnd)
		::SendMessage(m_pStatusWnd->m_hWnd, UM_IPC_BFTEST, ID_IPC_BFTEST_TEMPDATA_SCAN, 0);	// KillTimer

	theApp.m_appStatus = APPSTATUS_SHUTINGDOWN;
	::SleepEx(1000, TRUE);
	ShowWindow(SW_HIDE);

	if(m_pAmpTestWnd)
		::PostMessage(m_pAmpTestWnd->m_hWnd, WM_CLOSE, 0, 0);
	if(m_pPrefsWnd)
		::PostMessage(m_pPrefsWnd->m_hWnd, WM_CLOSE, 0, 0);

	if(theApp.m_pFileManager)	{ theApp.m_pFileManager->Stop(); }
	
	if(theApp.m_pACCT)			{ theApp.m_pACCT->Stop();	delete theApp.m_pACCT;	theApp.m_pACCT = NULL; }
	if(theApp.m_pRMI)			{ delete theApp.m_pRMI;	theApp.m_pRMI = NULL; }

	SleepEx(100, TRUE);

	theApp.Log(FALSE, _T("BFT Monitoring System End !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));

	theApp.m_appStatus = APPSTATUS_NONE;

	// 3. Windows ����
	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		if(m_pResistanceWnd[i])	delete m_pResistanceWnd[i];

	if(m_pStatusWnd)		delete m_pStatusWnd;

	/////////////////////////////////////////////////////////
	CDialog::OnCancel();
	return 0;
}

void CIPCTesterDlg::OnStartSerialThread()
{
	theApp.m_pACCT = new CSerialWorker_ACCT();
	theApp.m_pRMI = new CRMIInterface();
}


BOOL CIPCTesterDlg::OnNcActivate(BOOL bActive)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if (!bActive && !m_bGUIStart)
		SetTopMostWindow(TRUE);

	return CDialog::OnNcActivate(bActive);
}

void CIPCTesterDlg::OnNcLButtonDblClk(UINT nHitTest, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CRect rect;
	GetClientRect(rect);
	ClientToScreen(rect);

	if( ( rect.top + IPC_WINDOW_TITLE_HEIGHT ) > point.y )
		OnBnClickedMaximize();

	//CDialog::OnNcLButtonDblClk(nHitTest, point);
}

void CIPCTesterDlg::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if( point.y < IPC_WINDOW_TITLE_HEIGHT )
		OnBnClickedMaximize();

	//CDialog::OnLButtonDblClk(nFlags, point);
}

LRESULT CIPCTesterDlg::OnNcHitTest(CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	//return CDialog::OnNcHitTest(point);
	UINT ret = CDialog::OnNcHitTest( point );

	CRect rect;
	GetClientRect(rect);
	ClientToScreen(rect);

	int interval = 3;

	if( m_bMax_status )
	{
		if(ret == HTCLIENT && ( rect.top + IPC_WINDOW_TITLE_HEIGHT ) > point.y && !m_bMax_status)
		{
			return HTCAPTION;
		}
		else
			return 1;
	}

	if(rect.left+interval>point.x && rect.top+interval>point.y)
		return HTTOPLEFT;
	else if(rect.right-interval<point.x && rect.top+interval>point.y)
		return HTTOPRIGHT;
	else if(rect.left + (interval * 3) > point.x && rect.bottom - (interval *3) < point.y)
		return HTBOTTOMLEFT;
	else if(rect.right - (interval * 4) < point.x && rect.bottom - (interval * 4) < point.y)
		return HTBOTTOMRIGHT;
	else if(rect.right-interval<point.x)
		return HTRIGHT;
	else if(rect.left+interval>point.x)
		return HTLEFT;
	else if(rect.top+interval>point.y)
		return HTTOP;
	else if(rect.bottom-interval<point.y)
		return HTBOTTOM;
	else if(ret == HTCLIENT && ( rect.top + IPC_WINDOW_TITLE_HEIGHT ) > point.y && !m_bMax_status)
	{
		return HTCAPTION;
	}
	return ret;
}

void CIPCTesterDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if(activewnd)
	{
		// Status Window Position
		SetStatusWndPosition();

		// Set Measurement Window Position
		SetMeasurementWndPosition();

		CDC *dc = GetDC( );

		DrawTitleBar( dc , false );	
		DrawMenuButton( dc, false );
	
		ReleaseDC( dc );
	}
}

void CIPCTesterDlg::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialog::OnSizing(fwSide, pRect);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	int nFixedWidth = IPC_MAIN_MIN_WIDTH;
	int nFixedHeight = IPC_MAIN_MIN_HEIGHT;

	int nWidth, nHeight;
	nWidth = abs(pRect->right - pRect->left);
	nHeight = abs(pRect->bottom - pRect->top);
	switch(fwSide) 
	{
	case 2: 
	case 6: 
	case 8: 
		if (nWidth < nFixedWidth)
			pRect->right = pRect->left + nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->bottom = pRect->top + nFixedHeight;
		break;
	case 1: 
	case 3: 
	case 4: 
		if (nWidth < nFixedWidth)
			pRect->left = pRect->right - nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->top = pRect->bottom - nFixedHeight;
		break;
	case 5: 
		if (nWidth < nFixedWidth)
			pRect->right = pRect->left + nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->top = pRect->bottom - nFixedHeight;
		break;
	case 7: 
		if (nWidth < nFixedWidth)
			pRect->left = pRect->right - nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->bottom = pRect->top + nFixedHeight;
		break;
	default:
		return;
	}

	if (nWidth < nFixedWidth || nHeight < nFixedHeight)
		SetWindowPos(NULL, pRect->left, pRect->right, nWidth, nHeight, SWP_NOSIZE | SWP_NOMOVE);
}

void CIPCTesterDlg::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialog::OnClose();
}

BOOL CIPCTesterDlg::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(m_bMax_status == WS_DOING)
		return TRUE;

	return TRUE;
	//return CDialog::OnEraseBkgnd(pDC);
}


HRESULT CIPCTesterDlg::ShowHistoryDialog(WPARAM wParam, LPARAM lParam)
{
	ShowHistoryDlg((LPARAM)lParam);
	return S_OK;
}

HRESULT CIPCTesterDlg::ShowPrefsDialog(WPARAM wParam, LPARAM lParam)
{
	ShowPreferences();
	return S_OK;
}

HRESULT CIPCTesterDlg::ShowAmpTestDialog(WPARAM wParam, LPARAM lParam)
{
	ShowAmpTestDlg(lParam);
	return S_OK;
}

HRESULT CIPCTesterDlg::OnTempDisplay(WPARAM wParam, LPARAM lParam)
{
	char* pStr = (char*)lParam;
	if(pStr)
	{
		CString strTemp = pStr;
		delete[] pStr;
		m_stUpdate[BFT_TEMP].SetCaption(strTemp);
	}

	return S_OK;
}

HRESULT CIPCTesterDlg::OnBFTestCountDisplay(WPARAM wParam, LPARAM lParam)
{
	if(m_pStatusWnd)
	{
		CString strCount = theApp.ConvertStrValue(lParam);
		if(wParam == UM_IPC_MEAS_CURRENTCOUNT)
			m_stUpdate[BFT_CURRENT].SetCaption(strCount);
		else
			m_stUpdate[BFT_TOTAL].SetCaption(strCount);
	}

	return S_OK;
}

HRESULT CIPCTesterDlg::OnPreTestResistance(WPARAM wParam, LPARAM lParam)
{
	SResistanceData*	pData = (SResistanceData*)lParam;
	if(pData == NULL)
		return S_FALSE;

	CResistanceWnd* pResistance = m_pResistanceWnd[wParam - 1];
	if(pResistance)
	{
		// fail Margin Setting
		pResistance->SetFailMargin(thePrefs.m_failPercent);
		pResistance->PreTestResistance(pData->m_lfResist, true);
	}
	delete pData;
	return S_OK;
}

HRESULT CIPCTesterDlg::OnBFTestCreateFile(WPARAM wParam, LPARAM lParam)
{
	CFileManager*	pManager = (CFileManager*)theApp.m_pFileManager;
	if(pManager)
		::PostQueuedCompletionStatus(	pManager->Get_IOPORT(), 
										0,
										__INNERP_FILEMANAGER_BFTFILE_CREATE__,
										NULL);

	return S_OK;
}

HRESULT CIPCTesterDlg::OnBFTestResistance(WPARAM wParam, LPARAM lParam)
{
	SResistanceData*	pData = (SResistanceData*)lParam;
	if(pData == NULL)
		return S_FALSE;

	// ���� Manager ���� ���Ѵ�.
	// �������� �� ȭ�� Display �� ����
	/////////////////////////////////////////////////////////
	CFileManager*	pManager = (CFileManager*)theApp.m_pFileManager;
	if(pManager)
		::PostQueuedCompletionStatus(	pManager->Get_IOPORT(), 
										sizeof(SResistanceData),
										__INNERP_FILEMANAGER_ADDRESISTANCE__,
										(LPOVERLAPPED)pData);

	return S_OK;
}

HRESULT CIPCTesterDlg::OnBFTestDisplay(WPARAM wParam, LPARAM lParam)
{
	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
	{
		if(thePrefs.m_materialInfo[i] == false)
			continue;

		CResistanceWnd* pResistance = m_pResistanceWnd[i];
		if(pResistance && !pResistance->IsFail())
			::PostMessage(pResistance->m_hWnd, UM_IPC_MEAS_DISPLAY, 0, lParam);
	}

	CFileManager*	pManager = (CFileManager*)theApp.m_pFileManager;
	if(pManager)
	{
		::PostQueuedCompletionStatus(	pManager->Get_IOPORT(), 
										sizeof(int),
										__INNERP_FILEMANAGER_BFTFILE_SAVE__,
										(LPOVERLAPPED)lParam);
	}


	return S_OK;
}

void CIPCTesterDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(nIDEvent == IPC_TEMP_DATAREQUEST_TIMER)
	{
		m_pStatusWnd->KillTimer(IPC_TEMP_DATASCAN);

		time_t	ti;
		time(&ti);
		localtime(&ti);
		m_pStatusWnd->m_tiPass = ti;
		m_pStatusWnd->m_secCount = 0;

		thePrefs.IncreaseTestCount();
		m_pStatusWnd->TempDataRequest();
	}
	else if(nIDEvent == IPC_TEMP_DATAREQUEST_TIMER2)
	{
		m_pStatusWnd->KillTimer(IPC_TEMP_DATASCAN);

		float timer = thePrefs.m_interval;
		short min = timer;
		short sec = (short)(timer * 10 ) % 10;
		long  termSec = (min * 60 + sec * 6);

		KillTimer(m_pStatusWnd->m_timerID);
		m_pStatusWnd->m_timerID = IPC_TEMP_DATAREQUEST_TIMER;
		SetTimer(IPC_TEMP_DATAREQUEST_TIMER, termSec * 1000, NULL);

		time_t	ti;
		time(&ti);
		localtime(&ti);
		m_pStatusWnd->m_tiPass = ti;
		m_pStatusWnd->m_secCount = 0;
	
		thePrefs.IncreaseTestCount();
		m_pStatusWnd->TempDataRequest();
	}
}