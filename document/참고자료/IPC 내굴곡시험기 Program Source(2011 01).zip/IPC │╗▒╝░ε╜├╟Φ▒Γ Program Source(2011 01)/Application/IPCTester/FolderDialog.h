
#if !defined(AFX_FOLDERDIALOG_H__AB51302F_8F07_4DF3_9B6F_666572AD1E42__INCLUDED_)
#define AFX_FOLDERDIALOG_H__AB51302F_8F07_4DF3_9B6F_666572AD1E42__INCLUDED_

#include <shlobj.h>
#include <shellapi.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// CFolderDialog dialog
class CFolderDialog : CDialog
{
	//friend CFolderDialogSub;

public:
	CFolderDialog(CWnd *pParent = NULL, 
		int nSpecialFolder = CSIDL_DESKTOP, 
		LPCTSTR szTitle = TEXT("Choose Folder..."),
		LPCTSTR szRootPath = NULL, 
		UINT uFlag = BIF_EDITBOX | BIF_STATUSTEXT);

	virtual ~CFolderDialog();

	void SetRootPath(LPCTSTR szRootPath);
	LPCTSTR GetFolderPath();
	void SetParent(CWnd *pParent);
	void SetSpecialFolderLocation(int nFolder);	// nFolder = REGSTR_PATH_SPECIAL_FOLDERS
	void SetTitle(LPCTSTR szTitle);
	LPCTSTR GetFolderName( ) const;
	virtual int DoModal();

private:
	static int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM dwData);

	HRESULT SHPathToPIDL(LPCTSTR szPath, LPITEMIDLIST* ppidl);
	HICON	SHGetSystemIcon(int iIconIndex);

	CString				m_szRootPath;		
	CString				m_szFolderName;		
	HWND				m_hParent;			
	UINT				m_uFlag;			
	CString				m_szFolderPath;		
	int					m_nSpecialFolder;	
	CString				m_szTitle;			

	CWnd*				m_pParentWnd;
};

#endif // !defined(AFX_FOLDERDIALOG_H__AB51302F_8F07_4DF3_9B6F_666572AD1E42__INCLUDED_)
