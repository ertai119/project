#pragma once

#include "Ctrl/static/static.h"
#include "afxwin.h"

#define IPC_REPORT_TOP				10
#define IPC_REPORT_LEFT				10
#define IPC_REPORT_BOTTOM			10

#define IPC_REPORT_MEAS_STARTX		400
#define IPC_REPORT_EDIT_WIDTH		380
#define IPC_REPORT_EDIT_HEIGHT		170

#define IPC_REPORT_MIN_WIDTH		700		// Min Width Size
#define IPC_REPORT_MIN_HEIGHT		600

#define IPC_TRESULT_COLUMN_NAME			90
#define IPC_TRESULT_COLUMN_INIT			90
#define IPC_TRESULT_COLUMN_FAIL			90
#define IPC_TRESULT_COLUMN_TOTAL		90

#define IPC_MEASURE_COLUMN_COUNT		100
#define IPC_MEASURE_COLUMN_S1			90
#define IPC_MEASURE_COLUMN_S2			90
#define IPC_MEASURE_COLUMN_S3			90
#define IPC_MEASURE_COLUMN_S4			90
#define IPC_MEASURE_COLUMN_TEMP			100

enum TResultCtrlItems
{
	TRESULT_SITEM_NAME = 0,			
	TRESULT_SITEM_INITRESIST,		
	TRESULT_SITEM_FAILCOUNT,		
	TRESULT_SITEM_TOTALCOUNT,		
	TRESULT_SITEM_MAX,
};

static const struct
{
	UINT nColHdrId;
	int  nFormat;
	int  nWidth;
} colDataResult[] = 
			{	
				{IDS_REPORT_TRESULT_NAME,			LVCFMT_LEFT,	IPC_TRESULT_COLUMN_NAME}, 
				{IDS_REPORT_TRESULT_INITRESIST,		LVCFMT_CENTER,	IPC_TRESULT_COLUMN_INIT},
				{IDS_REPORT_TRESULT_FAILCOUNT,		LVCFMT_CENTER,	IPC_TRESULT_COLUMN_FAIL},
				{IDS_REPORT_TRESULT_TOTALCOUNT,		LVCFMT_CENTER,	IPC_TRESULT_COLUMN_TOTAL},
			};

enum MeasureCtrlItems
{
	MEASURE_SITEM_COUNT = 0,		
	MEASURE_SITEM_S1,				
	MEASURE_SITEM_S2,				
	MEASURE_SITEM_S3,				
	MEASURE_SITEM_S4,				
	MEASURE_SITEM_TEMP,				
	MEASURE_SITEM_MAX,
};

static const struct
{
	UINT nColHdrId;
	int  nFormat;
	int  nWidth;
} colDataMeasure[] = 
			{	
				{IDS_REPORT_MEASURE_COUNT,		LVCFMT_RIGHT,	IPC_MEASURE_COLUMN_COUNT}, 
				{IDS_REPORT_MEASURE_S1,			LVCFMT_CENTER,	IPC_MEASURE_COLUMN_S1},
				{IDS_REPORT_MEASURE_S2,			LVCFMT_CENTER,	IPC_MEASURE_COLUMN_S2},
				{IDS_REPORT_MEASURE_S3,			LVCFMT_CENTER,	IPC_MEASURE_COLUMN_S3},
				{IDS_REPORT_MEASURE_S4,			LVCFMT_CENTER,	IPC_MEASURE_COLUMN_S4},
				{IDS_REPORT_MEASURE_TEMP,		LVCFMT_CENTER,	IPC_TRESULT_COLUMN_TOTAL},
			};

// CMeasReportDlg ��ȭ �����Դϴ�.

class CMeasReportDlg : public CDialog
{
	DECLARE_DYNAMIC(CMeasReportDlg)

public:
	CMeasReportDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CMeasReportDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_MEASREPORTDLG };
	enum {	EN_STATIC_DOCUMENT = 0,		
			EN_STATIC_HEADER,			
			EN_STATIC_RESULT,			
			EN_STATIC_MAX,
		};
	enum {	EN_EDIT_DOCUMENT = 0,		
			EN_EDIT_HEADER,				
			EN_EDIT_MAX,
		};

	BOOL	AddResultList(short num, LPTSTR name, float lfResist, int failCount, long totalCount);
	BOOL	AddMeasureList(int item, long totalcount, float* lfResist, float lfTemp);

protected:
	COLORREF	m_clrBack, m_clrText, m_clrBlue, m_clrOutline, m_clrMask;

	cXenStatic		m_stStatic[EN_STATIC_MAX];
	CListCtrl		m_ResultListCtrl;		
	CListCtrl		m_MeasureListCtrl;		

	CImageList        m_imgList;

	CEdit			m_editReportEx[EN_EDIT_MAX];
	CString			m_strReport[EN_EDIT_MAX];

	CMeasHistoryDlg*	pHistoryWnd;
	CFont				m_listFont;

	CToolTipCtrl	m_ToolTipCtrl;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	void	Localize();
	void	LocalizeFont();
	void	InitControl();
	void	SetPosition();

	void	LoadReportHeader();
	void	LoadResultList();
	void	RedrawOutline(CDC* pDC);

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnClose();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnPaint();
};
