#include "StdAfx.h"
#include "Preferences.h"
#include "Ini.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPreferences thePrefs;

CPreferences::CPreferences(void)
{
	m_TestCurrentCount = 0;
	m_TestTotalCount = 0;
}

CPreferences::~CPreferences(void) {}

LPCTSTR CPreferences::GetConfigFile()
{
	return theApp.GetPrefsName();
}

// Preferences initialize
void CPreferences::Init()
{
	//get application start directory
	TCHAR buffer[512];

	::GetModuleFileName(0, buffer, 512);
	LPTSTR pszFileName = _tcsrchr(buffer, _T('\\')) + 1;
	if(pszFileName) *pszFileName = _T('\0');

	m_appDir = buffer;
	m_configDir = m_appDir + CONFIGFOLDER;
	m_fileDir = m_appDir + FILESFOLDER;

	CString strLog = m_appDir + _T("logs\\");		// ./logs/
	::CreateDirectory(strLog, 0);
	m_logDir = m_appDir + LOGFOLDER;				// ./logs/upload/

	::CreateDirectory(GetConfigDir(), 0);

	::CreateDirectory(m_fileDir, 0);

	::CreateDirectory(GetLogDir(), 0);

	CFont* pFont = CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT));
	pFont->GetLogFont(&m_lfText);

	LoadPreferences();
	CreateFont();					

	if(!PathFileExists (GetConfigFile()) ) 
		Save();
}

// preferences Un unitialize
void CPreferences::Uninit()
{
}

// Preferences File �� ���� �Ѵ�.
bool CPreferences::Save()
{
	SavePreferences();

	return true;
}

void CPreferences::SavePreferences()
{	
	::DeleteFile(GetConfigFile());

	CIni ini(GetConfigFile(), _T("IPCTester"));

	ini.WriteStringUTF8(_T("AppVersion"), theApp.m_strCurVersionLong);

	ini.WriteInt(_T("IPCTest_TotalCount"), m_TestTotalCount);	

	ini.WriteInt(_T("SerialPort_RMI"), m_portRMI);			
	ini.WriteInt(_T("SerialPort_ACCT"), m_portACCT);		

	ini.WriteInt(_T("SerialPort_BaudRate_RMI"), m_baudRateRMI);	
	ini.WriteInt(_T("SerialPort_BaudRate_ACCT"), m_baudRateACCT);	
	ini.WriteInt(_T("SerialPort_DataBits"), m_dataBits);	
	ini.WriteInt(_T("SerialPort_StopBits"), m_stopBits);	
	ini.WriteInt(_T("SerialPort_Parity"), m_parity);	

	ini.WriteFloat(_T("FixedTemp"),	m_temp);			
	ini.WriteInt(_T("AllowableTemp"), m_allowable);		
	ini.WriteBool(_T("AutoStart"), m_bAutoStart);		
	ini.WriteInt(_T("BendingSpeed"), m_bendingSpeed);	
	ini.WriteInt(_T("Amplitude"), m_amplitude);			
	ini.WriteFloat(_T("FailPercent"), m_failPercent);	
	ini.WriteFloat(_T("MeasureInterval"), m_interval);	
	ini.WriteInt(_T("TestStopCount"), m_stopCount);		
	ini.WriteBool(_T("UsedStopCount"), m_bUsed);		

	ini.WriteBool(_T("SelectS1"), m_materialInfo[0]);	
	ini.WriteBool(_T("SelectS2"), m_materialInfo[1]);	
	ini.WriteBool(_T("SelectS3"), m_materialInfo[2]);	
	ini.WriteBool(_T("SelectS4"), m_materialInfo[3]);	

	ini.WriteString(_T("MaterialName1"), m_materialName[0]);	
	ini.WriteString(_T("MaterialName2"), m_materialName[1]);	
	ini.WriteString(_T("MaterialName3"), m_materialName[2]);	
	ini.WriteString(_T("MaterialName4"), m_materialName[3]);	

	ini.WriteFloat(_T("PreTestS1"), m_preTest[0]);	
	ini.WriteFloat(_T("PreTestS2"), m_preTest[1]);	
	ini.WriteFloat(_T("PreTestS3"), m_preTest[2]);	
	ini.WriteFloat(_T("PreTestS4"), m_preTest[3]);	

	ini.WriteString(_T("FolderPath"), m_folderPath);
	ini.WriteString(_T("FileName"), m_fileName);	
}

//
// Load IPCConfig.ini 
//
void CPreferences::LoadPreferences()
{
	CIni ini(GetConfigFile(), _T("IPCTester"));
	ini.SetSection(_T("IPCTester"));

	CString strCurrVersion, strPrefsVersion;
	strCurrVersion = theApp.m_strCurVersionLong;
	strPrefsVersion = ini.GetStringUTF8(_T("AppVersion"));

	m_TestTotalCount	= ini.GetInt(_T("IPCTest_TotalCount"),	0);		

	m_portRMI	= ini.GetInt(_T("SerialPort_RMI"),	IPC_RMI_COMPORT);		
	m_portACCT	= ini.GetInt(_T("SerialPort_ACCT"), IPC_ACCT_COMPORT);	

	m_baudRateRMI	= ini.GetInt(_T("SerialPort_BaudRate_RMI"), IPC_RMI_BAUDRATE);	
	m_baudRateACCT	= ini.GetInt(_T("SerialPort_BaudRate_ACCT"), IPC_ACCT_BAUDRATE);	
	m_dataBits	= ini.GetInt(_T("SerialPort_DataBits"), IPC_SERIALPORT_DATABITS);	
	m_stopBits	= ini.GetInt(_T("SerialPort_StopBits"), IPC_SERIALPORT_STOPBITS);	
	m_parity	= ini.GetInt(_T("SerialPort_Parity"), IPC_SERIALPORT_PARITY);	

	m_temp		= ini.GetFloat(_T("FixedTemp"),	25.0);		
	m_allowable	= ini.GetInt(_T("AllowableTemp"), 1);		
	m_bAutoStart = ini.GetBool(_T("AutoStart"), false);		
	m_bendingSpeed = ini.GetInt(_T("BendingSpeed"), 1500);	
	m_amplitude	= ini.GetInt(_T("Amplitude"), 20);			
	m_failPercent = ini.GetFloat(_T("FailPercent"), 10.0);	
	m_interval	= ini.GetFloat(_T("MeasureInterval"), 3.0F);
	m_stopCount	= ini.GetInt(_T("TestStopCount"), 0);	
	m_bUsed		= ini.GetBool(_T("UsedStopCount"), false);	

	m_materialInfo[0] = ini.GetBool(_T("SelectS1"), true);	
	m_materialInfo[1] = ini.GetBool(_T("SelectS2"), true);	
	m_materialInfo[2] = ini.GetBool(_T("SelectS3"), true);	
	m_materialInfo[3] = ini.GetBool(_T("SelectS4"), true);	

	m_materialName[0] = ini.GetString(_T("MaterialName1"), _T("S1"));	
	m_materialName[1] = ini.GetString(_T("MaterialName2"), _T("S2"));	
	m_materialName[2] = ini.GetString(_T("MaterialName3"), _T("S3"));	
	m_materialName[3] = ini.GetString(_T("MaterialName4"), _T("S4"));	

	m_preTest[0]	= ini.GetFloat(_T("PreTestS1"), 0.0F);	
	m_preTest[1]	= ini.GetFloat(_T("PreTestS2"), 0.0F);	
	m_preTest[2]	= ini.GetFloat(_T("PreTestS3"), 0.0F);	
	m_preTest[3]	= ini.GetFloat(_T("PreTestS4"), 0.0F);	

	m_folderPath	= ini.GetString(_T("FolderPath"), m_fileDir);	
	m_fileName		= ini.GetString(_T("FileName"), NULL);			
}

//
// LOGFONT Create
void CPreferences::CreateFont()
{
	LPLOGFONT plfText = GetTextLogFont();
	if (m_fontText.m_hObject) 
		m_fontText.DeleteObject();
	if (plfText == NULL || plfText->lfFaceName[0] == _T('\0') || !m_fontText.CreateFontIndirect(plfText))
	{
		m_fontText.CreatePointFont(9 * 10, _T("MS Shell Dlg"));
		m_fontText.GetLogFont(&m_lfText);						//Initialize LOGFONT Structure
	}

	CFont* pFont = CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT));
	if (pFont)
	{
		LOGFONT lf;
		pFont->GetLogFont(&lf);
		if (m_fontDefault.m_hObject)
			m_fontDefault.DeleteObject();
		VERIFY( m_fontDefault.CreateFontIndirect(&lf) );

		lf.lfWeight = FW_BOLD;
		if (m_fontDefaultBold.m_hObject)
			m_fontDefaultBold.DeleteObject();
		VERIFY( m_fontDefaultBold.CreateFontIndirect(&lf) );
	}
}