// LogObjectA.h: interface for the CLogObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGOBJECT_H__4C988BAA_5E8B_4993_BC57_0A101D25233C__INCLUDED_)
#define AFX_LOGOBJECT_H__4C988BAA_5E8B_4993_BC57_0A101D25233C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	MAX_LOGSIZE		1024 //1K(1000��)
#define MAX_LOGCOUNT	50		// 10�� LOG POOL

class CLogObject  
{
private:
	struct __InnerLogParam__
	{
		short m_opcode;
		int m_length;
		TCHAR	pLog[MAX_LOGSIZE+1];
	};

	__InnerLogParam__ InnerLogparam[MAX_LOGSIZE];

public:
	CLogObject();
	virtual ~CLogObject();

protected:
	HANDLE m_hIOPORT;
	HANDLE m_hThread;
	DWORD  m_IDThread;
	long m_long_StartFlag;

	CString m_LogPath;
	CString m_Log_prefix;

	CString	m_CurrentFileName;
	short	m_curpos;

public:
	BOOL Get_StartFlag() { return (m_long_StartFlag == 1 ? TRUE : FALSE); }
	HANDLE Get_IOPORT() { return m_hIOPORT; }
	HANDLE Get_hThread() { return m_hThread; }
	DWORD Get_IDThread() { return m_IDThread; }

	void	SetCurrentLogFileName(LPCTSTR szLogFileName) { m_CurrentFileName = szLogFileName; }
	CString GetCurrentLogFileName() { return m_CurrentFileName; }

	void Start(LPCTSTR logpath, LPCTSTR prefix);
	void Stop();

	void LogHelper(short opcode, LPCTSTR plog);

protected:
	void Set_StartFlag(BOOL flag) { ::InterlockedExchange(&m_long_StartFlag, (flag == TRUE ? 1 : 0)); }
	static DWORD WINAPI LogInterface(LPVOID lp);
};

#endif // !defined(AFX_LOGOBJECT_H__4C988BAA_5E8B_4993_BC57_0A101D25233C__INCLUDED_)
