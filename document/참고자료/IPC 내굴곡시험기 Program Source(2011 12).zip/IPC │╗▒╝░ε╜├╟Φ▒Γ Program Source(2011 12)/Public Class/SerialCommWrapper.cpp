#include "StdAfx.h"
#include "SerialCommWrapper.h"


CSerialCommWrapper::CSerialCommWrapper(void)
{
	m_hIOPORT = NULL;
	m_hThread = NULL;
	m_IDThread = 0;

	ZeroMemory(m_DevName, 255);
	m_serialPacket.clear();
	m_sendCount = 0;

	m_long_StartFlag = 0;
	m_TimeOut = INFINITE;
}

CSerialCommWrapper::~CSerialCommWrapper(void) 
{
	RemoveAllSerialPacket();
}

BOOL CSerialCommWrapper::Start(LPTTYSTRUCT lpTTY, LPCTSTR pDevName, DWORD timeout/*=INFINITE*/)
{
	if(GetStartFlag() == FALSE)
	{
		::CopyMemory(&m_TTYInfo, lpTTY, sizeof(TTYSTRUCT));
		if(pDevName && lstrlen(pDevName)) lstrcpy(m_DevName, pDevName);
		if(timeout == 0)	timeout = INFINITE;
		m_TimeOut = timeout;

		m_hIOPORT = ::CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);
		m_hThread = ::CreateThread(NULL, 0, CSerialCommWrapper::InterfaceThread, this, 0, &m_IDThread);
		return TRUE;
	}
	else
		WarningLogStr(_T("WARRING : Already Started [CLIENTname(%s)]"), pDevName);
	return FALSE;
}

void CSerialCommWrapper::Stop()
{
	if ( m_hThread )
	{
		int nLoop = 0;
		while (!GetStartFlag() && nLoop++ < 500)
			::WaitForSingleObject(m_hThread, 10);

		if (m_hThread)
		{
			SetStartFlag(FALSE);

			::PostQueuedCompletionStatus(m_hIOPORT, 0, IOPORT_SHUTDOWN, NULL);
			::WaitForSingleObject(m_hThread, INFINITE);

			if(m_hIOPORT)
				::CloseHandle(m_hIOPORT);
			m_hIOPORT = NULL;
			
			if (m_hThread)
				::CloseHandle(m_hThread);

			m_hThread = NULL;
			m_IDThread = 0;
		}
	}
#ifdef	_DEBUG
	LogStr(NULL, _T("CSerialCommWrapper::Stop()"));
#endif
}

void CSerialCommWrapper::AddSerialPacket(short id, long nSize, byte* lpbuffer)
{
	_SerialPacket*	pPacket = NULL;
	pPacket = new _SerialPacket;
	if(pPacket == NULL) return;

	::ZeroMemory(pPacket, sizeof(_SerialPacket));
	pPacket->lpbuffer = new byte[nSize];
	if(pPacket->lpbuffer)
		::CopyMemory(pPacket->lpbuffer, lpbuffer, nSize);
	pPacket->nSize = nSize;

	m_serialPacket.insert(SERIALPACKET_OBJECT::value_type(id, pPacket));
}

void CSerialCommWrapper::RemoveSerialPacket(short id)
{
	SERIALPACKET_OBJECT::iterator iter;

	if(m_serialPacket.size())
	{
		for(iter = m_serialPacket.begin(); iter != m_serialPacket.end(); iter++)
		{
			_SerialPacket* pPacket = (_SerialPacket*)(*iter).second;
			if(pPacket && pPacket->lpbuffer)
				delete[] pPacket->lpbuffer;
			delete pPacket;
		}
		m_serialPacket.clear();
	}
}

void CSerialCommWrapper::RemoveAllSerialPacket()
{
	SERIALPACKET_OBJECT::iterator iter;

	if(m_serialPacket.size())
	{
		for(iter = m_serialPacket.begin(); iter != m_serialPacket.end(); iter++)
		{
			_SerialPacket* pPacket = (_SerialPacket*)(*iter).second;
			if(pPacket && pPacket->lpbuffer)
				delete[] pPacket->lpbuffer;
			delete pPacket;
		}
		m_serialPacket.clear();
	}
}

BOOL CSerialCommWrapper::SendSerialPacket()
{
	if(m_serialPacket.size())
	{
		SERIALPACKET_OBJECT::iterator iter = m_serialPacket.begin(); 
		if(iter != m_serialPacket.end())
		{
			_SerialPacket* pPacket = (_SerialPacket*)(*iter).second;
			if(pPacket->nSend < 3)		
			{
				LogStr(NULL, _T("SendSerialPacket Retry(%d)"), pPacket->nSend + 1);
				BOOL ret = SendData(pPacket->nSize, pPacket->lpbuffer);
				pPacket->nSend++;
				return ret;
			}

			WarningLogStr(_T("WARRING : SendSerialPacket Retry 3ȸ �ʰ� �Դϴ�. Packet �� ���� �մϴ�"));

			if(pPacket && pPacket->lpbuffer)
				delete[] pPacket->lpbuffer;
			delete pPacket;

			m_serialPacket.erase(iter);
		}
	}

	return FALSE;
}

BOOL CSerialCommWrapper::SendData(long nSize, byte* lpbuffer)
{
	if(GetStartFlag() == TRUE)
	{
		if(nSize > 0 && lpbuffer != NULL)
		{
			__InnerSerialWrapper__* pParam = new __InnerSerialWrapper__;
			pParam->port = m_TTYInfo.byCommPort;
			pParam->nSize = nSize;
			if(nSize)
			{
				pParam->lpbuffer = new byte[nSize];
				::CopyMemory(pParam->lpbuffer, lpbuffer, nSize);
			}
			if(GetStartFlag() == TRUE)
				::PostQueuedCompletionStatus(m_hIOPORT, sizeof(__InnerSerialWrapper__), __INNERP_SERIAL_WRAPPER, (LPOVERLAPPED)pParam);
			else
			{
				delete pParam;
				return FALSE;
			}

			return TRUE;
		}
		else	return FALSE;
	}
	return FALSE;
}


void CSerialCommWrapper::SetConnectionInfo(LPTTYSTRUCT lpTTY)
{
	::CopyMemory(&m_TTYInfo, lpTTY, sizeof(TTYSTRUCT));

	if(GetStartFlag() == TRUE)	
	{
		__InnerSerialWrapper__* pParam = new __InnerSerialWrapper__;
		pParam->port = m_TTYInfo.byCommPort;

		TTYSTRUCT* pTTY = new TTYSTRUCT;
		pParam->nSize = sizeof(TTYSTRUCT);
		pParam->lpbuffer = new byte[sizeof(TTYSTRUCT)];
		::CopyMemory(pParam->lpbuffer, lpTTY, sizeof(TTYSTRUCT));

		if(GetStartFlag() == TRUE)
			::PostQueuedCompletionStatus(m_hIOPORT, sizeof(__InnerSerialWrapper__), __INNERP_SERIAL_SETUPCONNECTION, (LPOVERLAPPED)pParam);
		else
			delete pParam;
	}
}

void CSerialCommWrapper::CloseConnection()
{
	if(GetStartFlag() == TRUE)	
	{
		__InnerSerialWrapper__* pParam = new __InnerSerialWrapper__;
		pParam->port = m_TTYInfo.byCommPort;

		if(GetStartFlag() == TRUE)
			::PostQueuedCompletionStatus(m_hIOPORT, sizeof(__InnerSerialWrapper__), __INNERP_SERIAL_CLOSECONNECTION, (LPOVERLAPPED)pParam);
		else
			delete pParam;
	}
}

DWORD WINAPI CSerialCommWrapper::InterfaceThread(LPVOID lpParameter)
{
	HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);

	CSerialCommWrapper* pParent = (CSerialCommWrapper*)lpParameter;
	HANDLE  hPort;

	DWORD UserKey;					
	DWORD NumberOfBytesTransferred;	
	LPOVERLAPPED lpOverlapped;	

	DWORD timeout = INFINITE;
	BOOL bContinue = TRUE;
	BOOL bStatus;
	LPTSTR pLogStr = NULL;
	TTYEvent* pEvent = NULL;

	if(pParent == NULL)
	{	
		pParent->ErrorLogStr(_T("ERROR : Parent Pointer is NULL"));
		pParent->ShutDownService();
		return 0;
	}

	hPort = pParent->Get_IOPORT();
	timeout = pParent->m_TimeOut;
	if(pParent->m_TTYInfo.byCommPort == 0 || hPort == NULL)
	{
		pParent->ErrorLogStr(_T("ERROR : IOPORT Handle == NULL [DevName(%s),PORT(%d)]"), 
			pParent->m_DevName, pParent->m_TTYInfo.byCommPort);
		pParent->ShutDownService();
		return 0;
	}

	pParent->SetConnection(FALSE);

	CSerialComm	Client;
	Client.Start(pParent->Get_IOPORT(), &pParent->m_TTYInfo, pParent->m_DevName);

	pParent->SetStartFlag(TRUE);
	pParent->LogStr(NULL, _T("SerialComm Service started [DevName(%s),PORT(%d)"), 
					pParent->m_DevName, pParent->m_TTYInfo.byCommPort);

	while(bContinue)
	{
		bStatus = ::GetQueuedCompletionStatus(hPort, &NumberOfBytesTransferred, &UserKey, &lpOverlapped, timeout);
		if(bStatus == FALSE)
		{
			if(lpOverlapped != NULL)	
			{
			}
			else
				pParent->TimeOutFunction(Client);
			continue;
		}

		switch(UserKey)
		{
		case IOPORT_SHUTDOWN:
			bContinue = FALSE;
			break;

		case SERIAL_COMM_START:
			pParent->OnStart(Client);
			break;

		case SERIAL_COMM_ERROR:
			pEvent = (TTYEvent*)lpOverlapped;
			if(pEvent)	
			{
				pParent->Error(pEvent->result, Client);
				::CoTaskMemFree(pEvent);
				pParent->SetConnection(FALSE);
				pEvent = NULL;
			}
			break;

		case SERIAL_COMM_CONNECT:					
			pEvent = (TTYEvent*)lpOverlapped;
			if(pEvent)	
			{
				pParent->OnConnect(pEvent, Client);
				::CoTaskMemFree(pEvent);
				pParent->SetConnection(TRUE);
				pEvent = NULL;
			}
			break;

		case SERIAL_COMM_RECEIVE:			
			pEvent = (TTYEvent*)lpOverlapped;
			if(pEvent)	
			{
				pParent->OnReceive(pEvent, Client);
				if(pEvent->pdata) ::CoTaskMemFree(pEvent->pdata);
				::CoTaskMemFree(pEvent);
				pEvent = NULL;
			}
			break;

		case SERIAL_COMM_CLOSE:
			pEvent = (TTYEvent*)lpOverlapped;
			if(pEvent)
			{
				pParent->OnClose(pEvent, Client);
				pParent->SetConnection(FALSE);
				::CoTaskMemFree(pEvent);
				pEvent = NULL;
			}
			break;

		case __INNERP_SERIAL_SETUPCONNECTION:
			if(NumberOfBytesTransferred == sizeof(__InnerSerialWrapper__))
			{
				__InnerSerialWrapper__* pParam;
				pParam = (__InnerSerialWrapper__*)lpOverlapped;
				if(pParam != NULL)
				{
					if(pParent->bConnectFlag == FALSE)
					{
						delete pParam;
						break;
					}
					
					LPTTYSTRUCT lpTTY = (LPTTYSTRUCT)pParam->lpbuffer;
					BOOL result = Client.SetupConnection(lpTTY, (pParent->bConnectFlag == TRUE)? false : true);
					if(result == TRUE)
					{
						pParent->SetConnection(TRUE);
					}
					delete pParam;
				}
			}
			break;

		case __INNERP_SERIAL_WRAPPER:
			if(NumberOfBytesTransferred == sizeof(__InnerSerialWrapper__))
			{
				__InnerSerialWrapper__* pParam;
				pParam = (__InnerSerialWrapper__*)lpOverlapped;
				if(pParam != NULL)
				{
					if(pParent->bConnectFlag == FALSE)
					{
						delete pParam;
						break;
					}
					
					BOOL result = Client.WriteCommBlock(pParam->lpbuffer, pParam->nSize);
					if(result == S_OK)
					{
#ifdef	_IPC_SIMULATOR_
						TCHAR strMsg[1024];
						lstrcpy(strMsg, _T("SEND="));

						for(int i = 0; i < pParam->nSize; i++)
							sprintf(strMsg, _T("%s0x%02X "), strMsg, pParam->lpbuffer[i]);

//						TRACE(strMsg);
						pParent->LogStr(1, strMsg);
#endif
					}
					else	
					{
						pParent->Error(result, Client);
						pParent->SetConnection(FALSE);
					}
					delete pParam;
				}
			}
			break;

		case __INNERP_SERIAL_CLOSECONNECTION:
			if(NumberOfBytesTransferred == sizeof(__InnerSerialWrapper__))
			{
				__InnerSerialWrapper__* pParam;
				pParam = (__InnerSerialWrapper__*)lpOverlapped;
				if(pParam != NULL)
				{
					BOOL result = Client.Disconnect();
					if(result != TRUE)
					{
					}
					delete pParam;
				}
			}
			break;

		default:
			pParent->OnUnknownMsg(UserKey, lpOverlapped, Client);
			break;
		}
	}

	Client.Stop();

	pParent->SetStartFlag(FALSE);
	pParent->LogStr(NULL, _T("Serial Service was stopped [CLIENTname(%s)]"),	pParent->m_DevName);

	if (pParent->m_hThread)
		::CloseHandle(pParent->m_hThread);
	pParent->m_hThread = NULL;

	::CoUninitialize();
	return 0;
}