#pragma once

#define MAX_RXBLOCK		80


// flow control
#define FC_DTRDSR  0x01
#define FC_RTSCTS  0x02
#define FC_XONXOFF 0x04

#define ASCII_XON  0x11
#define ASCII_XOFF 0x13

#define TTY_ERROR_0		1000	
#define TTY_ERROR_1		1001	
#define TTY_ERROR_2		1002	
#define TTY_ERROR_3		1003	
#define TTY_ERROR_4		1004	
#define TTY_ERROR_5		1005	
#define TTY_ERROR_6		1006	
#define TTY_ERROR_7		1007	
#define TTY_ERROR_8		1008	
#define TTY_ERROR_9		1009	
#define TTY_ERROR_10	1010	
#define TTY_ERROR_11	1011	
#define TTY_ERROR_12	1012	
#define TTY_ERROR_13	1013	
#define TTY_ERROR_14	1014	
#define TTY_ERROR_15	1015	
#define TTY_ERROR_16	1016	


typedef struct _TTY_Event
{
	short			ttyid;
	char			commdev[20];
	time_t			eventtime;
	unsigned long	datasize;
	unsigned char*	pdata;
	void*			pParam;
	unsigned long	result;
} TTYEvent, *LPTTYEvent;

enum _SERIAL_IOPORT_
{
    SERIAL_COMM_CONNECT		= 110001,
    SERIAL_COMM_CLOSE,
    SERIAL_COMM_RECEIVE,
    SERIAL_COMM_START,
	SERIAL_COMM_STOP,

	SERIAL_COMM_ERROR,

	SERIAL_CLIENT_CLOSE,
};

typedef struct _TTYSTRUCT
{
   BYTE byCommPort;				
   BYTE byXonXoff;
   BYTE byByteSize; 
   BYTE byFlowCtrl;
   BYTE byParity; 
   BYTE byStopBits;
   DWORD dwBaudRate;

} TTYSTRUCT, *LPTTYSTRUCT;


typedef struct _CONNECTION 
{
   HANDLE m_hCommPort;
   BOOL bConnected;
   OVERLAPPED osWrite;
   OVERLAPPED osRead;
   DWORD dwThreadID;

} CONNECTION, *LPCONNECTION;

class CSerialComm
{
public:
	CSerialComm(void);
	virtual ~CSerialComm(void);

	BOOL Start(HANDLE hParentPort, LPTTYSTRUCT lpTTY, LPCTSTR pCommName);
	void Stop();

	BOOL GetStartFlag()				{ return m_long_StartFlag;	}
	void Lock()						{ ::EnterCriticalSection ( &m_csLock ); }	
	void UnLock()					{ ::LeaveCriticalSection ( &m_csLock ); }

	BOOL Connect(LPTTYSTRUCT lpTTY);
	BOOL Disconnect();

	BOOL IsConnected() const;
	BOOL SetupConnection(LPTTYSTRUCT lpTTY, bool bReconnect = false);

	BOOL WriteCommBlock(LPBYTE lpszBlock , DWORD dwBytesToWrite);

protected:
	HANDLE	m_hThreadTerm ;					
	HANDLE	m_hThreadHandle;
	DWORD	m_ThreadID;

	HANDLE	m_hParentPort;					
	ULONG	m_lParentThread;				

 	long	m_long_StartFlag;

	TTYSTRUCT	m_TTY;

	TCHAR		m_CommName[20];
	
	HANDLE		m_hCommPort;
	BOOL		bConnected;
	OVERLAPPED	osWrite;
	OVERLAPPED	osRead;
	DWORD		dwThreadID;

private:
	CRITICAL_SECTION	m_csLock;


protected:

	BOOL	CreateSerialPort(LPTTYSTRUCT lpTTY);
	int		ReadCommBlock(LPBYTE lpszBlock, DWORD nLen);


	void	SetStartFlag(BOOL flag) { ::InterlockedExchange(&m_long_StartFlag, (flag == TRUE ? 1 : 0)); }

	static DWORD WINAPI ListenProc(LPVOID lpParameter);
};
