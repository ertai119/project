#pragma once

#include "..\\Object\\MyObject.h"

class cXenEditBox : public CEdit, public cPatrickTransparent
{
private:
	DECLARE_DYNAMIC(cXenEditBox)

public:
	
	cXenEditBox();
	virtual ~cXenEditBox();

protected:

	BOOL		m_bHasFocus;	

public:

	bool		Create( DWORD dwStyle, RECT rect, CWnd *ParentWnd, unsigned int UID = -1 );
	int			AddLine( TCHAR *pStr );
	void		Clear();

	HRESULT		Save( TCHAR *pFileName );
	HRESULT		LoadFromFile( TCHAR *pFileName );

protected:

	void DrawEdit();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:

	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnSetFocus();
	afx_msg void OnKillFocus();
	afx_msg void OnEditUpdate();
	afx_msg void OnSysColorChange();
	afx_msg HRESULT OnMouseLeave( WPARAM, LPARAM );

	DECLARE_MESSAGE_MAP()
};
