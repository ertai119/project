// XenButton.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "XenButton.h"
#include ".\xenbutton.h"


// cXenButton
IMPLEMENT_DYNAMIC(cXenButton, CButton)

BEGIN_MESSAGE_MAP(cXenButton, CButton)
		ON_WM_ERASEBKGND()
		ON_WM_MOUSEMOVE()
		ON_WM_LBUTTONDOWN()
		ON_WM_LBUTTONUP()
		// PatrickLee Added -----
		ON_WM_LBUTTONDBLCLK()
		// ----------------------
		ON_MESSAGE(WM_MOUSELEAVE,OnMouseLeave)
		ON_MESSAGE(WM_SETTEXT, OnSetText)
		ON_WM_CTLCOLOR_REFLECT()

		ON_WM_PAINT()
END_MESSAGE_MAP()
//-------------------------------------------------------------------------------------------------------------

cXenButton::cXenButton()
{
	m_ActivePagehWnd	= NULL;
	m_Checked			= false;	
	m_Type				= XEN_BTN_PUSH; 
	m_Group				= NULL;
	m_Font				= NULL;
	m_ImageList			= NULL;
	m_nStartImageIndex  = -1;
	m_ImageIconList		= NULL;
	m_nIconIndex		= -1;

	m_style				= XEN_BTN_FLAT;
	m_Stat				= XEN_BTN_ENABLE;

	m_bForceOwnerDraw	= FALSE; //Added on 2005/11/17
	m_bIsPainted		= FALSE;

	// PatrickLee Added --------------
	m_ptTextOffset.x	= 0;
	m_ptTextOffset.y	= 0;
	// -------------------------------
}
//-------------------------------------------------------------------------------------------------------------

cXenButton::~cXenButton()
{
}
//-------------------------------------------------------------------------------------------------------------

bool cXenButton::Create( LPCTSTR lpszCaption, DWORD dwStyle, RECT rect, CWnd *ParentWnd, unsigned int UID
						, XEN_BUTTON_TYPE nType, cBtnGrouping *Group, CWnd *ActivePage )
{
	m_This				= this;
	m_Owner				= ParentWnd;

	m_Caption			= lpszCaption;
	m_Rect				= rect;
	m_DrawRect.SetRect( 0, 0, m_Rect.right - m_Rect.left, m_Rect.bottom - m_Rect.top );
	m_UID				= UID;
	m_Align				= DT_CENTER | DT_VCENTER | DT_SINGLELINE ;

	m_Type				= nType;
	m_Group				= Group;
	m_ActivePagehWnd	= ActivePage;

	m_bForceOwnerDraw	= ((BS_OWNERDRAW & dwStyle) == BS_OWNERDRAW) ? TRUE : FALSE;

	CButton::Create( lpszCaption, dwStyle, rect, ParentWnd, UID );

	if( m_Group )
	{
		m_Group->Insert( m_UID, this );
		if( m_Group->Size() == 1 )
		{
			m_Group->SetActive( UID );	
		}
	}

	return true;
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::MoveWindow( LPCRECT lpRect, BOOL bRepaint )
{
	m_Rect				= lpRect;
	CButton::MoveWindow( m_Rect, bRepaint );
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::MoveWindow( int x, int y, int nWidth, int nHeight, BOOL bRepaint )
{
	m_Rect.SetRect( x, y, nWidth, nHeight ) ;
	CButton::MoveWindow( x, y, nWidth, nHeight, bRepaint );
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::SetImageList( CImageList *pImageList, int nStartIndex )
{
	m_ImageList			= pImageList;
	m_nStartImageIndex	= nStartIndex;
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::SetIcon( CImageList *pImageList, int nStartIndex )
{
	m_ImageIconList = pImageList;
	m_nIconIndex	= nStartIndex;
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::GetSize( CRect *rect )
{
	HGDIOBJ    hOldFont;
	CSize size;
	CPaintDC dc(this); 

	if( m_Font )
		hOldFont = dc.SelectObject( m_Font->m_hObject );

	size	 = dc.GetTextExtent( m_Caption.GetString() );

	CRect Rect;

	if( m_ImageIconList )
	{
		int nIconSizex = 0;
		int nIconSizey = 0;

		::ImageList_GetIconSize( m_ImageIconList->m_hImageList, &nIconSizex, &nIconSizey );

		Rect.SetRect( 0, 0, size.cx + 4 + nIconSizex + 2, size.cy + 4 );
	}
	else
		Rect.SetRect( 0, 0, size.cx + 4, size.cy + 4 );
	
	if( rect )
	{
		rect->SetRect( Rect.left, Rect.top, Rect.right, Rect.bottom );
	}

	if( m_Font )
		dc.SelectObject( hOldFont );
}
//-------------------------------------------------------------------------------------------------------------

BOOL cXenButton::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}
//-------------------------------------------------------------------------------------------------------------

LRESULT cXenButton::OnSetText(WPARAM wParam, LPARAM lParam)
{
	LRESULT Result = Default();
	CRect Rect;
	GetWindowRect(&Rect);
	GetParent()->ScreenToClient(&Rect);
	GetParent()->InvalidateRect(&Rect);
	GetParent()->UpdateWindow();

	return Result;
}
//-------------------------------------------------------------------------------------------------------------

HBRUSH cXenButton::CtlColor(CDC* pDC, UINT nCtlColor)
{
	if ( m_bForceOwnerDraw ) 
		return NULL;

	if ( m_bIsPainted )
		return NULL;

	if (CTLCOLOR_STATIC == nCtlColor)
	{
		if (m_Font) 
			pDC->SelectObject( m_Font );
		pDC->SetTextColor( m_clrFont );
		pDC->SetBkMode( TRANSPARENT );
	}

	DrawTransparent(pDC);
	return (HBRUSH)GetStockObject(NULL_BRUSH);
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::DrawItem( LPDRAWITEMSTRUCT lpDIS) 
{
	int		nIconSizex = 0, nIconSizey = 0, nOffPosy = 0;
	int		nImagex    = 0, nImagey    = 0;
	int		nIconx     = 1, nIcony     = 0;

	HFONT	hOldFont;
	CDC* pDC = CDC::FromHandle(lpDIS->hDC); //Patrick Added

	if( m_Font )
	{
		hOldFont = (HFONT)SelectObject( lpDIS->hDC, m_Font->m_hObject );
	}

	GetClientRect( m_DrawRect );
	
	if ( m_bDrawTransparent )
		DrawTransparent( pDC );
	else
		pDC->FillSolidRect( &m_DrawRect, m_clrBtnFace );

	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor( m_clrFont );

	if( m_ImageIconList )
	{
		::ImageList_GetIconSize( m_ImageIconList->m_hImageList, &nIconSizex, &nIconSizey );
		m_DrawRect.left += nIconSizex;
		nOffPosy		 = (m_DrawRect.bottom - nIconSizey ) / 2;	
	}

	if( m_ImageList )
	{
		::ImageList_GetIconSize( m_ImageList->m_hImageList, &nImagex, &nImagey );
	}

	if( m_Stat == XEN_BTN_DISABLE )
	{
		if( !m_ImageList )
		{
			switch( m_style )
			{
			case XEN_BTN_FLAT:
				break;
			case XEN_BTN_DOTNET:
				break;
			case XEN_BTN_3D:
				break;
			}
		}

		if( m_ImageList )
		{
			m_ImageList->DrawIndirect( CDC::FromHandle(lpDIS->hDC)
				,m_nStartImageIndex + XEN_BTN_DISABLE
				,CPoint( 0, 0 ) //��� ��ġ
				,CSize( nImagex, nImagey ) 
				,CPoint( 0, 0 ));
		}

		if( m_ImageIconList )
		{
			m_ImageIconList->DrawIndirect(CDC::FromHandle(lpDIS->hDC)
				,m_nIconIndex
				,CPoint( 1, nOffPosy )
				,CSize( nIconSizex, nIconSizey ) 
				,CPoint( 0, 0 ));
		}

		SetTextColor( lpDIS->hDC, GetSysColor(COLOR_GRAYTEXT) );
		
		if( m_Caption.GetLength() > 0 )
		// PatrickLee Modified --------------
		{
			m_DrawRect.left += m_ptTextOffset.x; m_DrawRect.top += m_ptTextOffset.y;
			DrawText( lpDIS->hDC, m_Caption.GetString(), m_Caption.GetLength(), m_DrawRect, m_Align );
		}
		// ----------------------------------

		if( m_Font )
		{
			SelectObject( lpDIS->hDC, hOldFont );
		}

		return ;
	}

	if( m_Type == XEN_BTN_PUSH )
	{//
		if (lpDIS->itemState & ODS_SELECTED )
		{
			short nIConset = 0;
			if( !m_ImageList )
			{
				switch( m_style )
				{
				case XEN_BTN_FLAT:
					{
						CRect tempDrawRect( m_DrawRect.left - nIconSizex, m_DrawRect.top, m_DrawRect.right, m_DrawRect.bottom );
						pDC->Draw3dRect( tempDrawRect, m_clrBtnShadow, m_clrBtnHilite );
						nIConset = 1;
					}
					break;
				case XEN_BTN_DOTNET:
					{
						CRect tempDrawRect( m_DrawRect.left - nIconSizex, m_DrawRect.top, m_DrawRect.right, m_DrawRect.bottom );
						pDC->FillSolidRect( &tempDrawRect, m_clrClick );
						pDC->Draw3dRect( tempDrawRect, m_clrBtnHighlight, m_clrBtnHighlight );
					}
					break;
				case XEN_BTN_3D:
					break;
				}
			}
			
			if( m_ImageList )
			{
				m_ImageList->DrawIndirect( CDC::FromHandle(lpDIS->hDC)
					,m_nStartImageIndex + XEN_BTN_CLICK
					,CPoint( 0, 0 ) 
					,CSize( nImagex, nImagey ) 
					,CPoint( 0, 0 ));
			}

			if( m_ImageIconList )
			{
				m_ImageIconList->DrawIndirect(CDC::FromHandle(lpDIS->hDC)
					,m_nIconIndex
					,CPoint( nIconx + nIConset, nOffPosy + nIConset) //��� ��ġ
					,CSize( nIconSizex, nIconSizey ) 
					,CPoint( 0, 0 ));
			}

			if( m_Caption.GetLength() > 0 )
			{
				CRect tempDrawRect( m_DrawRect.left + 1, m_DrawRect.top + 1, m_DrawRect.right + 1, m_DrawRect.bottom + 1 );

				if( m_style == XEN_BTN_DOTNET )
				{
					tempDrawRect = m_DrawRect;
				}

				// PatrickLee Modified --------------
				tempDrawRect.left += m_ptTextOffset.x; tempDrawRect.top += m_ptTextOffset.y;
				DrawText( lpDIS->hDC, m_Caption.GetString(), m_Caption.GetLength(), tempDrawRect, m_Align );
				// ----------------------------------
			}
		}
		else
		{
			if( m_Stat == XEN_BTN_ENABLE || m_Stat == XEN_BTN_CLICK )
			{
				short nIConset = 0;

				if( !m_ImageList )
				{
					switch( m_style )
					{
					case XEN_BTN_FLAT:
						break;
					case XEN_BTN_DOTNET:
						break;
					case XEN_BTN_3D:
						break;
					}
				}

				if( m_ImageList )
				{
					m_ImageList->DrawIndirect( CDC::FromHandle(lpDIS->hDC)
						,m_nStartImageIndex + XEN_BTN_ENABLE
						,CPoint( 0, 0 ) //��� ��ġ
						,CSize( nImagex, nImagey ) 
						,CPoint( 0, 0 ));
				}

				if( m_ImageIconList )
				{
					m_ImageIconList->DrawIndirect(CDC::FromHandle(lpDIS->hDC)
						,m_nIconIndex
						,CPoint( nIconx + nIConset, nOffPosy + nIConset) //��� ��ġ
						,CSize( nIconSizex, nIconSizey ) 
						,CPoint( 0, 0 ));
				}

				if( m_Caption.GetLength() > 0 )
				// PatrickLee Modified --------------
				{
					m_DrawRect.left += m_ptTextOffset.x; m_DrawRect.top += m_ptTextOffset.y;
					DrawText( lpDIS->hDC, m_Caption.GetString(), m_Caption.GetLength(), m_DrawRect, m_Align );
				}
				// ----------------------------------
			}
			else if( m_Stat == XEN_BTN_OVER )
			{
				short nIConset = 0;

				if( !m_ImageList )
				{
					switch( m_style )
					{
					case XEN_BTN_FLAT:
						{
							CRect tempDrawRect( m_DrawRect.left - nIconSizex, m_DrawRect.top, m_DrawRect.right, m_DrawRect.bottom );
							pDC->Draw3dRect( tempDrawRect, m_clrBtnHilite, m_clrBtnShadow );
						}
						break;
					case XEN_BTN_DOTNET:
						{
							CRect tempDrawRect( m_DrawRect.left - nIconSizex, m_DrawRect.top, m_DrawRect.right, m_DrawRect.bottom );
							pDC->FillSolidRect( &tempDrawRect, m_clrOver );
							pDC->Draw3dRect( tempDrawRect, m_clrBtnHighlight, m_clrBtnHighlight );
							nIConset = -1;
						}
						break;
					case XEN_BTN_3D:
						break;
					}
				}

				if( m_ImageList )
				{
					m_ImageList->DrawIndirect( CDC::FromHandle(lpDIS->hDC)
						,m_nStartImageIndex + XEN_BTN_OVER
						,CPoint( 0, 0 ) //��� ��ġ
						,CSize( nImagex, nImagey ) 
						,CPoint( 0, 0 ));
				}

				if( m_ImageIconList )
				{
					m_ImageIconList->DrawIndirect(CDC::FromHandle(lpDIS->hDC)
						,m_nIconIndex
						,CPoint( nIconx + nIConset, nOffPosy + nIConset ) //��� ��ġ
						,CSize( nIconSizex, nIconSizey ) 
						,CPoint( 0, 0 ));
				}
				
				if( m_Caption.GetLength() > 0 )
				{
					CRect tempDrawRect = m_DrawRect;

					if( m_style == XEN_BTN_DOTNET )
					{
						tempDrawRect.SetRect( m_DrawRect.left - 1, m_DrawRect.top - 1, m_DrawRect.right - 1, m_DrawRect.bottom - 1 );
					}

					// PatrickLee Modified --------------
					tempDrawRect.left += m_ptTextOffset.x; tempDrawRect.top += m_ptTextOffset.y;
					DrawText( lpDIS->hDC, m_Caption.GetString(), m_Caption.GetLength(), tempDrawRect, m_Align );
					// ----------------------------------
				}
			}
		}
	}
	else
	{
		if( m_ImageList )
		{
			m_ImageList->DrawIndirect( CDC::FromHandle(lpDIS->hDC)
				,m_nStartImageIndex + m_Stat
				,CPoint( 0, 0 ) 
				,CSize( nImagex, nImagey ) 
				,CPoint( 0, 0 ));
		}

		if( m_ImageIconList )
		{
			m_ImageIconList->DrawIndirect(CDC::FromHandle(lpDIS->hDC)
				,m_nIconIndex
				,CPoint( nIconx, nOffPosy ) 
				,CSize( nIconSizex, nIconSizey ) 
				,CPoint( 0, 0 ));
		}

		if( m_Stat == XEN_BTN_ENABLE )
		{
		}
		else if( m_Stat == XEN_BTN_CLICK )
		{
		}
		else if( m_Stat == XEN_BTN_OVER )
		{
		}
		else if( m_Stat == XEN_BTN_CLICKOVER )
		{
		}

		if( m_Caption.GetLength() > 0 )
		// PatrickLee Modified --------------
		{
			m_DrawRect.left += m_ptTextOffset.x; m_DrawRect.top += m_ptTextOffset.y;
			DrawText( lpDIS->hDC, m_Caption.GetString(), m_Caption.GetLength(), m_DrawRect, m_Align );
		}
		// ----------------------------------
	}

	if( m_Font )
	{
		SelectObject( lpDIS->hDC, hOldFont );
	}

}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::OnMouseMove(UINT nFlags, CPoint point)
{
	if (m_bForceOwnerDraw )
	{
		if( m_Stat != XEN_BTN_OVER && m_Stat != XEN_BTN_CLICKOVER)
		{
			if( m_Stat != XEN_BTN_CLICK && m_Type == XEN_BTN_PUSH )
				m_Stat = XEN_BTN_OVER;
			else if( m_Type != XEN_BTN_PUSH )
			{
				if( m_Checked )
					m_Stat = XEN_BTN_CLICKOVER;
				else
					m_Stat = XEN_BTN_OVER;
			}

			TRACKMOUSEEVENT t = { sizeof(TRACKMOUSEEVENT), TME_LEAVE, m_hWnd, 0 };
			TrackMouseEvent(&t);

			//Patrick Modified ------------
			Invalidate(FALSE);
			// ----------------------------
		}
	}
	else
		Default();

	CButton::OnMouseMove( nFlags, point );
}
//-------------------------------------------------------------------------------------------------------------

HRESULT cXenButton::OnMouseLeave(WPARAM, LPARAM)
{
	if (m_bForceOwnerDraw )
	{
		if( m_Stat == XEN_BTN_OVER || m_Stat == XEN_BTN_CLICKOVER )
		{
			if( m_Type != XEN_BTN_PUSH )
			{
				if( !m_Checked ) 
				{
					m_Stat	  = XEN_BTN_ENABLE;
				}
				else 
				{
					m_Stat	  = XEN_BTN_CLICK;
				}
			}
			else
				m_Stat = XEN_BTN_ENABLE;

			// Patrick Modified ----
			Invalidate(FALSE);
			// ---------------------
		}
	}
	else
		Default();

	return 0;
}
//-------------------------------------------------------------------------------------------------------------

// PatrickLee Added -------------------
void cXenButton::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	SendMessage(WM_LBUTTONDOWN, nFlags, MAKELPARAM(point.x, point.y));
}
// -------------------------------------
//-------------------------------------------------------------------------------------------------------------

void cXenButton::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_bForceOwnerDraw )
	{
		if( m_Type == XEN_BTN_PUSH )
		{
			m_Stat = XEN_BTN_ENABLE;
			Invalidate(FALSE);
		}
	}
	// PatrickLee Deleted ----------
	//else
	//	Default();
	// -----------------------------

	CButton::OnLButtonUp( nFlags, point );
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_bForceOwnerDraw )
	{
		if( m_Type == XEN_BTN_RADIO  && m_Group )
		{
			if( m_Checked )
				return;

			m_Group->SetActive( m_UID );

			LONG	MSG;

			MSG =  m_UID;
			MSG += (BN_CLICKED<<16);
			::SendMessage( ((CWnd*)m_Owner)->m_hWnd , WM_COMMAND, MSG, (LPARAM)m_hWnd );

			return;
		}
		else if(  m_Type == XEN_BTN_CHECK )// && m_Group )
		{
			MySetStat( m_Checked ? XEN_BTN_ENABLE : XEN_BTN_CLICK );
			SetChecked( m_Checked ? false : true );
			Invalidate(FALSE);
			
			LONG	MSG;

			MSG =  m_UID;
			MSG += (BN_CLICKED<<16);
			::SendMessage( ((CWnd*)m_Owner)->m_hWnd , WM_COMMAND, MSG, (LPARAM)m_hWnd );

			return;
		}

		m_Stat = XEN_BTN_CLICK;
		Invalidate(FALSE);
	}

	CButton::OnLButtonDown( nFlags, point );
}
//-------------------------------------------------------------------------------------------------------------

void cXenButton::OnPaint()
{
	m_bIsPainted = FALSE;
	CButton::OnPaint();
	m_bIsPainted = TRUE;
}