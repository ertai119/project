#pragma once

#include "GroupingButton.h"

class cXenButton : public CButton,  public cPatrickTransparent
{
private:
	
	DECLARE_DYNAMIC(cXenButton)

public:

	cXenButton();
	virtual ~cXenButton();

	bool			Create( LPCTSTR lpszCaption, DWORD dwStyle, RECT rect, CWnd *ParentWnd
						, unsigned int UID, XEN_BUTTON_TYPE nType = XEN_BTN_PUSH
						, cBtnGrouping *Group = NULL, CWnd *ActivePage = NULL );

	void		    Enable(){ m_Stat = XEN_BTN_ENABLE; EnableWindow(TRUE);	}
	void		    Disable(){ m_Stat = XEN_BTN_DISABLE; EnableWindow(FALSE); }
	
	void		    SetImageList( CImageList *pImageList, int nStartIndex );	
	void		    SetIcon( CImageList *pImageList, int nStartIndex );	
	
	void			SetFont( CFont *pFont ){ MySetFont(pFont); CButton::SetFont( pFont ); }
	void			SetAlign( unsigned int Align ){  m_Align = Align; }
	void			SetCaption( LPCTSTR Caption ){ m_Caption = Caption; SetWindowText(m_Caption); }

	void			SetGroup( cBtnGrouping* pGroup){ m_Group = pGroup; }
	void			SetChecked( bool Checked ){ m_Checked = Checked; }
	void			SetActivePage( CWnd *ActivePage ){ m_ActivePagehWnd = ActivePage; }

	void			GetSize( CRect *rect = NULL );
	bool			GetChecked(){return m_Checked; }
	CWnd		   *GetActivePage(){return m_ActivePagehWnd;}

	void			MoveWindow( LPCRECT lpRect, BOOL bRepaint = 1 );
	void			MoveWindow(	int x, int y, int nWidth, int nHeight, BOOL bRepaint = 1 );

	// PatrickLee Added --------------
	void			SetTextOffset(int nLeft, int nTop) { m_ptTextOffset.x = nLeft; m_ptTextOffset.y = nTop; }
	void			SetTextOffset(CPoint pt) { m_ptTextOffset = pt; }
	// -------------------------------

protected:

	short			m_Type;

	CRect			m_Rect;
	CRect			m_DrawRect;

	cBtnGrouping   *m_Group;		  
	CWnd		   *m_ActivePagehWnd; 

	bool			m_Checked;		  

	unsigned int	m_Align;
	CString			m_Caption;

	// PatrickLee Added ------------
	CPoint			m_ptTextOffset;
	// -----------------------------
	unsigned int	m_UID;
	
	CImageList	   *m_ImageList;
	int			    m_nStartImageIndex;

	CImageList	   *m_ImageIconList;
	int			    m_nIconIndex;

	BOOL			m_bIsPainted;
	
	DECLARE_MESSAGE_MAP()

	virtual void	DrawItem( LPDRAWITEMSTRUCT lpDIS );
	
	afx_msg void	OnMouseMove( UINT nFlags, CPoint point );
	afx_msg HRESULT OnMouseLeave( WPARAM, LPARAM );

	afx_msg void	OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void	OnLButtonDown(UINT nFlags, CPoint point);
	// PatrickLee Added ----------------
	afx_msg void	OnLButtonDblClk(UINT nFlags, CPoint point);
	// ---------------------------------
	afx_msg BOOL	OnEraseBkgnd(CDC* pDC);
	afx_msg LRESULT OnSetText(WPARAM wParam, LPARAM lParam);
	afx_msg HBRUSH	CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void	OnPaint();
};
