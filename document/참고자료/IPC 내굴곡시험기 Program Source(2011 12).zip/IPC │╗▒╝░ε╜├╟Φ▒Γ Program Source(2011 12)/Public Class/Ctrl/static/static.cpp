
#include "stdafx.h"
#include "static.h"

IMPLEMENT_DYNAMIC(cXenStatic, CStatic)

BEGIN_MESSAGE_MAP(cXenStatic, CStatic)
	// Patrick Added for HyperLink --------------
	//{{AFX_MSG_MAP(CHyperlinkStatic)
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
	// ------------------------------------------
	ON_MESSAGE(WM_SETTEXT, OnSetText)
	ON_WM_CTLCOLOR_REFLECT()
END_MESSAGE_MAP()
//-------------------------------------------------------------------------------------------------------------

cXenStatic::cXenStatic()
{
	// Patrick Added for HyperLink -------------------
	m_Caption.Empty();
	m_sHyperLink.Empty();
	m_bMouseInControl = m_bGetCaptionSize = m_bHyperLink = m_bCreateFont = false;

	m_hHandCursor = ::LoadCursor(0, MAKEINTRESOURCE(IDC_HAND));
	m_hArrowCursor = ::LoadCursor(0, MAKEINTRESOURCE(IDC_ARROW));
	// -----------------------------------------------

	m_style				= XEN_STATIC_OUTLINE_NONE;
	m_Font				= NULL;
	// Patrick Modified (05/12/05) ==============================================
	m_Stat				= XEN_BTN_ENABLE;
	// Patrick Modified (05/12/05) ==============================================

	m_bForceOwnerDraw	= FALSE; //Added on 2005/11/17
}
//-------------------------------------------------------------------------------------------------------------

cXenStatic::~cXenStatic()
{
}
//-------------------------------------------------------------------------------------------------------------

bool cXenStatic::Create( LPCTSTR lpszCaption, DWORD dwStyle, RECT rect, CWnd *ParentWnd, unsigned int UID )
{
	m_This				= this;
	m_Owner				= ParentWnd;

	m_Caption			= lpszCaption;
	m_Rect				= rect;
	m_Align				= DT_CENTER |  DT_VCENTER | DT_SINGLELINE;

	m_bForceOwnerDraw	= ((SS_OWNERDRAW & dwStyle) == SS_OWNERDRAW) ? TRUE : FALSE;


	CStatic::Create( lpszCaption, dwStyle, rect, ParentWnd, UID );

	return true;
}
//-------------------------------------------------------------------------------------------------------------

// Patrick Added ------------------------------------------------------------------------
void cXenStatic::SetHyperlink(CString strHyperlink)
{
	m_sHyperLink = strHyperlink;
	m_bHyperLink = true;
}
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::SetHyperLinkFont()
{
	CFont *pFont = GetFont();
	if (pFont) 
	{
		LOGFONT lf;
		pFont->GetObject(sizeof(lf), &lf);
		lf.lfUnderline = TRUE;		
		if (m_fontHyperLink.m_hObject)
			m_fontHyperLink.DeleteObject();
		m_fontHyperLink.CreateFontIndirect(&lf);
		m_bCreateFont = true;
	}
}
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::SetHyperLinkCaption(LPCTSTR Caption)
{ 
	m_Caption = Caption; 
	m_bGetCaptionSize = false; 
	SetWindowText(m_Caption); 
	Invalidate();
	if (m_bHyperLink) 
		SetHyperLinkFont();
} 
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::GetCaptionSize()
{
	if (!m_bGetCaptionSize && m_bCreateFont ) 
	{
		CClientDC dc(this);
		CFont *pOldFont = dc.SelectObject(m_Font);
		m_szCaption = dc.GetTextExtent(m_Caption);
		dc.SelectObject(pOldFont);
		m_bGetCaptionSize = true;
	}
}
//-------------------------------------------------------------------------------------------------------------

bool cXenStatic::InCaptionRange(CPoint &point)
{
	if ( !m_bGetCaptionSize )
		return false;

	if (m_Align & DT_RIGHT)
	{
		CRect rect;
		GetClientRect(&rect);
		return (( point.x >= rect.right-m_szCaption.cx)&&( point.x < rect.right ) &&
				( point.y >= 0 )&&( point.y < m_szCaption.cy ));
	}
	else
	{
		return (( point.x >= 0 )&&( point.x < m_szCaption.cx ) &&
				( point.y >= 0 )&&( point.y < m_szCaption.cy ));
	}
}
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::OnPaint() 
{	
	if ( m_bCreateFont == false )
		SetHyperLinkFont();

	if (m_bHyperLink)
	{
		CPaintDC dc(this);
		CFont *pOldFont = (CFont*)dc.SelectObject(&m_fontHyperLink);

		DWORD dwStyle = GetExStyle();

		dc.SetBkMode(TRANSPARENT);
		dc.SetTextColor(m_clrFont);

		if (!m_bGetCaptionSize)
			GetCaptionSize();

		dc.TextOut(0, 0, m_Caption);
		dc.SelectObject(pOldFont);
	}
	else
	{
		CStatic::OnPaint();
	}
}
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::OnDestroy() 
{
	CStatic::OnDestroy();
	if (m_bCreateFont)
		m_fontHyperLink.DeleteObject();
}
//-------------------------------------------------------------------------------------------------------------
// ========================================================================

BOOL cXenStatic::OnEraseBkgnd(CDC* pDC)
{
	return CStatic::OnEraseBkgnd(pDC); //Patrick Modified
}
//-------------------------------------------------------------------------------------------------------------

// Patrick Added ----------------------------------------------------
void cXenStatic::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if ( m_bGetCaptionSize == false )
		GetCaptionSize();
	if (InCaptionRange(point) && m_bHyperLink)
		GetParent()->PostMessage(WM_COMMAND, MAKEWPARAM(LOWORD(GetDlgCtrlID()), HIWORD(STN_CLICKED)), (LPARAM)m_hWnd);

}
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::PreSubclassWindow() 
{
	ModifyStyle(0, SS_NOTIFY, TRUE);
	GetWindowText(m_Caption);
	m_bGetCaptionSize = false;
	CStatic::PreSubclassWindow();
}
//-------------------------------------------------------------------------------------------------------------

LRESULT cXenStatic::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	if (m_bHyperLink)
	{
		m_bMouseInControl = false;
		::SetCursor(m_hArrowCursor);	
	}
	return 0;
}
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_bHyperLink)
	{
		if ( m_bMouseInControl == false ) 
		{
			//Track the mouse leave event
			TRACKMOUSEEVENT tme;
			tme.cbSize = sizeof(tme);
			tme.hwndTrack = GetSafeHwnd();
			tme.dwFlags = TME_LEAVE;        
			_TrackMouseEvent(&tme);
			m_bMouseInControl = true;
		}
		else 
		{
			if ( m_bGetCaptionSize == false )
				GetCaptionSize();
			::SetCursor((InCaptionRange(point)) ? m_hHandCursor : m_hArrowCursor);		
		}
	}
	CStatic::OnMouseMove(nFlags, point);
}
//-------------------------------------------------------------------------------------------------------------
// =====================================================================

LRESULT cXenStatic::OnSetText(WPARAM wParam, LPARAM lParam)
{
	LRESULT Result = Default();
	CRect Rect;
	GetWindowRect(&Rect);
	GetParent()->ScreenToClient(&Rect);
	GetParent()->InvalidateRect(&Rect);
	GetParent()->UpdateWindow();

	return Result;
}

//-------------------------------------------------------------------------------------------------------------

HBRUSH cXenStatic::CtlColor(CDC* pDC, UINT nCtlColor)
{
	if ( m_bForceOwnerDraw ) 
		return NULL;

	if (CTLCOLOR_STATIC == nCtlColor)
	{
		if (m_Font) pDC->SelectObject( m_Font );
		pDC->SetTextColor( m_clrFont );
		pDC->SetBkMode( TRANSPARENT );
	}

	return (HBRUSH)GetStockObject(NULL_BRUSH);
}
//====================================================================================

//-------------------------------------------------------------------------------------------------------------
void cXenStatic::MoveWindow( LPCRECT lpRect, BOOL bRepaint )
{
	m_Rect				= lpRect;
	m_DrawRect.SetRect( 0, 0, m_Rect.right - m_Rect.left, m_Rect.bottom - m_Rect.top );
	CStatic::MoveWindow( m_Rect, bRepaint );
}
//-------------------------------------------------------------------------------------------------------------

void cXenStatic::Refresh()
{
	CWnd::InvalidateRect( NULL );
}
//-------------------------------------------------------------------------------------------------------------

// Patrick Modified for HyperLink ---------------------------------------------
void cXenStatic::DrawItem( LPDRAWITEMSTRUCT lpDIS )
{
	CFont*  pOldFont;
	CDC*	pDC = CDC::FromHandle(lpDIS->hDC); //Patrick Added

	GetClientRect( m_DrawRect);

	if (m_bHyperLink)
	{
		if ( m_bCreateFont == false )
			SetHyperLinkFont();
		pOldFont = (CFont*)pDC->SelectObject(&m_fontHyperLink);
	}
	else
	{
		if( m_Font )
			pOldFont = (CFont *)pDC->SelectObject( m_Font );
	}

	if (m_bDrawTransparent)
		DrawTransparent( pDC );
	else
	{
		GetClientRect( m_DrawRect);
		pDC->FillSolidRect( &m_DrawRect, m_clrBtnFace );
	}

	pDC->SetBkMode( TRANSPARENT );
	(m_Stat == XEN_BTN_ENABLE) ? pDC->SetTextColor( m_clrFont ) : pDC->SetTextColor(GetSysColor(COLOR_GRAYTEXT));

	switch( m_style )
	{
	case XEN_STATIC_OUTLINE_SINGLE:
		pDC->Draw3dRect( m_DrawRect, m_clrOutLine, m_clrOutLine );
	break;
	case XEN_STATIC_OUTLINE_UPPER:
		pDC->Draw3dRect( m_DrawRect, GetSysColor(COLOR_BTNHILIGHT), GetSysColor(COLOR_BTNSHADOW) );
	break;
	case XEN_STATIC_OUTLINE_LOWER:
		pDC->Draw3dRect( m_DrawRect, GetSysColor(COLOR_BTNSHADOW), GetSysColor(COLOR_BTNHILIGHT) );
	break;
	}

	if( m_Caption.GetLength() > 0 )
	{
		DrawText( lpDIS->hDC, m_Caption.GetString(), m_Caption.GetLength(), m_DrawRect, m_Align );
	}

	if (m_bHyperLink || m_Font)
	{
		pDC->SelectObject( pOldFont );
	}
}
// ================================================================================
//-------------------------------------------------------------------------------------------------------------
