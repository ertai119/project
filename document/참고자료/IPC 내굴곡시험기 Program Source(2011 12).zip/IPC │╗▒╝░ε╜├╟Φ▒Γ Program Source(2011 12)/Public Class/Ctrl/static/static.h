#pragma once

#include "..\\Object\\MyObject.h"

#ifndef IDC_HAND
#define IDC_HAND MAKEINTRESOURCE(32649)
#endif

class cXenStatic : public CStatic, public cPatrickTransparent
{
private:

	DECLARE_DYNAMIC(cXenStatic)

protected:

	unsigned int	m_Align;
	CString			m_Caption;

	CRect			m_Rect;
	CRect			m_DrawRect;

	CFont			m_fontHyperLink;
	CString			m_sHyperLink;
	CSize			m_szCaption;
	bool			m_bMouseInControl, m_bGetCaptionSize, m_bHyperLink, m_bCreateFont;
	HCURSOR			m_hHandCursor, m_hArrowCursor;

	void			SetHyperLinkFont();
	void			GetCaptionSize();
	bool			InCaptionRange(CPoint &point);

protected:
	// Patrick Added for HyperLink--------------------------
	virtual void	PreSubclassWindow();

	afx_msg void	OnPaint();
	afx_msg void	OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void	OnDestroy();
	afx_msg void	OnMouseMove(UINT nFlags, CPoint point);
	afx_msg LRESULT OnMouseLeave(WPARAM wParam, LPARAM lParam);
	// -----------------------------------------------------

	afx_msg LRESULT OnSetText(WPARAM wParam, LPARAM lParam);
	afx_msg HBRUSH	CtlColor(CDC* pDC, UINT nCtlColor);

	afx_msg BOOL	OnEraseBkgnd(CDC* pDC);
	virtual void	DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
	DECLARE_MESSAGE_MAP()

public:

	cXenStatic();
	~cXenStatic();

	bool			Create( LPCTSTR lpszCaption, DWORD dwStyle, RECT rect, CWnd *ParentWnd, unsigned int UID = -1 );

	void			SetFont( CFont *pFont ){ MySetFont(pFont); CStatic::SetFont(pFont); }
	void			SetAlign( unsigned int Align )	{ m_Align = Align; }
	void			SetCaption( LPCTSTR Caption )	{ m_Caption = Caption; SetWindowText(m_Caption); }
	CString&		GetCaption()					{ return m_Caption; }
	void			SetHyperLinkCaption( LPCTSTR Caption );
	
	void			Refresh();

	void			MoveWindow( LPCRECT lpRect, BOOL bRepaint = 1 );

	CSize			GetTextSize()	{ GetCaptionSize(); return m_szCaption; }
	CString&		GetHyperlink()	{ return m_sHyperLink; }
	void			SetHyperlink(CString strHyperlink);
	
	void			Enable(BOOL bEnable) 
					{ m_Stat = (bEnable) ? XEN_BTN_ENABLE:XEN_BTN_DISABLE; EnableWindow(bEnable); Invalidate(); }
};