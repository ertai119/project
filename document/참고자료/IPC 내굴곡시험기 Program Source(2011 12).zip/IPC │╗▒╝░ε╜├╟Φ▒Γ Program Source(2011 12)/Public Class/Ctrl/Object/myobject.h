#pragma once

#pragma pack(push, 1)

enum XEN_LISTCTRL_FIELDTYPE{ XENDATA_STRING	= 1, XENDATA_TOOLTIP, XENDATA_PROGRESSBAR =	11,	XENDATA_BUTTON, XENDATA_IMAGE = 21 };

enum XEN_BUTTON_STATS { XEN_BTN_DISABLE = 0, XEN_BTN_ENABLE, XEN_BTN_OVER, XEN_BTN_CLICK, XEN_BTN_CLICKOVER };
enum XEN_BUTTON_TYPE  { XEN_BTN_PUSH = 0, XEN_BTN_CHECK, XEN_BTN_RADIO };
enum XEN_BUTTON_STYLE { XEN_BTN_FLAT = 0, XEN_BTN_DOTNET, XEN_BTN_3D };

enum XEN_STATIC_STYLE {  XEN_STATIC_OUTLINE_NONE = 0, XEN_STATIC_OUTLINE_SINGLE, XEN_STATIC_OUTLINE_UPPER, XEN_STATIC_OUTLINE_LOWER };

enum XEN_COMBOBOX_STATS { XEN_CMB_DISABLE   = 0, XEN_CMB_ENABLE, XEN_CMB_OVER, XEN_CMB_CLICK };
enum XEN_COMBOBOX_STYLE { XEN_CMB_FLAT		= 0, XEN_CMB_DOTNET, XEN_CMB_3D };

enum XEN_EDITBOX_STATS { XEN_EDIT_DISABLE = 0, XEN_EDIT_ENABLE, XEN_EDIT_OVER, XEN_EDIT_CLICK };
enum XEN_EDITBOX_STYLE { XEN_EDIT_FLAT	  = 0, XEN_EDIT_DOTNET, XEN_EDIT_3D };

enum XEN_POPUP_STYLE { XEN_POPUP_FLAT	  = 0, XEN_POPUP_DOTNET, XEN_POPUP_3D };

class cMyObject
{
private:
protected:

	CFont		   *m_Font;
	CFont		   *m_BoldFont;

	BOOL			m_bForceOwnerDraw; //Added on 2005/11/17

	short			m_style;
	short		    m_Stat;

	LPVOID			m_Owner;
	LPVOID			m_This;

public:

	cMyObject()
	{
		m_Owner		= NULL;
		m_This		= NULL;
		m_Font		= NULL;
		m_BoldFont	= NULL;
	}

	cMyObject( LPVOID pClass)
	{
		m_Owner = NULL;
		m_This	= pClass;
		m_Font		= NULL;
		m_BoldFont	= NULL;
	}

	~cMyObject()
	{

	}

	void SetObjectOwner( LPVOID iClass )
	{
		m_Owner = iClass;
	}
	LPVOID	GetObjectOwner(){ return m_Owner; }

	short MyGetStat(){ return m_Stat; }
	short MyGetStyle(){ return m_style; }
	void  MySetStyle( short nStyle ){ m_style = nStyle; }
	void  MySetStat( short stat ){ m_Stat = stat; }
	void  MySetFont( CFont *pFont ){ m_Font = pFont; }
	void  MySetBoldFont( CFont *pFont ){ m_BoldFont = pFont; }

	CFont	*MyGetFont(){return m_Font;}
	CFont	*MyGetBoldFont(){return m_BoldFont;}

};
//-------------------------------------------------------------------------------------------------------------

class cXenControlsColor : public cMyObject
{
private:
protected:

public:

	COLORREF	    m_clrFont;

	COLORREF		m_clrBtnFace;	
	COLORREF		m_clrBtnHilite;	
	COLORREF		m_clrBtnShadow;	

	COLORREF		m_clrBtnHighlight;
	COLORREF		m_clrOver;;	
	
	COLORREF		m_clrClick;	

	COLORREF		m_clrBk;	
	COLORREF		m_clrOutLine;	

	cXenControlsColor()
	{
		OnSysColorChange();
	}
	~cXenControlsColor(){}

	void SetFontColor( COLORREF FontColor ){ m_clrFont = FontColor;}	
	// append yoonmijin  2010/11/27
	void SetBackColor( COLORREF BackColor ){ m_clrBk = BackColor;}	
	//
	void SetOutLineColor( COLORREF	OutLine ) { m_clrOutLine = OutLine; }

	void OnSysColorChange() 
	{
		m_clrFont			= GetSysColor( COLOR_BTNTEXT );

		m_clrBtnHilite		= GetSysColor( COLOR_BTNHILIGHT );
		m_clrBtnShadow		= GetSysColor( COLOR_BTNSHADOW );
		m_clrBtnFace		= GetSysColor( COLOR_BTNFACE );

		m_clrBtnHighlight	= GetSysColor( COLOR_HIGHLIGHT );
		m_clrOver			= RGB( 181, 190, 214);			// Over Color

		m_clrClick			= RGB( 132, 146, 181);			// Clicked Color

		m_clrBk				= RGB( 255, 255, 255 );			// Back Ground Color	
		m_clrOutLine		= GetSysColor(CTLCOLOR_EDIT);	// Out Line Color

	}

};
//-------------------------------------------------------------------------------------------------------------

class cPatrickTransparent : public cXenControlsColor
{
private:
protected:

	bool			m_bDrawTransparent; 

	CDC				m_dcBk;
	CBitmap			m_bmpBk;
	CBitmap*		m_pbmpOldBk;

public:

	cPatrickTransparent()
	{
		m_bDrawTransparent	= FALSE;
		m_pbmpOldBk			= NULL;
	}

	~cPatrickTransparent()
	{
		// Patrick Added ------------------------
		if (m_dcBk.m_hDC != NULL)
			m_dcBk.DeleteDC();
		if (m_bmpBk.m_hObject != NULL)
			m_bmpBk.DeleteObject();
		// --------------------------------------
	}

	void			SetTransparent( BOOL bRepaint = FALSE );
	void			DrawTransparent( CDC* pDC);
};
//-------------------------------------------------------------------------------------------------------------

inline void cPatrickTransparent::DrawTransparent( CDC* pDC)
{
	if( !m_This )
		return;

	CClientDC clDC( ((CWnd*)m_This)->GetParent() );
	CRect rect;
	CRect rect1;

	((CWnd*)m_This)->GetClientRect(rect);

	((CWnd*)m_This)->GetWindowRect(rect1);
	((CWnd*)m_This)->GetParent()->ScreenToClient(rect1);

	if (m_dcBk.m_hDC == NULL)
	{
		m_dcBk.CreateCompatibleDC(&clDC);
		m_bmpBk.CreateCompatibleBitmap(&clDC, rect.Width(), rect.Height());
		m_pbmpOldBk = m_dcBk.SelectObject(&m_bmpBk);
		m_dcBk.BitBlt(0, 0, rect.Width(), rect.Height(), &clDC, rect1.left, rect1.top, SRCCOPY);
	} // if

	pDC->BitBlt(0, 0, rect.Width(), rect.Height(), &m_dcBk, 0, 0, SRCCOPY);
} 
//-------------------------------------------------------------------------------------------------------------

inline void cPatrickTransparent::SetTransparent( BOOL bRepaint )
{
	m_bDrawTransparent = TRUE;

	// Restore old bitmap (if any)
	if (m_dcBk.m_hDC != NULL && m_pbmpOldBk != NULL)
	{
		m_dcBk.SelectObject(m_pbmpOldBk);
	} // if

	m_bmpBk.DeleteObject();
	m_dcBk.DeleteDC();

	// Repaint the button
	if (bRepaint && ((CWnd*)m_This)) 
		((CWnd*)m_This)->Invalidate();
}
//-------------------------------------------------------------------------------------------------------------


#pragma pack(pop)