#pragma once
#include "ctrl/static/static.h"
#include "ctrl/button/Xenbutton.h"

// CIPCLoad ��ȭ �����Դϴ�.

class CIPCLoad : public CDialog
{
	DECLARE_DYNAMIC(CIPCLoad)

public:
	CIPCLoad(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CIPCLoad();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_IPCLOAD };

	void SetBFTotalCount(long count)		{ m_curTotalCount = count; }

protected:
	COLORREF	m_clrText, m_limitText;

	cXenStatic	m_stBFTotal;
	cXenStatic	m_stIPCLoad[2];
	cXenButton	m_btnOK;

	long		m_curTotalCount;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	void InitControl();
	void InitPos();
	
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnNcActivate(BOOL bActive);
};
