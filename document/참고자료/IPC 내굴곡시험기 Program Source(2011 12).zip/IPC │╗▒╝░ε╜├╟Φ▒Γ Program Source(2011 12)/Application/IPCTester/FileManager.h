#pragma once
#include "ResistanceWnd.h"

class CSerialWorker_ACCT;
class CSerialWorker_RMI;

// File Manager Thread
#define	__INNERP_FILEMANAGER_ADDRESISTANCE__				31000
#define	__INNERP_FILEMANAGER_BFTFILE_CREATE__				31001
#define	__INNERP_FILEMANAGER_BFTFILE_SAVE__					31002


// CFileManager ���� ����Դϴ�.

class CFileManager : public CObject
{
public:
	CFileManager();
	virtual ~CFileManager();

	BOOL Start(CWnd* pWindow = NULL, DWORD timeout = INFINITE);
	void Stop();

	BOOL	GetStartFlag()	{ return (m_long_StartFlag == 1 ? TRUE : FALSE); }
	HANDLE	Get_IOPORT()	{ return m_hIOPORT; }
	HANDLE	Get_hThread()	{ return m_hThread; }
	DWORD	Get_IDThread()	{ return m_IDThread; }

	LPTSTR	GetFilePath()	{ return m_saveFile; }

	BOOL	ReadLine(LPTSTR filepath, LPSTR pBuffer, int nline);
	BOOL	ReadBlock(LPTSTR filepath, LPSTR pBuffer, int nline);

private:
	SResistanceData	ResistData[IPC_MAX_MATERIAL];

protected:
	HANDLE	m_hIOPORT;
	HANDLE	m_hThread;
	DWORD	m_IDThread;

	CRITICAL_SECTION	m_CriticalSection;

	long	m_long_StartFlag;
	DWORD	m_TimeOut;

	CWnd*	m_pMainWnd;
	TCHAR	m_saveFile[256];

protected:
	void OnUnknownMsg(DWORD userkey, void* pParam);
	void TimeOutFunction();

	void AddResistanceData(void* pParam);

	BOOL SaveHeader();
	BOOL SaveBFTFile(long count);

	LPTSTR CreateFilePath();

	BOOL	WriteBlock(LPTSTR filepath, LPSTR pBuffer, int nsize);

	void SetStartFlag(BOOL flag) { ::InterlockedExchange(&m_long_StartFlag, (flag == TRUE ? 1 : 0)); }

	static DWORD WINAPI InterfaceThread(LPVOID lpParameter);
};


