#include "StdAfx.h"
#include "RMIInterface.h"

CRMIInterface::CRMIInterface(void)
{
}

CRMIInterface::~CRMIInterface(void)
{
}

void CRMIInterface::SetSessionSerialPort(LPASRLSTRUCT lpASRL)
{
	CopyMemory(&m_ASRLInfo, lpASRL, sizeof(LPASRLSTRUCT));
}

BOOL CRMIInterface::RequestResistData()
{
	double res;

	/* Open session to GPIB device at address 22 */
	ViStatus status = viOpenDefaultRM(&defaultRM);

	if(status != S_OK)
	{
		if(m_hWnd)
			::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_RESISTANCE_ERROR, 0);
		return S_FALSE;
	}

	char devid[128];
	sprintf(devid, "ASRL%d::INSTR", m_ASRLInfo.asrlid);

	ViUInt32 timeout = 2000;
	status = viOpen(defaultRM, devid, VI_NULL, timeout, &vi);
	if(status == S_OK)
	{
		status = viPrintf(vi, "*RST\n");

		if(status == S_OK)
		{
			SleepEx(300, TRUE);

			viPrintf (vi, "SYST:REM\n");
			SleepEx(300, TRUE);

			viPrintf (vi, "MEAS:RES?\n");

			ViStatus ret = viScanf (vi, "%lf", &res);

			if(m_hWnd)
			{
				if(ret == S_OK)
				{
					char*	pdata = new char[256];
					if(pdata)
					{
						sprintf(pdata, "%.06lf", res);
						::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_RESISTANCE, (LPARAM)pdata);
					}
				}
				else	
				{
					::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_RESISTANCE_ERROR, 0);
				}
			}

			viClose(vi);
			viClose(defaultRM);

			return S_OK;
		}
	}


	viClose(defaultRM);
	if(m_hWnd)
		::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_RESISTANCE_ERROR, 0);
	return S_FALSE;
}

