// AmplitudeDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "AmplitudeDlg.h"

#define		IPC_DATAREQUEST_TIMER		3000


// CAmplitudeDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CAmplitudeDlg, CDialog)

CAmplitudeDlg::CAmplitudeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAmplitudeDlg::IDD, pParent)
{
	m_clrBack		= IPC_BACKGROUND_COLOR;	
	m_clrText		= PALETTERGB(0,0,0);			// BLACK
	m_clrValue		= PALETTERGB(0, 0, 255);		// BLUE
	m_clrMask		= PALETTERGB(255,0,255);		// PINK

	m_amplitude = 0;
	m_bTestStop = false;
	m_bStopCommand = false;
	m_testCount = 0;
	m_reqCount = 0;
}

CAmplitudeDlg::~CAmplitudeDlg()
{
}

void CAmplitudeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CAmplitudeDlg::Localize()
{
	m_stAmp[EN_STATIC_DEF_AMP].SetFontColor(m_clrValue);
	m_stAmp[EN_STATIC_DEF_AMP].SetCaption(GetResString(IDS_AMPTEST_STATIC_AMP));

	m_stAmp[EN_STATIC_DEF_CURRAMP].SetFontColor(m_clrValue);
	m_stAmp[EN_STATIC_DEF_CURRAMP].SetCaption(GetResString(IDS_AMPTEST_STATIC_CURRENTAMP));

	CString strAmp;
	strAmp.Format(_T("%d"), m_amplitude);
	m_stAmp[EN_STATIC_AMP].SetCaption(strAmp);

	UpdateData(FALSE);
}

void CAmplitudeDlg::LocalizeFont()
{
	CFont *pFont = thePrefs.GetGUIDefault();
	CFont*	m_fontBold = thePrefs.GetGUIDefaultBold();

	for (int i = 0; i < EN_STATIC_MAX; i++)
		m_stAmp[i].SetFont(pFont);	

}

void CAmplitudeDlg::InitPos()
{
	CRect	rcClient;
	GetClientRect(&rcClient);

	if (m_stAmp[0].m_hWnd && m_btnStop.m_hWnd)
	{
		int nCtrlWidth = 90;
		int	nCtrlHeight = 20;
		int	nCtrlIntv = 20, nLineIntv = 9, nOffSet = 10;

		CRect	rcTemp(0,0,0,0);

		rcTemp.left		= IPC_AMPTEST_GRAPH_STARTX - 36;
		rcTemp.top		= IPC_AMPTEST_BUTTON_TOP;
		rcTemp.right	= rcTemp.left + nCtrlWidth;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		for(int i = 0; i <= EN_STATIC_DEF_CURRAMP; i++)
		{
			m_stAmp[i].MoveWindow(&rcTemp, FALSE);

			rcTemp.left		= rcTemp.right + nCtrlIntv;
			rcTemp.right	= rcTemp.left + nCtrlWidth;
		}

		rcTemp.left		= IPC_AMPTEST_GRAPH_STARTX - 36;
		rcTemp.top		= rcTemp.bottom + 5;
		rcTemp.right	= rcTemp.left + nCtrlWidth;
		rcTemp.bottom	= rcTemp.top + nCtrlHeight;
		for(int i = EN_STATIC_AMP; i < EN_STATIC_MAX; i++)
		{
			m_stAmp[i].MoveWindow(&rcTemp, FALSE);

			rcTemp.left		= rcTemp.right + nCtrlIntv;
			rcTemp.right	= rcTemp.left + nCtrlWidth;
		}

		CRect rcBtn;
		m_btnStop.GetWindowRect(&rcBtn);
	
		int w = rcBtn.Width();
		int h = rcBtn.Height();

		rcTemp.left		= rcTemp.right + 10 - nCtrlWidth;
		rcTemp.top		= IPC_AMPTEST_BUTTON_TOP;
		rcTemp.right	= rcTemp.left + w;
		rcTemp.bottom	= rcTemp.top + h;

		m_btnStop.MoveWindow(&rcTemp, FALSE);
		m_btnStop.Invalidate(FALSE);
		m_btnStop.ShowWindow(SW_SHOW);
	}
}

void CAmplitudeDlg::InitControl()
{
	CRect	rcTemp(0,0,0,0);

	// Create Stop Buttons 
	//////////////////////////////////////////////////////////////////////////////////
	CImageList*	pImageList = NULL;
	pImageList = theResMan.GetImageListRes(IPC_RESMAN_BTN_TEST_STOP);

	IMAGEINFO	imgInfo;
	CRect	rcRect;
	pImageList->GetImageInfo(1, &imgInfo);
	rcRect = imgInfo.rcImage;

	m_btnStop.SetImageList(pImageList, 0);
	m_btnStop.Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
						rcRect, this, IDC_AMPTEST_BTN_STOP);
	m_btnStop.SetTransparent();


	short pwidth = 60;
	for (int i = 0; i < EN_STATIC_MAX; i++)
	{
		if(i >= EN_STATIC_AMP)
		{
			m_stAmp[i].Create(NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | SS_OWNERDRAW, 
								CRect(0, 0, pwidth, 20), this, IDC_AMPTEST_STATIC_AMP + i);
			m_stAmp[i].SetAlign(DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		}
		else
		{
			m_stAmp[i].Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, 
								CRect(0, 0, pwidth, 20), this, IDC_AMPTEST_STATIC_AMP + i);
			m_stAmp[i].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		}
		m_stAmp[i].SetFontColor( m_clrText );	
		m_stAmp[i].SetCaption( _T("") );
	}
}

void CAmplitudeDlg::DrawGraphicArea(CDC* pDC)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	CRect	rcTemp;
	rcTemp.left = rcClient.right - (IPC_AMPTEST_GRAPH_WIDTH + IPC_AMPTEST_LEFT);
	rcTemp.top = IPC_AMPTEST_TOP;
	rcTemp.right = rcClient.right - IPC_AMPTEST_LEFT;
	rcTemp.bottom = rcTemp.top + IPC_AMPTEST_GRAPH_HEIGHT - 1;

	// Graph Area FillRect (BLACK Color)
	CBrush brNew(m_clrText), *pOldBrush;
	pOldBrush = pDC->SelectObject(&brNew);

	pDC->FillRect(rcTemp, &brNew);
	pDC->SelectObject(pOldBrush);

	CPen pen;
	pen.CreatePen(PS_SOLID, 1, PALETTERGB(0, 0, 0));
	CPen *pOldPen = pDC->SelectObject(&pen);

	CFont*	pFont;
	pFont = thePrefs.GetGUIDefault();

    CFont* pOldFont = pDC->SelectObject(pFont);
	pDC->SetTextColor(m_clrText);
//	pDC->SetBkMode(TRANSPARENT);

	{
		CRect	rcItem;
		short	inter = IPC_AMPTEST_GRAPH_HEIGHT / (8 - 1);

		rcItem.left = rcTemp.left - 25;
		rcItem.right = rcItem.left + 20;

		for(int i = 0; i < 8; i++)
		{
			rcItem.top = rcTemp.top + (i * inter) - 5;
			rcItem.bottom = rcItem.top + 15;
			pDC->DrawText(GetResString(IDS_AMPTEST_STATIC_Y1 + i), 
							rcItem, DT_SINGLELINE | DT_LEFT | DT_VCENTER );

			pDC->MoveTo(rcTemp.left - 5, rcTemp.top + (i * inter));
			pDC->LineTo(rcTemp.left - 5 + 10, rcTemp.top + (i * inter));
		}

		CString strTime;
		strTime.Format(_T("%02d:%02d"), (int)m_reqCount / 60, (int)m_reqCount % 60);
		rcItem.right = rcTemp.right + 7;
		rcItem.left = rcItem.right - 30;
		rcItem.top = rcTemp.bottom + 7;
		rcItem.bottom = rcItem.top + 15;
		pDC->DrawText(strTime, rcItem, DT_SINGLELINE | DT_RIGHT | DT_VCENTER );

		pDC->MoveTo(rcTemp.right - 1, rcTemp.bottom - 5);
		pDC->LineTo(rcTemp.right - 1, rcTemp.bottom + 5);
	}

	{
		CPen pen;
		pen.CreatePen(PS_SOLID, 1, PALETTERGB(0, 128, 64));
		pDC->SelectObject(&pen);

		// Net Line Interval
		int		width = rcTemp.Width();
		short	interX = width / 15;
		short	interY = IPC_AMPTEST_GRAPH_HEIGHT / 7;

		// Data Interval
		int interval = (IPC_AMPTEST_GRAPH_WIDTH / IPC_AMPTEST_GRAPH_XPOINTS);
	
		int tab = 0;

		if((m_reqCount % 2) == 0L)	
			tab = interX / (interX / interval);

		for(int i = 1; i <= 15; i++)
		{
			int x = (rcTemp.right + tab) - (i * interX);
			if(x > rcTemp.left)
			{
				pDC->MoveTo(x, rcTemp.top);
				pDC->LineTo(x, rcTemp.bottom);
			}
		}
		for(int i = 1; i < 7; i++)
		{
			pDC->MoveTo(rcTemp.left, rcTemp.top + (i * interY));
			pDC->LineTo(rcTemp.right, rcTemp.top + (i * interY));
		}

		CPen penData;
		penData.CreatePen(PS_SOLID, 1, PALETTERGB(0, 255, 0));
		pDC->SelectObject(&penData);

		for(int i = 0; i < m_testCount; i++)
		{
			int y = ((rcTemp.bottom * m_ampData[i]) / (float)(IPC_AMPTEST_GRAPH_YPOINTS + 2)); 
			int x = ((m_testCount - 1) - i) * interval;

			ptAmplitude[i] = CPoint(rcTemp.right - x, rcTemp.bottom - y);
		}

		pDC->Polyline(ptAmplitude, m_testCount);
	}

	pDC->SelectObject(pOldFont);
	pDC->SelectObject(pOldPen);
}


BEGIN_MESSAGE_MAP(CAmplitudeDlg, CDialog)
	ON_MESSAGE(UM_IPC_AMPTEST,	OnAMPTest)

	ON_BN_CLICKED(IDC_AMPTEST_BTN_STOP,		OnTestStop)

	ON_WM_CLOSE()
	ON_WM_PAINT()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CAmplitudeDlg �޽��� ó�����Դϴ�.

BOOL CAmplitudeDlg::OnInitDialog()
{
	/*
	 *	Create Preference Controls & Set Properties	
	 *  Note: DDX/DDV�� �����Ǳ� ���� User Created Control�� �����Ѵ�.
	 */
	InitControl();

	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	LocalizeFont();
	Localize();
	InitPos();

	if(theApp.m_pACCT)
	{
		theApp.m_pACCT->SetWindowHandle(m_hWnd);
		theApp.m_pACCT->AmpDataRequest();
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CAmplitudeDlg::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(m_bTestStop == false)
	{
		m_bTestStop = true;

		CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
		if(pAcct)
			pAcct->EndAmpTest();
		SleepEx(1000, TRUE);
	}

	CDialog::OnClose();
}

void CAmplitudeDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialog::OnPaint()��(��) ȣ������ ���ʽÿ�.
	DrawGraphicArea(&dc);
}

void CAmplitudeDlg::OnTestStop()
{
	m_bStopCommand = true;

}

HRESULT CAmplitudeDlg::OnAMPTest( WPARAM wParam, LPARAM lParam )
{
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
	
	switch(wParam)
	{	
		case ID_IPC_AMPTEST_END_CONFIRM :
			m_bTestStop = true;
			break;

		case ID_IPC_AMPTEST_DATA :
			{
				char* pStr = (char*)lParam;
				float pVal = atof(pStr);

				CString strAmp;
				strAmp.Format(_T("%.2f"), pVal);
				m_stAmp[EN_STATIC_AMP_CURRENT].SetCaption(strAmp);

				UpdateData(FALSE);

				m_ampData[m_testCount++] = pVal;
				m_reqCount++;

				if(m_testCount == (IPC_AMPTEST_GRAPH_XPOINTS + 2))
				{
					for(int i = 0; i < m_testCount; i++)
						m_ampData[i] = m_ampData[i + 1];
					m_testCount = IPC_AMPTEST_GRAPH_XPOINTS + 1;
				}

				CDC*	pDC = GetDC();
				DrawGraphicArea(pDC);
				ReleaseDC(pDC);

				if(m_bStopCommand)
				{
					CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
					if(pAcct)
						pAcct->EndAmpTest();

					return 0;
				}

				SetTimer(IPC_DATAREQUEST_TIMER, 1000, NULL);
			}
			break;

		default :
			break;
	}

	return 0;

}

void CAmplitudeDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if (nIDEvent == IPC_DATAREQUEST_TIMER)
	{	
		KillTimer(IPC_DATAREQUEST_TIMER);

		if(!m_bTestStop)
		{
			CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
			if(pAcct && pAcct->IsConnection())
				pAcct->AmpDataRequest();
		}
	}
}
