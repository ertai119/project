// IPCTester.h : PROJECT_NAME ���� ���α׷��� ���� �� ��� �����Դϴ�.
//

#pragma once

#ifndef __AFXWIN_H__
	#error PCH���� �� ������ �����ϱ� ���� 'stdafx.h'�� �����Ͻʽÿ�.
#endif

#include "resource.h"		

#include "IPCTesterDlg.h"
#include "LogObjectA.h"
#include "IPCTester_i.h"

#include "SerialWorker_ACCT.h"
#include "RMIInterface.h"
#include "FileManager.h"


#define IPC_TEMP_DATACHECK_TIMER		2000
#define	IPC_TEMP_DATAREQUEST_TIMER		2001
#define	IPC_TEMP_DATAREQUEST_TIMER2		2002

#define IPC_TEMP_DATASCAN				2010

#define CONFIGFOLDER				_T("config/")
#define FILESFOLDER					_T("files")
#define LOGFOLDER					_T("logs/")

#define IPCLOG						100					

#define IPC_BACKGROUND_COLOR		PALETTERGB(240, 240, 240)


///////////////////////////////////////////////////////////////////////////////
// Resource strings
//
#ifdef USE_STRING_IDS
#define	RESSTRIDTYPE		LPCTSTR
#define	IDS2RESIDTYPE(id)	#id
#define GetResString(id)	_GetResString(#id)
CString _GetResString(RESSTRIDTYPE StringID);
#else	//USE_STRING_IDS
#define	RESSTRIDTYPE		UINT
#define	IDS2RESIDTYPE(id)	id
CString GetResString(RESSTRIDTYPE StringID);
#define _GetResString(id)	GetResString(id)
#endif	//!USE_STRING_IDS

CString GetFloatingFormat(float inter, short len);

// Resource bitmaps
HBITMAP GetResBitmap(UINT uBitmapID);

enum AppStatus
{
	APPSTATUS_CONNECTION = 0,			// 
	APPSTATUS_APPRUNNING,
	APPSTATUS_RUN,
   	APPSTATUS_SHUTINGDOWN,
	APPSTATUS_NONE
};

// CIPCTesterApp:
// �� Ŭ������ ������ ���ؼ��� IPCTester.cpp�� �����Ͻʽÿ�.
//

class CIPCTesterApp : public CWinApp
{
public:
	CIPCTesterApp();

// ������
	public:
	virtual BOOL InitInstance();

// ����
// helper function
public:	
	void	LogEvent(LPCTSTR pszLog, short opcode = 0);
	void	ErrorLogEvent(LPCTSTR str, ...);

	void	Log(BOOL eventviewerflag, LPCTSTR str, ...);
	void	WarningLog(LPCTSTR str, ...);
	void	ErrorLog(LPCTSTR str, ...);

	int		Count_argumentlists(LPCTSTR lpszFormat, va_list argList);

	CString ConvertStrValue(long lValue);

	void	CloseConnection(short exitflag = false)	
			{ 
				ipcTesterdlg->CloseConnection(exitflag);
			}
	int		IPCMessageBox(UINT nIDPrompt, UINT nIDCaption, UINT nType=0, UINT nIDHelp=(UINT)-1)
			{	if(ipcTesterdlg) return ipcTesterdlg->IPCMessageBox(nIDPrompt, nIDCaption, nType, nIDHelp);
				else return 0;
			}
	int		IPCMessageBox(LPCTSTR lpszText, LPCTSTR lpszCaption, UINT nType=0, UINT nIDHelp=(UINT)-1)
			{	if(ipcTesterdlg) return ipcTesterdlg->IPCMessageBox(lpszText, lpszCaption, nType, nIDHelp); 
				else return 0;
			}

	AppStatus	GetAppStatus()					{ return m_appStatus; }
	LPCTSTR		GetPrefsName()					{ return m_pszPrefsName; }

	CResistanceWnd* GetResistanceWnd(short index)	
							{	return ipcTesterdlg->GetResistanceWnd(index); }

	void	SerialDisconnect();

	void	SetAppStatus(AppStatus status)		{ ::InterlockedExchange((long*)&m_appStatus, status); }

private:

protected:
	TCHAR				m_pszPrefsName[MAX_PATH];		

	CString m_configDir;				
	CString m_logDir;					

	CString	m_strStorageDir;			

	HANDLE				hMutexOneInstance;
	CRITICAL_SECTION	m_CriticalSection;

public:
	static const UINT	m_nVersionMjr;
	static const UINT	m_nVersionMin;
	static const UINT	m_nVersionUpd;
	static const UINT	m_nVersionBld;

	DWORD				m_dwProductVersionMS;
	DWORD				m_dwProductVersionLS;
	CString				m_strCurVersionLong;

	CLogObject			m_LOG;

	CSerialWorker_ACCT*	m_pACCT;
	CRMIInterface*		m_pRMI;

	CFileManager*		m_pFileManager;

	TCHAR				m_strLog[20][2048];		

	AppStatus			m_appStatus;

	CIPCTesterDlg*		ipcTesterdlg;

	DECLARE_MESSAGE_MAP()
	virtual BOOL InitApplication();
	BOOL ExitInstance(void);
};

extern CIPCTesterApp theApp;
