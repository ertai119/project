#pragma once
#include "afxwin.h"
#include "ResistanceWnd.h"

#include "Ctrl/Edit/EditBox.h"
#include "Ctrl/static/static.h"
#include "Ctrl/Button/XenButton.h"

#define IPC_HISTORY_TOP					10
#define IPC_HISTORY_LEFT				10
#define IPC_HISTORY_BOTTOM				10

#define IPC_HISTORY_CONTROL_STARTX		60
#define IPC_HISTORY_CONTROL_HEIGHT		70

#define IPC_HISTORY_MIN_WIDTH			930		// Min Width Size
#define IPC_HISTORY_MIN_HEIGHT			720

#define	IPC_HISTORY_PRETEST_NAMELINE	5		
#define	IPC_HISTORY_PRETEST_DATALINE	6		
#define	IPC_HISTORY_FAILMARGIN_DATALINE	8		
#define	IPC_HISTORY_MEASURE_DATALINE	11		


struct	SResultData
{
	SResultData() 		{ ZeroMemory(this, sizeof(SResultData)); }
	~SResultData()		{ 	}

	TCHAR	strName[256];
	float	failMargin;
	int		failCount;
	float	lfResist;
	long	totalCount;
};

typedef std::map< long, SResistanceData* >	MATERIALDATA_MAP;

struct	SBFTFileData
{
	SBFTFileData() 		
	{ 
		bRemove = false;
		testTotalCount = 0;
		lfTemp = 0.0f;

		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
			lfResist[i] = 0.0f;

		dataList.clear(); 
	}
	~SBFTFileData()		
	{ 
		dataList.clear();	
	}

	void AddResistData(SResistanceData* pdata)
	{
		if(pdata)
		{
			long index = pdata->m_material;
			dataList.insert(RESISTANCEDATA_MAP::value_type(index, pdata));
		}

	}

	bool				bRemove;
	long				testTotalCount;
	float				lfTemp;

	float				lfResist[IPC_MAX_MATERIAL];

	MATERIALDATA_MAP	dataList;
};


typedef std::map< long, SBFTFileData* >	BFTFILE_MAP;


// CMeasHistoryDlg ��ȭ �����Դϴ�.

class CMeasHistoryDlg : public CDialog
{
	friend class CMeasReportDlg;

	DECLARE_DYNAMIC(CMeasHistoryDlg)

public:
	CMeasHistoryDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CMeasHistoryDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_MEASHISTORYDLG };

	enum {	EN_STATIC_ZOOM_Y = 0,		
			EN_STATIC_ZOOM_X,			
			EN_STATIC_FAIL,				
			EN_STATIC_FROM_Y,			
			EN_STATIC_TO_Y,				
			EN_STATIC_FROM_X,			
			EN_STATIC_TO_X,				
			EN_STATIC_MAX,
		};

	// Define Button ID Enum
	enum {	EN_BTN_ZOOMIN_Y = 0,
			EN_BTN_ZOOMORG_Y,
			EN_BTN_ZOOMIN_X,
			EN_BTN_ZOOMORG_X,
			EN_BTN_REPORT,
			EN_BTN_MAX,
		};

	// Text Edit
	enum {	EN_EDIT_FROMY	= 0, 
			EN_EDIT_TOY, 
			EN_EDIT_FROMX, 
			EN_EDIT_TOX, 
			EN_EDIT_MAX,
			EN_SPIN_MAX = EN_EDIT_MAX,
		};

	enum {
			FILE_HISTORY_DATE = 0,			
			FILE_HISTORY_COUNT,				
			FILE_HISTORY_RESIST1,			
			FILE_HISTORY_RESIST2,			
			FILE_HISTORY_RESIST3,			
			FILE_HISTORY_RESIST4,			
			FILE_HISTORY_FAIL,				
			FILE_HISTORY_TEMP,				
			FILE_HISTORY_MAX
	};

	void SetFilePath(CString strPath)			{ m_strFilePath = strPath; }

public:
	COLORREF	m_clrBack, m_clrText, m_clrBlue, m_clrOutline, m_clrMask;

	BOOL		m_bFail;
	CFont		m_titleFont;
	CString		m_strFilePath;

	float		m_lfFail;

	CRect		rcResist;
protected:
	CResistanceWnd*	m_pResistanceWnd[IPC_MAX_MATERIAL];

	cXenStatic		m_stStatic[EN_STATIC_MAX];
	cXenButton		m_btnHistory[EN_BTN_MAX];
	cXenEditBox		m_editHistory[EN_EDIT_MAX];
	CSpinButtonCtrl m_spinHistory[EN_SPIN_MAX];

	CStatic			m_stGroup;
	int				m_zoomScale[EN_EDIT_MAX];

	SResultData		m_resultData[IPC_MAX_MATERIAL];
	BFTFILE_MAP		m_BFTList;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	afx_msg void OnBnClickedFail(UINT ID);
	afx_msg void OnBnClickedCommand(UINT ID);
	

	void	Localize();
	void	LocalizeFont();
	void	InitControl();
	void	InitHistory();
	void	SetPosition();

	BOOL	LoadHeader();
	BOOL	LoadResistanceData();

	void	SetResistanceWndPosition();
	void	DrawDialogArea( CDC *pDC );

	void	RemoveAllFileList();

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);

	afx_msg void OnDeltaposSpinFromX(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinToX(NMHDR *pNMHDR, LRESULT *pResult);

};
