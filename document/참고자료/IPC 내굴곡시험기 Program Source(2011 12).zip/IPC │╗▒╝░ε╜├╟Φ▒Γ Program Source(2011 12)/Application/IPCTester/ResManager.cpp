#include "StdAfx.h"
#include "ResManager.h"


CResManager theResMan;

CResManager::CResManager(void)
{
	m_clrMask=PALETTERGB(255,0,255);
}

CResManager::~CResManager(void)
{
}

void CResManager::Init()
{
	HIMAGELIST hSystemImageList, hSystemImageListSmall;

	hSystemImageList = GetSysImageList();
	hSystemImageListSmall = GetSysImageList(TRUE);

	m_imglResManager[IPC_RESMAN_SYSICON_SMALL].Attach(hSystemImageListSmall);
	m_imglResManager[IPC_RESMAN_SYSICON_LARGE].Attach(hSystemImageList);

	InitResManager();
}

void CResManager::InitResManager()
{
	// Load Preference Icon Images
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Windows Titlebar Images
	m_bmpTitlebar.Attach(GetResBitmap(IDB_MAIN_TITLEBAR));

	// Initialize Image List
	/////////////////////////////////////////////////////
	//===================================================================================
	CBitmap bmp;
	BITMAP	bmpInfo;

	// Load Title Logo Image
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	bmp.Attach(GetResBitmap(IDB_IPC_LOGO));
	bmp.GetBitmap(&bmpInfo);
	m_imglResManager[IPC_RESMAN_IPC_LOGO].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
	m_imglResManager[IPC_RESMAN_IPC_LOGO].Add(&bmp, m_clrMask);
	//bmp.Detach();
	bmp.DeleteObject();
	//===========================================================================================================

	// Load Config Dialog Image
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	bmp.Attach(GetResBitmap(IDB_CONFIG_TITLE));
	bmp.GetBitmap(&bmpInfo);
	m_imglResManager[IPC_RESMAN_CONFIG_TITLE].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
	m_imglResManager[IPC_RESMAN_CONFIG_TITLE].Add(&bmp, m_clrMask);
	//bmp.Detach();
	bmp.DeleteObject();
	//===========================================================================================================

	// Load Dialog Title Logo Image
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	bmp.Attach(GetResBitmap(IDB_IPC_CONFIGLOGO));
	bmp.GetBitmap(&bmpInfo);
	m_imglResManager[IPC_RESMAN_IPC_CONFIGLOGO].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
	m_imglResManager[IPC_RESMAN_IPC_CONFIGLOGO].Add(&bmp, m_clrMask);
	//bmp.Detach();
	bmp.DeleteObject();
	//===========================================================================================================
	
	// Load BHflex Logo Image
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	CString m_sBitmap;
	m_sBitmap.Format(_T("UserLogo.bmp"));

	HBITMAP hBitmap = (HBITMAP)::LoadImage(
											AfxGetInstanceHandle(),  
											m_sBitmap,  
											IMAGE_BITMAP,  
											0, 0,  
											LR_LOADFROMFILE | LR_CREATEDIBSECTION);  

	if(hBitmap)
	{
		bmp.Attach(hBitmap);
		bmp.GetBitmap(&bmpInfo);
		m_imglResManager[IPC_RESMAN_IPC_COMPANYLOGO].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
		m_imglResManager[IPC_RESMAN_IPC_COMPANYLOGO].Add(&bmp, m_clrMask);
		//bmp.Detach();
		bmp.DeleteObject();
		//===========================================================================================================
	}
	else
	{
		bmp.Attach(GetResBitmap(IDB_BHFLEX_LOGO));
		bmp.GetBitmap(&bmpInfo);
		m_imglResManager[IPC_RESMAN_IPC_COMPANYLOGO].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
		m_imglResManager[IPC_RESMAN_IPC_COMPANYLOGO].Add(&bmp, m_clrMask);
		//bmp.Detach();
		bmp.DeleteObject();
	}

	// Load Background Images
	for(int j = 0; j < EN_BACKGROUND_MAX; j++)
	{
		m_bmpBG[j].Attach(GetResBitmap(IDB_COUNT_BG + j));
	}

	// Load Default Button Images
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	for (int i=0; i<(IPC_RESMAN_BTN_APPLYNOW - IPC_RESMAN_BTN_DEFAULT)+1; i++)
	{
		bmp.Attach(GetResBitmap(IDB_BTN_DEFAULT+i));
		bmp.GetBitmap(&bmpInfo);
		m_imglResManager[IPC_RESMAN_BTN_DEFAULT+i].Create(bmpInfo.bmWidth/5, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 5);

		m_imglResManager[IPC_RESMAN_BTN_DEFAULT+i].Add(&bmp, m_clrMask);
		//bmp.Detach();
		bmp.DeleteObject();
	}

	// Load Main Button Images
	for (int i=0; i<(IPC_RESMAN_BTN_EXIT - IPC_RESMAN_BTN_TEST_RESTART)+1; i++)
	{
		bmp.Attach(GetResBitmap(IDB_BTN_RESTART + i));
		bmp.GetBitmap(&bmpInfo);
		m_imglResManager[IPC_RESMAN_BTN_TEST_RESTART + i].Create(bmpInfo.bmWidth/4, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 4);

		m_imglResManager[IPC_RESMAN_BTN_TEST_RESTART + i].Add(&bmp, m_clrMask);
		//bmp.Detach();
		bmp.DeleteObject();
	}

	// Load Config Button Images
	for (int i=0; i<(IPC_RESMAN_BTN_REPORT - IPC_RESMAN_BTN_AUTOSTART)+1; i++)
	{
		bmp.Attach(GetResBitmap(IDB_BTN_AUTOSTART + i));
		bmp.GetBitmap(&bmpInfo);
		m_imglResManager[IPC_RESMAN_BTN_AUTOSTART + i].Create(bmpInfo.bmWidth/4, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 4);

		m_imglResManager[IPC_RESMAN_BTN_AUTOSTART + i].Add(&bmp, m_clrMask);
		//bmp.Detach();
		bmp.DeleteObject();
	}

	// Load Status Resize Image
	bmp.Attach(GetResBitmap(IDB_COUNT_BG));
	bmp.GetBitmap(&bmpInfo);
	m_imglResManager[IPC_RESMAN_COUNT_BG].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
	m_imglResManager[IPC_RESMAN_COUNT_BG].Add(&bmp, m_clrMask);
	//bmp.Detach();
	bmp.DeleteObject();
	
	// Load Status Resize Image
	bmp.Attach(GetResBitmap(IDB_STATUS_FAIL));
	bmp.GetBitmap(&bmpInfo);
	m_imglResManager[IPC_RESMAN_SATATUS_FAIL].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
	m_imglResManager[IPC_RESMAN_SATATUS_FAIL].Add(&bmp, m_clrMask);
	//bmp.Detach();
	bmp.DeleteObject();

	// Load Status Resize Image
	bmp.Attach(GetResBitmap(IDB_STATUS_RESIZE));
	bmp.GetBitmap(&bmpInfo);
	m_imglResManager[IPC_RESMAN_SATATUS_RESIZE].Create(bmpInfo.bmWidth, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR24, 0, 1);
	m_imglResManager[IPC_RESMAN_SATATUS_RESIZE].Add(&bmp, m_clrMask);
	//bmp.Detach();
	bmp.DeleteObject();

	// Windows System(Minimize, Maximize, Close) Images Load
	//////////////////////////////////////////////////////////////////////////
	for (int i = 0; i < (IPC_RESMAN_WINDOW_MIN - IPC_RESMAN_WINDOW_CLOSE) + 1; i++)
	{
		bmp.Attach(GetResBitmap(IDB_BTN_CLOSE + i));
		bmp.GetBitmap(&bmpInfo);
		m_imglResManager[IPC_RESMAN_WINDOW_CLOSE + i].Create(bmpInfo.bmWidth/5, bmpInfo.bmHeight, ILC_MASK | ILC_COLOR32, 0, 5);
		m_imglResManager[IPC_RESMAN_WINDOW_CLOSE + i].Add(&bmp, m_clrMask);
		//bmp.Detach();
		bmp.DeleteObject();
	}
}

void CResManager::UnInit()
{
	// Delete Object for Preference Icon Images
	////////////////////////////////////////////////////////

	m_bmpTitlebar.DeleteObject();

	// Detach hImageList for System Icon Images
	////////////////////////////////////////////////////////
	m_imglResManager[IPC_RESMAN_SYSICON_SMALL].Detach();
	m_imglResManager[IPC_RESMAN_SYSICON_LARGE].Detach();
}

void CResManager::Localize()
{
	// Delete Object for Preference Icon Images
	////////////////////////////////////////////////////////
	m_bmpTitlebar.Detach();

	for(int i = IPC_RESMAN_BTN_DEFAULT; i < IPC_RESMAN_MAX ; i++)
	{
		m_imglResManager[i].Detach();
		m_imglResManager[i].DeleteImageList();
	}

	InitResManager();
}

//�ش����� ���� �� ���丮�� �ý��� ������ ImageList Handle�� �����´�.
HIMAGELIST CResManager::GetSysImageList( BOOL bSmall )
{
	SHFILEINFO  sfi;
	ZeroMemory( &sfi, sizeof( SHFILEINFO ) );

	HIMAGELIST hImageList;

	hImageList = (bSmall) ?
		(HIMAGELIST)SHGetFileInfo( (LPCTSTR)_T("c:\\"), 0, &sfi, sizeof(SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_SMALLICON ):
		(HIMAGELIST)SHGetFileInfo( (LPCTSTR)_T("c:\\"), 0, &sfi, sizeof(SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_LARGEICON );

	return hImageList;
}
