#pragma once
#include "ResManager.h"
#include "ctrl/button/Xenbutton.h"

#include <stdio.h>
#include <time.h>


#define	MAX_STATUS_IPCLOG			1

#define IPC_STATUS_TOP				15
#define IPC_STATUS_LEFT				15


enum TestStatus
{
   	TESTSTATUS_INIT_PRETEST = 0,		
	TESTSTATUS_ALLOWABLE,				
	TESTSTATUS_START,			
	TESTSTATUS_PAUSE,
   	TESTSTATUS_RESTART,
   	TESTSTATUS_STOP,
};

// CStatusWnd ��ȭ �����Դϴ�.

class CStatusWnd : public CDialog
{
	DECLARE_DYNAMIC(CStatusWnd)

public:
	CStatusWnd(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CStatusWnd();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_STATUSWND };
	enum {	STATUS_BTN_RESTART = 0,
			STATUS_BTN_PAUSE,
			STATUS_BTN_START,
			STATUS_BTN_STOP,
			STATUS_BTN_REPORT,
			STATUS_BTN_MAX,
		};

	void	Localize();
	void	LocalizeFont();
	void	InitControl();
	void	UpdateTestStatus();

	TestStatus GetTestStatus()					{ return m_testStatus; }

	void	SetTempRequestTimer();
	void	KillTempRequestTimer();

	void	StartBFTRequest();		
	void	StopBFTRequest();		
	void	PauseBFTRequest();		
	
	void	TempDataRequest();		

	/////////////////////////////////////////////////

	void	SetTestStatus(TestStatus status)	{ ::InterlockedExchange((long*)&m_testStatus, status); }

	bool	isBFTest()	{ return (m_testStatus == TESTSTATUS_STOP || m_testStatus == TESTSTATUS_PAUSE)? false : true; }

protected:
	COLORREF		m_clrText, m_clrBack, m_clrMask, m_clrOutline;	

	cXenButton		m_testBtn[STATUS_BTN_MAX + 2];		
	cXenButton		m_btnSKlogo;
	CToolTipCtrl	m_ToolTipCtrl;
	CRect			m_rcPre;

	CWnd*			pParentWnd;
	bool			m_bProgramExit;
	long			m_lTempTimer;

public:
	CRect			m_orgRect;
	TestStatus		m_testStatus;

	float			m_lfTemp;
	int				m_secCount;
	bool			m_bConfirm;
	long			m_lTempScan;

	time_t			m_tiPass;
	UINT			m_timerID;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	afx_msg void	OnBnClickedCommand(UINT ID);
	afx_msg HRESULT OnPauseTest( WPARAM wParam, LPARAM lParam );
	afx_msg HRESULT OnEndTest( WPARAM wParam, LPARAM lParam );
	afx_msg HRESULT OnPreTest( WPARAM wParam, LPARAM lParam );
	afx_msg HRESULT OnBFTest( WPARAM wParam, LPARAM lParam );

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
