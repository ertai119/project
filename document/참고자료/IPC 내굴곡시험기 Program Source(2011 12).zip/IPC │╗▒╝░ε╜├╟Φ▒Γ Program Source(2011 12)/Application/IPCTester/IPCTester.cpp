// IPCTester.cpp : ���� ���α׷��� ���� Ŭ���� ������ �����մϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "IPCTesterDlg.h"
#include <initguid.h>
#include "IPCTester_i.c"


#include <shfolder.h>
#include <shellapi.h>
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� �ڵ� ���� 
#pragma comment(linker, "/SECTION:.shr,RWS")
#pragma data_seg(".shr")
HWND	g_IPCHandle = NULL;
TCHAR	g_sParam[1024] = {NULL,};
#pragma data_seg()


CString GetFloatingFormat(float inter, short len)
{
	// Floating Value Format Define
	CString strFormat;
	strFormat.Format(_T("%%.01f"));

	short cc = len;
	double value = pow(10, (double)cc);
	int rr = inter * value;
	while(!(rr % 10))
	{
		cc--;
		value = pow(10, (double)cc);
		rr = inter * value;
		if(cc == 0) break;
	}
	if(cc) strFormat.Format(_T("%%.0%df"), cc);

	return strFormat;
}

CString GetResString(UINT uStringID)
{
	CString resString;
	if (resString.IsEmpty())
		resString.LoadString(GetModuleHandle(NULL), uStringID);
	return resString;
}

HBITMAP GetResBitmap(UINT uBitmapID)
{
	HBITMAP hBitmap;
	hBitmap = ::LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(uBitmapID));
	return hBitmap;
}

HRESULT GetSpecialFolderPath(int nFolder, CString &szPath)
{
	TCHAR szSystemPath[MAX_PATH];

	DWORD dwRet = ::SHGetFolderPath(NULL, nFolder, NULL, 0, szSystemPath);

	if (dwRet == S_OK)
		szPath = szSystemPath;

	return dwRet;
}

bool	SystemRegistryKeyExist(HKEY hKeyParent, LPCTSTR lpszKeyName);
CString	GetSystemRegistryKey(HKEY hKeyparent, LPCTSTR lpszKeyName, LPCTSTR pszValueName = _T(""));

bool SystemRegistryKeyExist(HKEY hKeyParent, LPCTSTR lpszKeyName)
{
	CRegKey mKey;

	if(mKey.Open(hKeyParent, lpszKeyName, KEY_READ) == ERROR_SUCCESS)
	{
		mKey.Close();
		return true;
	}

	return false;
}

CString	GetSystemRegistryKey(HKEY hKeyparent, LPCTSTR lpszKeyName, LPCTSTR pszValueName)
{
	CRegKey	mKey;
	CString	strValue;
	TCHAR	szValueName[MAX_STRING];
	ULONG	lSize=MAX_STRING;

	strValue.Empty();
	ZeroMemory(szValueName, MAX_STRING);

	LONG err;
	if((err = mKey.Open(hKeyparent, lpszKeyName, KEY_READ)) == ERROR_SUCCESS)
		
	{
		if (mKey.QueryStringValue(pszValueName, (LPTSTR)szValueName, &lSize) == ERROR_SUCCESS)
			strValue = szValueName;
	}

	return strValue;
}

// CIPCTesterApp


class CIPCTesterModule :
	public CAtlMfcModule
{
public:
	DECLARE_LIBID(LIBID_IPCTesterLib);
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_IPCTESTER, "{3A9966BF-0A1F-4992-8183-D1AEF104D571}");};

CIPCTesterModule _AtlModule;

BEGIN_MESSAGE_MAP(CIPCTesterApp, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


// CIPCTesterApp ����

CIPCTesterApp::CIPCTesterApp()
{
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.
	// InitInstance�� ��� �߿��� �ʱ�ȭ �۾��� ��ġ�մϴ�.
	// this is the "base" version number <major>.<minor>.<update>.<build>
	m_dwProductVersionMS = MAKELONG(CIPCTesterApp::m_nVersionMin, CIPCTesterApp::m_nVersionMjr);
	m_dwProductVersionLS = MAKELONG(CIPCTesterApp::m_nVersionBld, CIPCTesterApp::m_nVersionUpd);

	// create a string version (e.g. "0.3000")
	// this is the "base" version number <major>.<minor><update>
	m_strCurVersionLong.Format(_T("%u.%u%02d"), CIPCTesterApp::m_nVersionMjr, 
								CIPCTesterApp::m_nVersionMin, CIPCTesterApp::m_nVersionUpd);

#ifdef _DEBUG
	m_strCurVersionLong += _T(" DEBUG");
#endif
#ifdef _BETA
	m_strCurVersionLong += _T(" BETA");
#endif

	m_pACCT = NULL;
	m_pRMI = NULL;
	m_pFileManager = NULL;

	hMutexOneInstance = NULL;
	InitializeCriticalSection(&m_CriticalSection);
}


// ������ CIPCTesterApp ��ü�Դϴ�.

CIPCTesterApp theApp;


// CIPCTesterApp �ʱ�ȭ

BOOL CIPCTesterApp::InitInstance()
{
	TCHAR szAppDir[MAX_PATH];
	VERIFY( GetModuleFileName(m_hInstance, szAppDir, ARRSIZE(szAppDir)) );
	VERIFY( PathRemoveFileSpec(szAppDir) );
	
	TCHAR szConfigDir[MAX_PATH];
	::wsprintf(szConfigDir, _T("%s\\%s"), szAppDir, CONFIGFOLDER);
	::CreateDirectory(szConfigDir, NULL);

	::wsprintf(m_pszPrefsName, _T("%s%s"), szConfigDir, _T("IPCConfig.ini"));

	AfxOleInit();
	// ���� ���α׷� �Ŵ��佺Ʈ�� ComCtl32.dll ���� 6 �̻��� ����Ͽ� ���־� ��Ÿ����
	// ����ϵ��� �����ϴ� ���, Windows XP �󿡼� �ݵ�� InitCommonControls()�� �ʿ��մϴ�. 
	// InitCommonControls()�� ������� ������ â�� ���� �� �����ϴ�.
	InitCommonControls();

	CWinApp::InitInstance();

	AfxEnableControlContainer();
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	// Register class factories via CoRegisterClassObject().
	if (FAILED(_AtlModule.RegisterClassObjects(CLSCTX_LOCAL_SERVER, REGCLS_MULTIPLEUSE)))
		return FALSE;
	// App was launched with /Embedding or /Automation switch.
	// Run app as automation server.
	if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated)
	{
		// Don't show the main window
		return TRUE;
	}
	// App was launched with /Unregserver or /Unregister switch.
	if (cmdInfo.m_nShellCommand == CCommandLineInfo::AppUnregister)
	{
		_AtlModule.UpdateRegistryAppId(FALSE);
		_AtlModule.UnregisterServer(TRUE);
		return FALSE;
	}
	// App was launched with /Register or /Regserver switch.
	if (cmdInfo.m_nShellCommand == CCommandLineInfo::AppRegister)
	{
		_AtlModule.UpdateRegistryAppId(TRUE);
		_AtlModule.RegisterServer(TRUE);
		return FALSE;
	}

	// ǥ�� �ʱ�ȭ
	// �̵� ����� ������� �ʰ� ���� ���� ������ ũ�⸦ ���̷���
	// �Ʒ����� �ʿ� ���� Ư�� �ʱ�ȭ ��ƾ�� �����ؾ� �մϴ�.
	// �ش� ������ ����� ������Ʈ�� Ű�� �����Ͻʽÿ�.
	// TODO: �� ���ڿ��� ȸ�� �Ǵ� ������ �̸��� ����
	// ������ �������� �����ؾ� �մϴ�.
	SetRegistryKey(_T("���� ���� ���α׷� �����翡�� ������ ���� ���α׷�"));

	m_appStatus = APPSTATUS_NONE;

	thePrefs.Init();
	theResMan.Init();

	// LogObject Start
	m_LOG.Start(thePrefs.GetLogDir(), _T("ipc"));

	m_pFileManager	= new CFileManager();

	CIPCTesterDlg dlg;
	m_pMainWnd = &dlg;
	ipcTesterdlg = &dlg;
	dlg.DoModal();

	// ��ȭ ���ڰ� �������Ƿ� ���� ���α׷��� �޽��� ������ �������� �ʰ�
	// ���� ���α׷��� ���� �� �ֵ��� FALSE�� ��ȯ�մϴ�.
	return FALSE;
}

BOOL CIPCTesterApp::InitApplication()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	 CString szInstance;
     bool AlreadyRunning;

	szInstance = _T("Global\\IPCTester-3A9966BF-0A1F-4992-8183-D1AEF104D571");

     hMutexOneInstance = ::CreateMutex( NULL, TRUE, szInstance);
     AlreadyRunning = (GetLastError() == ERROR_ALREADY_EXISTS);
	if ( AlreadyRunning )
	{ 
		HWND hOther = g_IPCHandle;

		if (hOther != NULL)
		{ 
		}
 
		return FALSE;		
	} 


	return CWinApp::InitApplication();
}

void CIPCTesterApp::LogEvent(LPCTSTR pszLog, short opcode/* = 0*/)
{
#ifndef	_WIN32_WINDOWS_ 
	HANDLE  hEventSource;
	WORD wType;

	if(opcode == 0)	wType = EVENTLOG_INFORMATION_TYPE;
	else if(opcode == 1)	wType = EVENTLOG_WARNING_TYPE;
	else if(opcode == 2)	wType = EVENTLOG_ERROR_TYPE;
	else return;

	if(pszLog && lstrlen(pszLog) > 0)
	{
		hEventSource = RegisterEventSource(NULL, _T("ipc"));
		if (hEventSource != NULL)
		{
			ReportEvent(hEventSource, wType, 0, 0, NULL, 1, 0, (LPCTSTR*)&pszLog, NULL);
			DeregisterEventSource(hEventSource);
		}
	}
#endif
}

void CIPCTesterApp::ErrorLogEvent(LPCTSTR str, ...)
{
	LPTSTR pLog = NULL;
	int argumentcount = 0;
	va_list pArg;
	
	va_start(pArg, str);
	argumentcount = Count_argumentlists(str, pArg);
	if(argumentcount == 0)
	{
		va_end(pArg);	
		return;
	}
	pLog = new TCHAR[argumentcount+1];
	wvsprintf(pLog, str, pArg);
	va_end(pArg);

	m_LOG.LogHelper(2, pLog);
	delete[] pLog;
}

void CIPCTesterApp::Log(BOOL eventviewerflag, LPCTSTR str, ...)
{
	static int log_count = 0;

	LPTSTR pLog = NULL;
	int argumentcount = 0;
	va_list pArg;
	
	if(m_appStatus == APPSTATUS_NONE) return;

	va_start(pArg, str);
	argumentcount = Count_argumentlists(str, pArg);
	if(argumentcount == 0)
	{
		va_end(pArg);	
		return;
	}
	pLog = new TCHAR[argumentcount+1];
	wvsprintf(pLog, str, pArg);
	va_end(pArg);

	if((argumentcount < 2048) && eventviewerflag == IPCLOG)	// Log Display
	{
	}

	if (eventviewerflag != IPCLOG) 
		m_LOG.LogHelper(0, pLog);

	delete[] pLog;
}

void CIPCTesterApp::WarningLog(LPCTSTR str, ...)
{
	LPTSTR pLog = NULL;
	int argumentcount = 0;
	va_list pArg;
	
	va_start(pArg, str);
	argumentcount = Count_argumentlists(str, pArg);
	if(argumentcount == 0)
	{
		va_end(pArg);	
		return;
	}
	pLog = new TCHAR[argumentcount+1];
	wvsprintf(pLog, str, pArg);
	va_end(pArg);

	m_LOG.LogHelper(1, pLog);
	delete[] pLog;
}

void CIPCTesterApp::ErrorLog(LPCTSTR str, ...)	
{
	LPTSTR pLog = NULL;
	int argumentcount = 0;
	va_list pArg;
	
	va_start(pArg, str);
	argumentcount = Count_argumentlists(str, pArg);
	if(argumentcount == 0)
	{
		va_end(pArg);	
		return;
	}
	pLog = new TCHAR[argumentcount+1];
	wvsprintf(pLog, str, pArg);
	va_end(pArg);

	theApp.LogEvent(pLog, 2);
	m_LOG.LogHelper(2, pLog);
	delete[] pLog;
}

int CIPCTesterApp::Count_argumentlists(LPCTSTR lpszFormat, va_list argList)
{
	#define TCHAR_ARG   TCHAR
	#define WCHAR_ARG   WCHAR
	#define CHAR_ARG    char

	#define DOUBLE_ARG  double

	#define FORCE_ANSI      0x10000
	#define FORCE_UNICODE   0x20000
	#define FORCE_INT64     0x40000
	
	if(lpszFormat == NULL)	return 0;
	if(lstrlen(lpszFormat) < 1)	return 0;

	va_list argListSave = argList;

	int nMaxLen = 0;
	for (LPCTSTR lpsz = lpszFormat; *lpsz != '\0'; lpsz = _tcsinc(lpsz))
	{
		if (*lpsz != '%' || *(lpsz = _tcsinc(lpsz)) == '%')
		{
			nMaxLen += (int)_tclen(lpsz);
			continue;
		}

		int nItemLen = 0;

		int nWidth = 0;
		for (; *lpsz != '\0'; lpsz = _tcsinc(lpsz))
		{
			if (*lpsz == '#')			nMaxLen += 2;   
			else if (*lpsz == '*')		nWidth = va_arg(argList, int);
			else if (*lpsz == '-' || *lpsz == '+' || *lpsz == '0' || *lpsz == ' ');
			else 		break;
		}
		if (nWidth == 0)
		{
			nWidth = _ttoi(lpsz);
			for (; *lpsz != '\0' && _istdigit(*lpsz); lpsz = _tcsinc(lpsz));
		}
		if(nWidth < 0)	return 0;

		int nPrecision = 0;
		if (*lpsz == '.')
		{
			lpsz = _tcsinc(lpsz);

			if (*lpsz == '*')
			{
				nPrecision = va_arg(argList, int);
				lpsz = _tcsinc(lpsz);
			}
			else
			{
				nPrecision = _ttoi(lpsz);
				for (; *lpsz != '\0' && _istdigit(*lpsz); lpsz = _tcsinc(lpsz));
			}
			if(nPrecision < 0)	return 0;
		}

		int nModifier = 0;
		if (_tcsncmp(lpsz, _T("I64"), 3) == 0)
		{
			lpsz += 3;
			nModifier = FORCE_INT64;
		}
		else
		{
			switch (*lpsz)
			{
			case 'h':
				nModifier = FORCE_ANSI;
				lpsz = _tcsinc(lpsz);
				break;
			case 'l':
				nModifier = FORCE_UNICODE;
				lpsz = _tcsinc(lpsz);
				break;
			case 'F':
			case 'N':
			case 'L':
				lpsz = _tcsinc(lpsz);
				break;
			}
		}

		switch (*lpsz | nModifier)
		{
		case 'c':
		case 'C':
			nItemLen = 2;
			va_arg(argList, TCHAR_ARG);
			break;
		case 'c'|FORCE_ANSI:
		case 'C'|FORCE_ANSI:
			nItemLen = 2;
			va_arg(argList, CHAR_ARG);
			break;
		case 'c'|FORCE_UNICODE:
		case 'C'|FORCE_UNICODE:
			nItemLen = 2;
			va_arg(argList, WCHAR_ARG);
			break;
		case 's':
			{
				LPCTSTR pstrNextArg = va_arg(argList, LPCTSTR);
				if (pstrNextArg == NULL)	   nItemLen = 6;  
				else
				{
				   nItemLen = lstrlen(pstrNextArg);
				   nItemLen = max(1, nItemLen);
				}
			}
			break;
		case 'S':
			{
#ifndef _UNICODE
				LPWSTR pstrNextArg = va_arg(argList, LPWSTR);
				if (pstrNextArg == NULL)	   nItemLen = 6;  
				else
				{
				   nItemLen = (int)wcslen(pstrNextArg);
				   nItemLen = max(1, nItemLen);
				}
#else
				LPCSTR pstrNextArg = va_arg(argList, LPCSTR);
				if (pstrNextArg == NULL)	   nItemLen = 6; 
				else
				{
				   nItemLen = lstrlenA(pstrNextArg);
				   nItemLen = max(1, nItemLen);
				}
#endif
			}
			break;

		case 's'|FORCE_ANSI:
		case 'S'|FORCE_ANSI:
			{
				LPCSTR pstrNextArg = va_arg(argList, LPCSTR);
				if (pstrNextArg == NULL)	   nItemLen = 6; 
				else
				{
				   nItemLen = lstrlenA(pstrNextArg);
				   nItemLen = max(1, nItemLen);
				}
			}
			break;

		case 's'|FORCE_UNICODE:
		case 'S'|FORCE_UNICODE:
			{
				LPWSTR pstrNextArg = va_arg(argList, LPWSTR);
				if (pstrNextArg == NULL)	   nItemLen = 6; 
				else
				{
				   nItemLen = (int)wcslen(pstrNextArg);
				   nItemLen = max(1, nItemLen);
				}
			}
			break;
		}
		if (nItemLen != 0)
		{
			if (nPrecision != 0)		nItemLen = min(nItemLen, nPrecision);
			nItemLen = max(nItemLen, nWidth);
		}
		else
		{
			switch (*lpsz)
			{
			case 'd':
			case 'i':
			case 'u':
			case 'x':
			case 'X':
			case 'o':
				if (nModifier & FORCE_INT64)			va_arg(argList, __int64);
				else				va_arg(argList, int);
				nItemLen = 32;
				nItemLen = max(nItemLen, nWidth+nPrecision);
				break;
			case 'e':
			case 'g':
			case 'G':
				va_arg(argList, DOUBLE_ARG);
				nItemLen = 128;
				nItemLen = max(nItemLen, nWidth+nPrecision);
				break;
			case 'f':
				{
					double f;
					LPTSTR pszTemp;
					pszTemp = (LPTSTR)_alloca(max(nWidth, 312+nPrecision+6));
					f = va_arg(argList, double);
					_stprintf( pszTemp, _T( "%*.*f" ), nWidth, nPrecision+6, f );
					nItemLen = (int)_tcslen(pszTemp);
				}
				break;
			case 'p':
				va_arg(argList, void*);
				nItemLen = 32;
				nItemLen = max(nItemLen, nWidth+nPrecision);
				break;
			case 'n':
				va_arg(argList, int*);
				break;

			default:
				return 0;
			}
		}

		nMaxLen += nItemLen;
	}
	return nMaxLen;	
}

BOOL CIPCTesterApp::ExitInstance(void)
{
	if(theApp.m_pFileManager)	{ delete m_pFileManager;		m_pFileManager = NULL; }

	thePrefs.Uninit();
	theResMan.UnInit();

	m_LOG.Stop();

	DeleteCriticalSection(&m_CriticalSection);

	if( hMutexOneInstance )
	{
		CloseHandle(hMutexOneInstance);
		hMutexOneInstance = NULL;
	}

	_AtlModule.RevokeClassObjects();
	return CWinApp::ExitInstance();
}

void CIPCTesterApp::SerialDisconnect()
{
	if(m_pACCT && m_pACCT->GetStartFlag()) 
	{
		m_pACCT->CloseConnection();
	}
}

CString CIPCTesterApp::ConvertStrValue(long lValue)
{
	CString strVal;
	strVal.Empty();
	strVal.Format(_T("%u"), lValue);

	int len = strVal.GetLength();
	CString strValue;
	strValue.Empty();

	if(len > 3)
	{
		CString temp;

		int count = len / 3;
		if(!(len % 3))
			count -= 1;

		for(int i = 0; i < count; i++)
		{
			temp.Empty();
			temp.Append(strVal.Right((i + 1) * 3), 3);
			strValue.Insert(0, temp);
			strValue.Insert(0, _T(','));
		}
		temp.Empty();
		temp.Append(strVal.Left((len % 3)? len % 3 : 3), (len % 3)? len % 3 : 3);
		strValue.Insert(0, temp);
	}
	else
		strValue = strVal;

	return strValue;
}

