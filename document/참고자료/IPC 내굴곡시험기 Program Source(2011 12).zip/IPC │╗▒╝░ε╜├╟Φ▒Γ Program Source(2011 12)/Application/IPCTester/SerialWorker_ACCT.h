#pragma once

#include "SerialCommWrapper.h"

#define __INNERP_ACCT_SELECT_MT__		11000


enum ACCT_STATUS
{
	ACCTSTATUS_NONE = 0,
	ACCTSTATUS_CONNECT,
	ACCTSTATUS_DISCONNECT,
	ACCTSTATUS_FINISH
};

class CSerialWorker_ACCT : public CSerialCommWrapper
{
	friend class CStatusWnd;

	class WORKINFO_CLIENT
	{
	public:
		WORKINFO_CLIENT() { ZeroMemory(this, sizeof(WORKINFO_CLIENT)); }
		~WORKINFO_CLIENT() { if(lpbuffer) delete[] lpbuffer ; }

		void*			lpbuffer;	
		int				nSize;
	};

	class WORKINFO_INDICATION
	{
	public:
		WORKINFO_INDICATION() { ZeroMemory(this, sizeof(WORKINFO_INDICATION)); }
		~WORKINFO_INDICATION() { }

		short			m_mtNum;			
		byte			m_mtInfo[4];		
		short			m_amplitude;		
		int				m_bendingSpeed;		
		short			m_autoStart;		
		short			m_temp;				

	};

public:
	CSerialWorker_ACCT(void);
	virtual ~CSerialWorker_ACCT(void);

	enum REQUIRED_KIND
	{
		REQUIRED_NONE = 0,				
		REQUIRED_HEADER,				
		REQUIRED_BODY,					
	};

	ACCT_STATUS GetACCTStatus()			{ return m_status; }

	void SetWindowHandle(HWND hwnd)		{ m_hWnd = hwnd; }

	BOOL SelectMTRequest(short mtNum);					
	BOOL MTPreTest();									

	BOOL StartAmpTest(short amp, int m_bendingSpeed);	
	BOOL AmpDataRequest();								
	BOOL EndAmpTest();									

	BOOL SetParamInfo(void* pParam);					
	BOOL ReadyBFT();									
	BOOL TempDataRequest();								
	BOOL StartBFTRequest();								
	BOOL PauseBFTRequest();								
	BOOL EndBFTRequest();								

protected:
	BOOL Error(HRESULT code, CSerialComm& Connector);
	void LogStr(BOOL eventviewerflag, LPCTSTR pFormat, ...);
	void ErrorLogStr(LPCTSTR pFormat, ...);
	void WarningLogStr(LPCTSTR pFormat, ...);

	void OnReceive(TTYEvent* pEvent, CSerialComm& Connector);
	BOOL OnClose(TTYEvent* pEvent, CSerialComm& Connector);
	void OnUnknownMsg(DWORD userkey, void* pParam, CSerialComm& Connector);
	void OnStart(CSerialComm& Connector);
	void OnConnect(TTYEvent* pEvent, CSerialComm& Connector);
	void OnDisConnect();
	void TimeOutFunction(CSerialComm& Connector);
	void ShutDownService();

	BOOL PacketParsing(TTYEvent* pEvent, byte *lpBuffer, long lLen, CSerialComm& Connector);
	BOOL MethodParsing(int methodid, LPCSTR pBuffer, int addsize, TTYEvent* pEvent, CSerialComm& Connector);

	void ClearVariable(BOOL callingflag = FALSE);

	void MaterialTPreTest(LPCSTR pBuffer, int addsize, int methodid, CSerialComm& Connector);
	void AmplitudeAdjustTest(LPCSTR pBuffer, int addsize, int methodid, CSerialComm& Connector);
	void BendingFatigueTest(LPCSTR pBuffer, int addsize, int methodid, CSerialComm& Connector);

public:

protected:
	HWND	m_hWnd;				

	long	m_ConnectionFlag;
	ACCT_STATUS		m_status;

	time_t m_connecttime;		
	time_t m_last_rcvtime;		
	time_t m_last_sndtime;		

	BOOL m_requiredNext;		
	int m_SavedMethod;
	unsigned long m_ReceivedSize;			
	unsigned long m_RequiredReceiveSize;	
	byte* m_pSaveBuffer;

};
