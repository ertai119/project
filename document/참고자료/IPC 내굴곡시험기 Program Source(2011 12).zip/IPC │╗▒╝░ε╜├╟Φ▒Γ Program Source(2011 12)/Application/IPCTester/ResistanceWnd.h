#pragma once
#include "afxwin.h"

#include "Ctrl/static/static.h"

#define IPC_RESISTANCE_TOP				2
#define IPC_RESISTANCE_LEFT				2
#define IPC_RESISTANCE_BOTTOM			2

#define IPC_RESISTANCE_GRAPH_STARTX		65

#define IPC_RESISTANCE_GRAPH_STARTY		IPC_RESISTANCE_TOP * 4
#define IPC_RESISTANCE_GRAPH_ENDY		35

#define IPC_RESISTANCE_GRAPH_XPIXEL		100				// 100 Pixel �� X �� ǥ��
#define IPC_RESISTANCE_GRAPH_XVALUE		20				// 1 POint �� 50 Pixel
#define	IPC_RESISTANCE_GRAPH_YPOINTS	6

#define IPC_RESISTANCE_MAXPOINTS		200

struct SResistanceData
{
	SResistanceData()	{ ZeroMemory(this, sizeof(SResistanceData)); }

	short	m_material;		
	long	m_count;		
	float	m_lfResist;		
	short	m_fail;			
};


typedef std::map< long, SResistanceData* >	RESISTANCEDATA_MAP;

// CResistanceWnd ��ȭ �����Դϴ�.

class CResistanceWnd : public CWnd
{
	DECLARE_DYNAMIC(CResistanceWnd)

public:
	CResistanceWnd();   // ǥ�� �������Դϴ�.
	virtual ~CResistanceWnd();

// ��ȭ ���� �������Դϴ�.
	// Define Static Enum
	enum {	EN_STATIC_INIT_RESIST = 0,		
			EN_STATIC_MEAS_RESIST,			
			EN_STATIC_RATE_OF_CHANGE,		
			EN_STATIC_MAX,
		};

	enum {	EN_STATIC_SCALE_X = 0,
			EN_STATIC_SCALE_Y,
			EN_SCALE_MAX,
		};

	short	GetFailCount()					{ return m_failCount; }
	bool	IsFail()						{ return m_bFail;	}

	float	GetOrgMaxScaleY()				{ return m_maxScaleYOrg; }
	float	GetOrgMaxScaleX()				{ return m_maxScaleXOrg; }

	int		GetBendingCount()				{ return m_bendingCount; }

	void	SetMaterialNum(short num)		{ m_materialNum = num; }
	void	SetHistoryWindow()				{ m_historyWnd = TRUE; }
	void	SetFail(bool fail)				{ m_bFail = fail; m_failCount++; }

	void	SetFailMargin(float failmargin);

	void	DrawFailMargin(bool bmargin);
	void	ClearResistanceData();


	BOOL	PreTestResistance(float resist, bool binit = false);
	void	InitResistance(float resist, bool bfailmargin);

	BOOL	AddResistanceData(SResistanceData*	pdata);

	void	ChangeZoomScaleY(float from, float to);
	void	ChangeZoomScaleX(long from, long to);

	void	ChangeOrgScaleX();
	void	ChangeOrgScaleY();

public:
	COLORREF	m_clrBack, m_clrText, m_clrValue[EN_STATIC_MAX], m_clrMask;
	COLORREF	m_clrScale[2];

protected:
	CString		m_stStatus[EN_STATIC_MAX];
	CString		m_stResistance[EN_STATIC_MAX];
	CRect		m_rcStatus[EN_STATIC_MAX];
	CRect		m_rcResistance[EN_STATIC_MAX];
	CString		m_stFail;
	CRect		m_rcFail;

	CStatic		m_stY;
	cXenStatic	m_stX;

	RESISTANCEDATA_MAP	m_datalist;

	CPoint		ptResistance[IPC_RESISTANCE_MAXPOINTS];

	CRect		m_rcGraph;
	short		m_materialNum;
	float		m_lfInitResist;			
	float		m_failPercent;			
	bool		m_bFail;

	float		m_maxScale, m_minScale;
	float		m_maxFailMargin, m_minFailMargin;
	bool		m_bScaleDef, m_bXScaleDef;

	bool		m_bFailMargin;
	long		m_maxScaleX, m_minScaleX;

	float		m_maxScaleYOrg, m_minScaleYOrg;
	long		m_maxScaleXOrg, m_minScaleXOrg;

	long		m_initCount;
	int			m_bendingCount;

	short		m_failCount;
	long		m_testCount;

	BOOL		m_historyWnd;

	CRITICAL_SECTION	m_cs;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	void	Localize();
	void	LocalizeFont();
	void	InitControl();
	void	SetPosition();

	void	DrawGraphicArea(CDC* pDC);
	void	DrawGraphicNet(CDC* pDC);
	void	DrawGraphicData(CDC* pDC);

	void	DrawGraphicHistoryArea(CDC* pDC);
	void	DrawGraphicHistoryNet(CDC* pDC);
	void	DrawGraphicHistoryData(CDC* pDC);
	//

	void	RemoveAllDataList();
	SResistanceData* FindResistanceData(int count);
	void	RemoveResistanceData(int count);

	long	MaxMeasureCount();
	long	MinMeasureCount();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg HRESULT OnBFTestDraw(WPARAM wParam, LPARAM lParam);

	afx_msg void OnPaint();
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual BOOL DestroyWindow();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
