#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <visa.h>

typedef struct _ASRLSTRUCT
{
	short		asrlid;						
	DWORD		dwBaudRate;
	BYTE		byParity; 
	BYTE		byDataBits; 
	BYTE		byStopBits;

} ASRLSTRUCT, *LPASRLSTRUCT;


class CRMIInterface
{
public:
	CRMIInterface(void);
	virtual ~CRMIInterface(void);

	void	SetWindowHandle(HWND hwnd)		{ m_hWnd = hwnd; }

	void	SetSessionSerialPort(LPASRLSTRUCT lpASRL);
	int		RequestResistData();

protected:
	ASRLSTRUCT		m_ASRLInfo;
	ViSession		defaultRM, vi;

	HWND			m_hWnd;
};
