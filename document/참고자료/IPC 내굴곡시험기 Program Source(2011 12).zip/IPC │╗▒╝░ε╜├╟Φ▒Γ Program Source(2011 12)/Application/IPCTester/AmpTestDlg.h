#pragma once
#include "Ctrl/Button/XenButton.h"
#include "Ctrl/static/static.h"

#define IPC_AMPTEST_TOP				15
#define IPC_AMPTEST_LEFT			15
#define IPC_AMPTEST_BOTTOM			10

#define IPC_AMPTEST_GRAPH_STARTX	73
#define IPC_AMPTEST_GRAPH_HEIGHT	200

// CAmpTestDlg ��ȭ �����Դϴ�.

class CAmpTestDlg : public CDialog
{
	DECLARE_DYNAMIC(CAmpTestDlg)

public:
	CAmpTestDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CAmpTestDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_AMPTESTDLG };

	// Define Static Enum
	enum {	EN_STATIC_AMP,
			EN_STATIC_AMP_CURRENT,
			EN_STATIC_MAX,
		};

	//void	LocalizeFont();
	//void	InitControl();
	//void	InitPos();

	//void	DrawGraphicArea(CDC* pDC);


	//COLORREF	m_clrBack, m_clrText, m_clrValue, m_clrMask;

	//cXenButton		m_btnStop;
	//cXenStatic		m_stAmp[EN_STATIC_MAX];

//protected:
//	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
//	virtual void OnOK();

//	DECLARE_MESSAGE_MAP()
//public:
//	virtual BOOL OnInitDialog();
	//afx_msg void OnClose();
};
