// ResistanceWnd.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "ResistanceWnd.h"


// CResistanceWnd ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CResistanceWnd, CWnd)

CResistanceWnd::CResistanceWnd()
{
	m_clrBack		= IPC_BACKGROUND_COLOR;	
	m_clrText		= PALETTERGB(0,0,0);			// BLACK

	m_clrValue[0]	= PALETTERGB(255, 255, 255);	// White
	m_clrValue[1]	= PALETTERGB(0, 199, 0);		// Green
	m_clrValue[2]	= PALETTERGB(255, 255, 0);		// Yellow

	m_clrScale[0]	= PALETTERGB(128, 128, 128);
	m_clrScale[1]	= PALETTERGB(0, 0, 255);

	m_clrMask		= PALETTERGB(255,0,255);		// PINK

	m_materialNum = 0;
	m_lfInitResist = 5.0;

	m_maxScale = 10.0f;
	m_minScale = 0.0f;
	m_maxScaleX = 100.0f;
	m_minScaleX = 100000000.0f;

	m_maxScaleYOrg = 10.0f;
	m_minScaleYOrg = 0.0f;
	m_maxScaleXOrg = 100.0f; 
	m_minScaleXOrg = 100000000.0f;

	m_minFailMargin = m_maxFailMargin = 0;
	m_bScaleDef = false;
	m_bFail = false;
	m_failCount = 0;
	m_testCount = 0;
	m_bendingCount = 1;

	m_datalist.clear();

	m_historyWnd = FALSE;
	m_bFailMargin = true;
	m_failPercent = 0.0f;

	m_initCount = 0;
	m_bXScaleDef = false;

	InitializeCriticalSection(&m_cs);
}

CResistanceWnd::~CResistanceWnd()
{
	RemoveAllDataList();

	DeleteCriticalSection(&m_cs);
}

void CResistanceWnd::DoDataExchange(CDataExchange* pDX)
{
	CWnd::DoDataExchange(pDX);
}

void CResistanceWnd::Localize()
{
	if(m_historyWnd)
	{
	}
	else
	{
		for (int i = 0; i < EN_STATIC_MAX; i++)
		{
			m_stStatus[i] = GetResString(IDS_RESISTANCE_STATIC_1 + i);
			m_stResistance[i] = _T("0");
		}

	}

	m_stX.SetCaption(GetResString(IDS_RESISTANCE_STATIC_4));

	UpdateData(FALSE);
}

void CResistanceWnd::LocalizeFont()
{
	CFont *pFont = thePrefs.GetGUIDefault();
	CFont*	m_fontBold = thePrefs.GetGUIDefaultBold();

	m_stX.SetFont(pFont);
	m_stY.SetFont(pFont);
}

void CResistanceWnd::SetPosition()
{
	CRect	rcClient;
	GetClientRect(&rcClient);

	CDC*	pDC = GetDC();
	DrawGraphicArea(pDC);
	ReleaseDC(pDC);

	if (m_stY.m_hWnd && m_stX.m_hWnd)
	{
		int nCtrlWidth = 80;
		int	nCtrlHeight = 15;
		int	nCtrlIntv = 5, nLineIntv = 5;

		nLineIntv = (m_rcGraph.Height() / 5) - nCtrlHeight;

		CRect	rcTemp(0, 0, 0, 0);

		CRect	rcStatic;
		m_stY.GetClientRect(&rcStatic);

		int yy = rcClient.bottom - (IPC_RESISTANCE_GRAPH_STARTY + IPC_RESISTANCE_GRAPH_ENDY);
		yy = (yy - rcStatic.Height()) / 2;

		m_stY.SetWindowPos(0, rcStatic.left + IPC_RESISTANCE_LEFT * 2, yy + IPC_RESISTANCE_GRAPH_STARTY, 
							  0, 0, SWP_NOSIZE | SWP_NOREDRAW);

		rcTemp.bottom = rcClient.bottom;
		rcTemp.top = rcTemp.bottom - nCtrlHeight;

		rcTemp.left = rcClient.left + IPC_RESISTANCE_LEFT * 10;
		rcTemp.right = rcClient.right - IPC_RESISTANCE_LEFT * 10;

		m_stX.MoveWindow(&rcTemp, FALSE);
		m_stX.Invalidate(FALSE);
		m_stX.ShowWindow(SW_SHOW);

		if(!m_historyWnd)
		{
			rcTemp.left		= rcClient.left + IPC_RESISTANCE_GRAPH_STARTX + IPC_RESISTANCE_LEFT * 4 ;
			rcTemp.top		= rcClient.top + IPC_RESISTANCE_TOP * 6;
			rcTemp.right	= rcTemp.left + nCtrlWidth;
			rcTemp.bottom	= rcTemp.top + nCtrlHeight;

			for(int i = 0; i < EN_STATIC_MAX; i++)
			{
				int nLeft = rcTemp.left;
				
				CRect rcItem(nLeft, rcTemp.top, nLeft + nCtrlWidth, rcTemp.top + nCtrlHeight);
				m_rcStatus[i] = rcItem;

				rcItem.left += (nCtrlWidth + nCtrlIntv);
				rcItem.right = rcItem.left + nCtrlWidth;

				m_rcResistance[i] = rcItem;

				if(i == EN_STATIC_INIT_RESIST)	
				{
					rcItem.left += (nCtrlWidth + nCtrlIntv * 13);
					rcItem.right = rcItem.left + nCtrlWidth * 2;

					m_rcFail = rcItem;
				}

				rcTemp.top = rcItem.bottom + nLineIntv;
			}
		}
	}
}

void CResistanceWnd::InitControl()
{
	CRect	rcTemp(0,0,0,0);

	m_stX.Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, 
						CRect(0, 0, 0, 0), this, IDC_RESISTANCE_SCALE_X);

	m_stX.SetAlign(DT_CENTER | DT_BOTTOM | DT_SINGLELINE);
	m_stX.SetTransparent();
	m_stX.SetFontColor( m_clrScale[1] );	

	m_stY.Create(GetResString(IDS_RESISTANCE_STATIC_5), 
						WS_CHILD | WS_VISIBLE | SS_CENTER, 
						CRect(0, 0, 20, 50), this, IDC_RESISTANCE_SCALE_Y);

	m_bendingCount = thePrefs.m_bendingSpeed * thePrefs.m_interval;
}

void CResistanceWnd::DrawGraphicArea(CDC* pDC)
{
	if(m_historyWnd)
	{
		DrawGraphicHistoryArea(pDC);
		return;
	}

	CRect rcClient;
	GetClientRect(&rcClient);

	CRect	rcTemp;

	rcTemp.left = rcClient.left + IPC_RESISTANCE_GRAPH_STARTX;
	rcTemp.top = rcClient.top + IPC_RESISTANCE_GRAPH_STARTY;
	rcTemp.right = rcClient.right - IPC_RESISTANCE_LEFT * 4;
	rcTemp.bottom = rcClient.bottom - IPC_RESISTANCE_GRAPH_ENDY;

	int inter = rcTemp.Height() / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	// 6 �ܰ�
	rcTemp.bottom = rcTemp.top + ((IPC_RESISTANCE_GRAPH_YPOINTS - 1) * inter);

	m_rcGraph = rcTemp;

	COLORREF bkGraph = m_clrText;
	if(m_historyWnd)	bkGraph = PALETTERGB(250, 250, 250);

	CBrush brGraph(bkGraph);
	CBrush brFail(PALETTERGB(250, 250, 250));
	CBrush* pOldBrush = pDC->SelectObject(&brGraph);

	if(m_bFail)
		pDC->FillRect(rcTemp, &brFail);
	else
		pDC->FillRect(rcTemp, &brGraph);

	pDC->SelectObject(pOldBrush);

	// Draw Pen
	CPen pen;
	pen.CreatePen(PS_SOLID, 1, PALETTERGB(0, 0, 0));

	CPen *pOldPen = pDC->SelectObject(&pen);

	if(m_bFail || m_historyWnd)
		pDC->Rectangle(rcTemp.left-1, rcTemp.top-1, rcTemp.right + 1, rcTemp.bottom);

	CFont*	pFont;
	pFont = thePrefs.GetGUIDefault();

    CFont* pOldFont = pDC->SelectObject(pFont);
	pDC->SetTextColor(m_clrText);
	pDC->SetBkColor(m_clrBack);
	pDC->SetBkMode(OPAQUE);

	// Net Line Interval
	// Graph Width / Height ����
	int	graphW = rcClient.right - IPC_RESISTANCE_GRAPH_STARTX;
	int	graphH = rcTemp.bottom - rcTemp.top;

	int	interY = graphH / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	
	int interX = graphW / IPC_RESISTANCE_GRAPH_XPIXEL;			
	
	{
		CRect	rcItem;

		CBrush brBack(m_clrBack);

		rcItem.left = rcTemp.left - 43;
		rcItem.right = rcItem.left + 35;
		rcItem.top = rcTemp.top - 5;
		rcItem.bottom = rcTemp.bottom + 5;
		pDC->FillRect(rcItem, &brBack);

		rcItem.right = rcTemp.right + 5;
		rcItem.left = rcTemp.left - 90;
		rcItem.top = rcTemp.bottom + 1;
		rcItem.bottom = rcItem.top + 20;
		pDC->FillRect(rcItem, &brBack);

		rcItem.left = rcTemp.left - 43;
		rcItem.right = rcItem.left + 35;

		for(int i = 0; i < IPC_RESISTANCE_GRAPH_YPOINTS; i++)
		{
			rcItem.top = rcTemp.top + (i * interY) - 5;
			rcItem.bottom = rcItem.top + 15;

			pDC->MoveTo(rcTemp.left - 5, rcTemp.top + (i * interY));
			pDC->LineTo(rcTemp.left, rcTemp.top + (i * interY));

			if(m_bScaleDef)
			{
				CString strVal;
				float inter = (m_maxScale - m_minScale) / 5.0;
		
				CString strFormat = GetFloatingFormat(inter, 1);

				if(m_minScale >= 0 && m_maxScale >= 0) 
					strVal.Format(strFormat, m_maxScale - (i * inter));
				else
					strVal.Format(strFormat, m_minScale + (i * inter));

				pDC->DrawText(strVal, rcItem, DT_RIGHT | DT_SINGLELINE | DT_VCENTER );
			}
			else
			{
				pDC->DrawText(GetResString(IDS_RESISTANCE_STATIC_Y1 + i), 
								rcItem, DT_RIGHT | DT_SINGLELINE | DT_VCENTER );
			}
		}

		CString strCount;
		LONG totalCount = m_testCount;

		strCount.Format(_T("%ld"), totalCount);

		rcItem.right = rcTemp.right + 5;
		rcItem.left = rcItem.right - 90;
		rcItem.top = rcTemp.bottom + 7;
		rcItem.bottom = rcItem.top + 15;

		pDC->DrawText(strCount, rcItem, DT_SINGLELINE | DT_RIGHT | DT_VCENTER );

		for(int i = 0; i <= interX; i++)
		{
			short left = rcTemp.right - (i * IPC_RESISTANCE_GRAPH_XPIXEL);
			if(left > IPC_RESISTANCE_GRAPH_STARTX)
			{
				pDC->MoveTo(left - 1, rcTemp.bottom);
				pDC->LineTo(left - 1, rcTemp.bottom + 5);

				int inter = thePrefs.m_bendingSpeed * thePrefs.m_interval * 
							(IPC_RESISTANCE_GRAPH_XPIXEL / IPC_RESISTANCE_GRAPH_XVALUE);

				if((totalCount - (i * inter)) > 0)
				{
					rcItem.right = left + 5;
					rcItem.left = left - 50;

					strCount.Format(_T("%ld"), (totalCount - (i * inter)));
					pDC->DrawText(strCount, rcItem, DT_SINGLELINE | DT_RIGHT | DT_VCENTER );
				}
			}
		}
	}

	pen.DeleteObject();

	DrawGraphicNet(pDC);
	DrawGraphicData(pDC);

	pDC->SetBkColor(m_clrText);
	pDC->SetBkMode(TRANSPARENT);

	CRect	rcItem;
	for(int i = 0; i < EN_STATIC_MAX; i++)
	{
		if(m_bFail) pDC->SetTextColor(m_clrText);
		else		pDC->SetTextColor(m_clrValue[i]);

		pDC->DrawText(m_stStatus[i], m_rcStatus[i], DT_SINGLELINE | DT_LEFT | DT_VCENTER );
		pDC->DrawText(m_stResistance[i], m_rcResistance[i], DT_SINGLELINE | DT_LEFT | DT_VCENTER );
	}

	if(m_bFail)
	{
		CImageList* pImage = theResMan.GetImageListRes( IPC_RESMAN_SATATUS_FAIL );
		CPoint ptImage(m_rcFail.left - 20, m_rcFail.top - 1);
		pImage->Draw(pDC, 0, ptImage, ILD_TRANSPARENT);

		pDC->SetTextColor(PALETTERGB(255, 0, 0));	// Red
		pDC->DrawText(m_stFail, m_rcFail, DT_SINGLELINE | DT_LEFT | DT_VCENTER );
	}

	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOldFont);
}

void CResistanceWnd::DrawGraphicNet(CDC* pDC)
{
	// Net Line Interval
	// Graph Width / Height ����
	int	graphW = m_rcGraph.Width();
	int	graphH = m_rcGraph.Height();

	int	interY = graphH / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	
	int interX = graphW / IPC_RESISTANCE_GRAPH_XPIXEL;			

	CPen pen;
	pen.CreatePen(PS_SOLID, 1, PALETTERGB(95, 95, 43));

	CPen *pOldPen = pDC->SelectObject(&pen);

	// Y �� 
	for(int i = 0; i < IPC_RESISTANCE_GRAPH_YPOINTS; i++)
	{
		pDC->MoveTo(m_rcGraph.left, m_rcGraph.top + (i * interY));
		pDC->LineTo(m_rcGraph.right, m_rcGraph.top + (i * interY));
	}
	pen.DeleteObject();

	pDC->SelectObject(pOldPen);
}

void CResistanceWnd::DrawGraphicData(CDC* pDC)
{
	if(!m_bScaleDef)
		return;

	// Net Line Interval
	// Graph Width / Height ����
	int	graphW = m_rcGraph.Width();
	int	graphH = m_rcGraph.Height();

	int	interY = graphH / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	
	int interX = graphW / IPC_RESISTANCE_GRAPH_XPIXEL;			

	CPen penData;
	CPen *pOldPen = NULL;

	penData.CreatePen(PS_SOLID, 1, PALETTERGB(0, 255, 0));
	pOldPen = pDC->SelectObject(&penData);

	LONG totalCount = m_testCount;

	int xPoints = graphW / IPC_RESISTANCE_GRAPH_XVALUE; 

	int measCount = 0;
	int i = 0;

	if(m_bFail) 
		i = 1;

	for(; i < xPoints + 2; i++)
	{
		int inter = thePrefs.m_bendingSpeed * thePrefs.m_interval;

		SResistanceData* pdata = FindResistanceData(totalCount - (i *inter));

		if(pdata)
		{
			float lfValue = pdata->m_lfResist;

			int y = ((m_rcGraph.Height() * (lfValue - m_minScale)) / (float)(m_maxScale - m_minScale)); 
			int x = i * IPC_RESISTANCE_GRAPH_XVALUE;

			int ypoint = m_rcGraph.bottom - (y + 1);
			int xpoint = m_rcGraph.right - x;

			if(xpoint >= m_rcGraph.left)
				ptResistance[measCount++] = CPoint(xpoint, ypoint);

			if(measCount > IPC_RESISTANCE_MAXPOINTS)
				break;
		}
	}

	pDC->Polyline(ptResistance, measCount);

	pDC->SelectObject(pOldPen);
}

void CResistanceWnd::DrawGraphicHistoryArea(CDC* pDC)
{
	if(!m_bXScaleDef)
		return;

	CRect rcClient;
	GetClientRect(&rcClient);

	CRect	rcTemp;

	rcTemp.left = rcClient.left + IPC_RESISTANCE_GRAPH_STARTX;
	rcTemp.top = rcClient.top + IPC_RESISTANCE_GRAPH_STARTY;
	rcTemp.right = rcClient.right - IPC_RESISTANCE_LEFT * 4;
	rcTemp.bottom = rcClient.bottom - IPC_RESISTANCE_GRAPH_ENDY;

	int inter = rcTemp.Height() / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	// 6 �ܰ�
	rcTemp.bottom = rcTemp.top + ((IPC_RESISTANCE_GRAPH_YPOINTS - 1) * inter);

	// Graph ũ�⸦ ���� ������ �����Ѵ�.
	m_rcGraph = rcTemp;

	// Graph Area FillRect (250, 250, 250 Color)
	COLORREF bkGraph = PALETTERGB(250, 250, 250);

	CBrush brGraph(bkGraph);
	CBrush* pOldBrush = pDC->SelectObject(&brGraph);

	pDC->FillRect(rcTemp, &brGraph);
	pDC->SelectObject(pOldBrush);

	// Draw Pen
	CPen pen;
	pen.CreatePen(PS_SOLID, 1, PALETTERGB(0, 0, 0));

	CPen *pOldPen = pDC->SelectObject(&pen);

	pDC->Rectangle(rcTemp.left-1, rcTemp.top-1, rcTemp.right + 1, rcTemp.bottom);

	CFont*	pFont;
	pFont = thePrefs.GetGUIDefault();

    CFont* pOldFont = pDC->SelectObject(pFont);
	pDC->SetTextColor(m_clrText);
	pDC->SetBkColor(m_clrBack);
	pDC->SetBkMode(OPAQUE);

	// Net Line Interval
	// Graph Width / Height ����
	int	graphW = m_rcGraph.right - m_rcGraph.left;
	int	graphH = m_rcGraph.bottom - m_rcGraph.top;

	if(graphW < 0 || graphH < 0)
		return;

	int	interY = graphH / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	
	int interX = graphW / IPC_RESISTANCE_GRAPH_XPIXEL;			
	
	{
		CBrush brBack(m_clrBack);
		CRect	rcItem;

		rcItem.left = rcTemp.left - 43;
		rcItem.right = rcItem.left + 35;
		rcItem.top = rcTemp.top - 5;
		rcItem.bottom = rcTemp.bottom + 5;
		pDC->FillRect(rcItem, &brBack);

		rcItem.right = rcTemp.right + 5;
		rcItem.left = rcTemp.left - 90;
		rcItem.top = rcTemp.bottom + 1;
		rcItem.bottom = rcItem.top + 20;
		pDC->FillRect(rcItem, &brBack);

		rcItem.left = rcTemp.left - 43;
		rcItem.right = rcItem.left + 35;

		for(int i = 0; i < IPC_RESISTANCE_GRAPH_YPOINTS; i++)
		{
			rcItem.top = rcTemp.top + (i * interY) - (IPC_RESISTANCE_GRAPH_YPOINTS - 1);
			rcItem.bottom = rcItem.top + 15;

			pDC->MoveTo(rcTemp.left - 5, rcTemp.top + (i * interY));
			pDC->LineTo(rcTemp.left, rcTemp.top + (i * interY));

			CString strVal;
			float inter = (m_maxScale - m_minScale) / (float)(IPC_RESISTANCE_GRAPH_YPOINTS - 1);
	
			CString strFormat = GetFloatingFormat(inter, 1);

			if(m_minScale >= 0 && m_maxScale >= 0) 
				strVal.Format(strFormat, m_maxScale - (i * inter));
			else
				strVal.Format(strFormat, m_minScale + (i * inter));

			pDC->DrawText(strVal, rcItem, DT_RIGHT | DT_SINGLELINE | DT_VCENTER );
		}

		CString strCount;
		LONG maxCount = MaxMeasureCount();

		strCount.Format(_T("%ld"), maxCount);

		rcItem.right = rcTemp.right + 5;
		rcItem.left = rcItem.right - 90;
		rcItem.top = rcTemp.bottom + 7;
		rcItem.bottom = rcItem.top + 15;

		pDC->DrawText(strCount, rcItem, DT_SINGLELINE | DT_RIGHT | DT_VCENTER );

		int inter = ((m_maxScaleX - m_minScaleX) / m_bendingCount) / (interX);
		if(inter == 0) inter = 1;

		short	nPixel = IPC_RESISTANCE_GRAPH_XPIXEL;
		if(inter == 1)
			nPixel = graphW / ((m_maxScaleX - m_minScaleX) / m_bendingCount);

		interX = graphW / nPixel;			

		for(int i = 0; i < interX + 2; i++)
		{
			short left = rcTemp.right - (i * nPixel);
			if(left >= IPC_RESISTANCE_GRAPH_STARTX)
			{
				pDC->MoveTo(left - 1, rcTemp.bottom);
				pDC->LineTo(left - 1, rcTemp.bottom + 5);

				if((maxCount - (i * inter * m_bendingCount)) >= 0)
				{
					rcItem.right = left + 5;
					rcItem.left = left - 50;

					pDC->FillRect(rcItem, &brBack);

					strCount.Format(_T("%ld"), (maxCount - (i * inter * m_bendingCount)));
					pDC->DrawText(strCount, rcItem, DT_SINGLELINE | DT_RIGHT | DT_VCENTER );
				}
				else
				{
					rcItem.right = left + 5;
					rcItem.left = left - 50;

					pDC->FillRect(rcItem, &brBack);
				}
			}
		}
	}

	pen.DeleteObject();

	DrawGraphicHistoryNet(pDC);
	DrawGraphicHistoryData(pDC);

	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOldFont);
}

void CResistanceWnd::DrawGraphicHistoryNet(CDC* pDC)
{
	// Net Line Interval
	// Graph Width / Height ����
	int	graphW = m_rcGraph.Width();
	int	graphH = m_rcGraph.Height();

	int	interY = graphH / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	
	int interX = graphW / IPC_RESISTANCE_GRAPH_XPIXEL;			

	CPen pen;
	if(m_historyWnd)
		pen.CreatePen(PS_SOLID, 1, PALETTERGB(196, 200, 124));
	else
		pen.CreatePen(PS_SOLID, 1, PALETTERGB(95, 95, 43));

	CPen *pOldPen = pDC->SelectObject(&pen);

	for(int i = 0; i < IPC_RESISTANCE_GRAPH_YPOINTS; i++)
	{
		pDC->MoveTo(m_rcGraph.left, m_rcGraph.top + (i * interY));
		pDC->LineTo(m_rcGraph.right, m_rcGraph.top + (i * interY));
	}

	int inter = ((m_maxScaleX - m_minScaleX) / m_bendingCount) / (interX);
	if(inter == 0) inter = 1;

	short	nPixel = IPC_RESISTANCE_GRAPH_XPIXEL;
	if(inter == 1)
	{
		nPixel = graphW / ((m_maxScaleX - m_minScaleX) / m_bendingCount);
		interX = graphW / nPixel;			// n Pixel ���� Draw
	}

	for(int i = 0; i < interX + 2; i++)
	{
		short left = m_rcGraph.right - i * nPixel;
		if(left > m_rcGraph.left)
		{
			pDC->MoveTo(left - 1, m_rcGraph.top);
			pDC->LineTo(left - 1, m_rcGraph.bottom);
		}
		else
		{
			pDC->MoveTo(m_rcGraph.left, m_rcGraph.top);
			pDC->LineTo(m_rcGraph.left, m_rcGraph.bottom);

			break;
		}
	}

	float margin = m_failPercent * 0.01;
	float minMargin = m_lfInitResist - (m_lfInitResist * margin);
	float maxMargin = m_lfInitResist + (m_lfInitResist * margin);

	int ypixel = ((m_rcGraph.Height() * (m_lfInitResist - m_minScale)) / (float)(m_maxScale - m_minScale));

	CPen pointpen;
	pointpen.CreatePen(PS_SOLID, 1, PALETTERGB(82, 82, 82));
	pDC->SelectObject(&pointpen);

	int yinterval = m_rcGraph.bottom - (ypixel + 1);
	pDC->MoveTo(m_rcGraph.left, yinterval);
	pDC->LineTo(m_rcGraph.right, yinterval);

	if(m_bFailMargin)
	{
		CPen marginpen;
		marginpen.CreatePen(PS_DASHDOT, 1, PALETTERGB(247, 131,134));
		pDC->SelectObject(&marginpen);

		int miny = ((m_rcGraph.Height() * (minMargin - m_minScale)) / (float)(m_maxScale - m_minScale)); 
		int maxy = ((m_rcGraph.Height() * (maxMargin - m_minScale)) / (float)(m_maxScale - m_minScale)); 

		yinterval = m_rcGraph.bottom - (miny + 1);
		pDC->MoveTo(m_rcGraph.left, yinterval);
		pDC->LineTo(m_rcGraph.right, yinterval);

		yinterval = m_rcGraph.bottom - (maxy + 1);
		pDC->MoveTo(m_rcGraph.left, yinterval);
		pDC->LineTo(m_rcGraph.right, yinterval);

		marginpen.DeleteObject();
	}
	pointpen.DeleteObject();
	pen.DeleteObject();

	pDC->SelectObject(pOldPen);
}

void CResistanceWnd::DrawGraphicHistoryData(CDC* pDC)
{
	if(!m_bScaleDef)
		return;

	// Net Line Interval
	// Graph Width / Height ����
	int	graphW = m_rcGraph.Width();
	int	graphH = m_rcGraph.Height();

	if(graphW < 0 || graphH < 0)
		return;

	int	interY = graphH / (IPC_RESISTANCE_GRAPH_YPOINTS - 1);	
	int interX = graphW / IPC_RESISTANCE_GRAPH_XPIXEL;			

	CPen penData;
	CPen *pOldPen = NULL;

	penData.CreatePen(PS_SOLID, 1, PALETTERGB(0, 255, 0));
	pOldPen = pDC->SelectObject(&penData);

	LONG maxCount = MaxMeasureCount();

	int inter = ((m_maxScaleX - m_minScaleX) / m_bendingCount) / (interX);	
	if(inter == 0) inter = 1;

	int xValue = IPC_RESISTANCE_GRAPH_XPIXEL / inter;

	if(inter == 1)
		xValue = graphW / ((m_maxScaleX - m_minScaleX) / m_bendingCount);

	int xPoints = graphW / xValue; 

	int measCount = 0;
	int i = 0;

	for(; i < xPoints + 2; i++)
	{
		SResistanceData* pdata = FindResistanceData(maxCount - (i * m_bendingCount));

		if(pdata && !pdata->m_fail)
		{
			float lfValue = pdata->m_lfResist;

			int y = ((m_rcGraph.Height() * (lfValue - m_minScale)) / (float)(m_maxScale - m_minScale)); 
			int x = i * xValue;

			int ypoint = m_rcGraph.bottom - (y + 1);
			int xpoint = m_rcGraph.right - x;

			if(xpoint >= m_rcGraph.left)
				ptResistance[measCount++] = CPoint(xpoint, ypoint);

			if(measCount > IPC_RESISTANCE_MAXPOINTS)
				break;
		}
	}

	pDC->Polyline(ptResistance, measCount);

	pDC->SelectObject(pOldPen);
}

BOOL CResistanceWnd::PreTestResistance(float resist, bool binit)
{
	BOOL	result = S_OK;

	CString	strVal;
	CString strFormat = GetFloatingFormat(resist, 4);
	strVal.Format(strFormat, resist);

	if(binit)
	{
		m_lfInitResist = resist;
		m_stResistance[EN_STATIC_INIT_RESIST] = strVal;

		m_stResistance[EN_STATIC_MEAS_RESIST] = _T("0.0");
		m_stResistance[EN_STATIC_RATE_OF_CHANGE] = _T("0.0");

		float margin = m_failPercent * 0.01;
		m_maxFailMargin = m_lfInitResist + (m_lfInitResist * margin) + 0.00005;
		m_minFailMargin = m_lfInitResist - (m_lfInitResist * margin) + 0.00005;

		float range = margin * 2;
		m_maxScale = m_lfInitResist + (m_lfInitResist * range) + 0.00005;
		m_minScale = m_lfInitResist - (m_lfInitResist * range) + 0.00005;

		m_maxScaleYOrg = m_maxScale;
		m_minScaleYOrg = m_minScale;

		m_bScaleDef = true;
	}
	else
	{
		float m_lfResist = resist;

		float rate = (m_lfResist * 100.0f) / m_lfInitResist;
		rate = (100.0f - rate) * -1.0;

		if(rate > 100.0f || rate < -100.0f)
		{
			if(rate > 0)	rate = 100.0f;
			else			rate = -100.0f;
		}

		if(rate == 100.f || rate == -100.0f)
			m_stResistance[EN_STATIC_MEAS_RESIST] = _T("XXX.XXXX");
		else
			m_stResistance[EN_STATIC_MEAS_RESIST] = strVal;

		CString strFormat = GetFloatingFormat(rate, 2);
		strVal.Format(strFormat, rate);
		m_stResistance[EN_STATIC_RATE_OF_CHANGE] = strVal;


		if(	m_lfResist > m_maxFailMargin || m_lfResist < m_minFailMargin )
		{
			SetFail(true);
			result = S_FALSE;

			CString strFail;
			if(m_materialNum >= 0 && m_materialNum < IPC_MAX_MATERIAL)
			{
				strFail.Format(GetResString(IDS_RESISTANCE_STATIC_6), thePrefs.m_materialName[m_materialNum]);
				m_stFail = strFail;
			}
		}
	}

	CDC*	pDC = GetDC();
	DrawGraphicArea(pDC);
	ReleaseDC(pDC);

	return result;
}

void CResistanceWnd::ChangeZoomScaleY(float from, float to)
{
	m_maxScale = to;
	m_minScale = from;

	CDC*	pDC = GetDC();
	DrawGraphicHistoryArea(pDC);
	ReleaseDC(pDC);

}
void CResistanceWnd::ChangeZoomScaleX(long from, long to)
{
	m_maxScaleX = to / m_bendingCount * m_bendingCount;
	m_minScaleX = from / m_bendingCount * m_bendingCount;

	if((m_maxScaleX - m_minScaleX) == 0)
		m_minScaleX = m_maxScaleX - m_bendingCount;

	CDC*	pDC = GetDC();
	DrawGraphicHistoryArea(pDC);
	ReleaseDC(pDC);

}

void CResistanceWnd::ChangeOrgScaleX()
{
	m_maxScaleX = m_maxScaleXOrg;
	m_minScaleX = m_minScaleXOrg;

	CDC*	pDC = GetDC();
	DrawGraphicHistoryArea(pDC);
	ReleaseDC(pDC);
}

void CResistanceWnd::ChangeOrgScaleY()
{
	m_maxScale = m_maxScaleYOrg;
	m_minScale = m_minScaleYOrg;

	CDC*	pDC = GetDC();
	DrawGraphicHistoryArea(pDC);
	ReleaseDC(pDC);
}

void CResistanceWnd::SetFailMargin(float failmargin)	
{ 
	m_failPercent = failmargin; 
}

void CResistanceWnd::InitResistance(float resist, bool bfailmargin)
{
	m_bFailMargin = bfailmargin;
	PreTestResistance(resist, true);
}

void CResistanceWnd::DrawFailMargin(bool bmargin)
{
	m_bFailMargin = bmargin;

	CDC*	pDC = GetDC();
	DrawGraphicArea(pDC);
	ReleaseDC(pDC);
}

void CResistanceWnd::ClearResistanceData()
{
	RemoveAllDataList();

	m_lfInitResist = 5.0;
	m_minFailMargin = m_maxFailMargin = 0;
	m_bScaleDef = false;
	m_bFail = false;
	m_testCount = 0;
	m_failCount = 0;
	m_bendingCount = 1;

	m_initCount = 0;

	PreTestResistance(0.0f, true);
}

BOOL CResistanceWnd::AddResistanceData(SResistanceData*	pdata)
{
	BOOL result = S_FALSE;
	if(pdata)
	{
		if((pdata->m_count - m_initCount) > 0)
			m_bendingCount = pdata->m_count - m_initCount;

		m_initCount = pdata->m_count;

		if(!m_historyWnd)
		{
			long removeCount = pdata->m_count - (m_bendingCount * (IPC_RESISTANCE_MAXPOINTS + 5));
			if(removeCount > 0)
				RemoveResistanceData(removeCount);
		}

		if(m_bFail)
			pdata->m_fail = 1;
		
		if(m_historyWnd)
		{
			m_maxScaleX = pdata->m_count;

			if(pdata->m_count < m_minScaleX)
				m_minScaleX = pdata->m_count;

			m_maxScaleXOrg = m_maxScaleX;
			m_minScaleXOrg = m_minScaleX;

			m_bXScaleDef = true;
			if((m_maxScaleX - m_minScaleX) == 0)
				m_minScaleX = m_maxScaleX - m_bendingCount;
		}

		result = PreTestResistance(pdata->m_lfResist);
		if(result == S_FALSE)
			pdata->m_fail = 1;

		pair< map<long, SResistanceData*>::iterator, bool > pr;
		pr = m_datalist.insert(RESISTANCEDATA_MAP::value_type(pdata->m_count, pdata));
		if(pr.second != true)
		{
			SResistanceData* pdd = FindResistanceData(pdata->m_count);
			if(pdd)
			{
				CopyMemory(pdd, pdata, sizeof(SResistanceData));
				delete pdata;
			}
		}
	}
	return result;
}

void CResistanceWnd::RemoveAllDataList()
{
	RESISTANCEDATA_MAP::iterator iter;
	SResistanceData*	pdata = NULL;
	::EnterCriticalSection(&m_cs);
	for (iter = m_datalist.begin(); iter != m_datalist.end(); iter++)
	{
		pdata = (SResistanceData*)(*iter).second;
		delete pdata;
	}
	m_datalist.clear();
	::LeaveCriticalSection(&m_cs);
}

SResistanceData* CResistanceWnd::FindResistanceData(int count)
{
	RESISTANCEDATA_MAP::iterator iter;
	SResistanceData* pdata = NULL;

	::EnterCriticalSection(&m_cs);
	if(m_datalist.size())
	{
		iter = m_datalist.find(count);
		if (iter != m_datalist.end())	
			pdata = (SResistanceData*) (*iter).second;
	}
	::LeaveCriticalSection(&m_cs);

	return pdata;
}

void CResistanceWnd::RemoveResistanceData(int count)
{
	RESISTANCEDATA_MAP::iterator iter;
	SResistanceData* pdata = NULL;

	::EnterCriticalSection(&m_cs);
	if(m_datalist.size())
	{
		iter = m_datalist.find(count);
		if (iter != m_datalist.end())	
		{
			pdata = (SResistanceData*) (*iter).second;
			delete pdata;
			m_datalist.erase(iter);
		}
	}
	::LeaveCriticalSection(&m_cs);
}

long CResistanceWnd::MaxMeasureCount()
{
	return m_maxScaleX;
}

long CResistanceWnd::MinMeasureCount()
{
	return m_minScaleX;
}

BEGIN_MESSAGE_MAP(CResistanceWnd, CWnd)

	ON_MESSAGE(UM_IPC_MEAS_DISPLAY,		OnBFTestDraw)

	ON_WM_PAINT()
	ON_WM_CLOSE()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CResistanceWnd �޽��� ó�����Դϴ�.
int CResistanceWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  ���⿡ Ư��ȭ�� �ۼ� �ڵ带 �߰��մϴ�.
	InitControl();

	Localize();
	LocalizeFont();

	SetPosition();

	UpdateWindow();
	return 0;
}


void CResistanceWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CWnd::OnPaint()��(��) ȣ������ ���ʽÿ�.

	CDC*	pDC = GetDC();
	DrawGraphicArea(pDC);
	ReleaseDC(pDC);
}

void CResistanceWnd::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CWnd::OnClose();
}

void CResistanceWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	SetPosition();
}


HRESULT CResistanceWnd::OnBFTestDraw(WPARAM wParam, LPARAM lParam)
{
	m_testCount = (long)lParam;

	CDC*	pDC = GetDC();
	DrawGraphicArea(pDC);
	ReleaseDC(pDC);

	return S_OK;
}


BOOL CResistanceWnd::DestroyWindow()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	return CWnd::DestroyWindow();
}

BOOL CResistanceWnd::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CBrush backBrush(m_clrBack);
	CBrush* pOldBrush = pDC->SelectObject(&backBrush);

	CRect rect;
	pDC->GetClipBox(&rect);     // Erase the area needed

	pDC->ExcludeClipRect(m_rcGraph);

	pDC->SelectObject(&backBrush);
	pDC->PatBlt(rect.left, rect.top, 
				rect.Width(), rect.Height(),
				PATCOPY);

	pDC->SelectObject(pOldBrush);

	return TRUE;
//	return CWnd::OnEraseBkgnd(pDC);
}

HBRUSH CResistanceWnd::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CWnd::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ���⼭ DC�� Ư���� �����մϴ�.
	if(nCtlColor == IDC_RESISTANCE_SCALE_Y)
	{
		pDC->SetTextColor(m_clrScale[0]);
		pDC->SetBkColor(m_clrBack);
		pDC->SetBkMode(OPAQUE);
		return (HBRUSH)GetStockObject(NULL_BRUSH);
	}

	// TODO:  �⺻���� �������� ������ �ٸ� �귯�ø� ��ȯ�մϴ�.
	return hbr;
}
