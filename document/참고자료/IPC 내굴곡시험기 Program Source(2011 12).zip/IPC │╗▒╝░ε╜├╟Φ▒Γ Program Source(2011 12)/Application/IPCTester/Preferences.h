#pragma once

class CPreferences
{
public:
	CPreferences(void);
	virtual ~CPreferences(void);

	void	Init();									
	void	Uninit();								
	void	CreateFont();							

	uint16	GetPortRMI()					{ return m_portRMI; }		
	uint16	GetPortACCT()					{ return m_portACCT; }		

	int		GetBaudRateRMI()				{ return m_baudRateRMI; }
	int		GetBaudRateACCT()				{ return m_baudRateACCT; }
	uint16	GetDataBits()					{ return m_dataBits; }
	uint16	GetStopBits()					{ return m_stopBits; }
	uint16	GetParity()						{ return m_parity; }

	CString& GetAppDir()					{ return m_appDir; }
	CString& GetConfigDir()					{ return m_configDir; }
	CString& GetLogDir()					{ return m_logDir; }
	CString& GetFileDir()					{ return m_folderPath; }
	void	 SetFileDir(CString dir)		{ m_folderPath = dir; }
	LPLOGFONT GetTextLogFont()				{ return &m_lfText; }

	void	ClearTestCurrentCount()			{ m_TestCurrentCount = 0; }

	LONG	GetTestTotalCount()				{ return m_TestTotalCount; }		
	LONG	GetTestCurrentCount()			{ return m_TestCurrentCount; }		
	LONG	IncreaseTestCount()		
	{ 
			m_TestTotalCount += m_bendingSpeed * m_interval;	
			m_TestCurrentCount += m_bendingSpeed * m_interval;	

			Save(); 
			return m_TestCurrentCount;
	}		

	// Text CFont 
	CFont*	GetIPCFont()					{ return &m_fontText; }
	CFont*	GetGUIDefault()					{ return &m_fontDefault; }
	CFont*	GetGUIDefaultBold()				{ return &m_fontDefaultBold; }

	bool	Save();									


	static	LPCTSTR GetConfigFile();

	void	SetTestTotalCount(LONG count)	{ ::InterlockedExchange(&m_TestTotalCount, count); }

protected:
	void LoadPreferences();
	void SavePreferences();


public:
	float	m_temp;					
	uint16	m_allowable;			
	bool	m_bAutoStart;			

	uint16	m_bendingSpeed;			
	uint16	m_amplitude;
	float	m_failPercent;	
	float	m_interval;				
	LONG	m_stopCount;			
	bool	m_bUsed;				

	bool	m_materialInfo[4];		
	CString m_materialName[4];		

	CString	m_folderPath;			
	CString	m_fileName;				

	float	m_preTest[4];			
	float	m_bftTemp;				

	LONG	m_TestTotalCount;		
	LONG	m_TestCurrentCount;		

protected:
	CString m_appDir;
	CString m_configDir;
	CString m_logDir;
	CString m_fileDir;

	uint16	m_portRMI;				
	uint16	m_portACCT;				

	int		m_baudRateRMI;
	int		m_baudRateACCT;
	uint16	m_dataBits;
	uint16	m_stopBits;
	uint16	m_parity;

	LOGFONT m_lfText;		
	CFont	m_fontText;		
	CFont	m_fontDefault;
	CFont	m_fontDefaultBold;

};

extern CPreferences	thePrefs;
