#pragma once

enum	IPC_RESMAN_INDEX
{
	IPC_RESMAN_SYSICON_SMALL = 0,		
	IPC_RESMAN_SYSICON_LARGE,			

	IPC_RESMAN_IPC_LOGO,				
	IPC_RESMAN_IPC_CONFIGLOGO,			
	IPC_RESMAN_IPC_COMPANYLOGO,			

	IPC_RESMAN_CONFIG_TITLE,			

	IPC_RESMAN_BTN_DEFAULT,				

	IPC_RESMAN_BTN_OK,					
	IPC_RESMAN_BTN_CANCEL,				
	IPC_RESMAN_BTN_APPLYNOW,			

	IPC_RESMAN_BTN_TEST_RESTART,		
	IPC_RESMAN_BTN_TEST_PAUSE,			
	IPC_RESMAN_BTN_TEST_START,			
	IPC_RESMAN_BTN_TEST_STOP,			
	IPC_RESMAN_BTN_TEST_HISTORY,		
	IPC_RESMAN_BTN_PREFERENCE,			
	IPC_RESMAN_BTN_EXIT,				
	
	IPC_RESMAN_BTN_AUTOSTART,			
	IPC_RESMAN_BTN_NOTSTART,			
	IPC_RESMAN_BTN_MEASURE,				
	IPC_RESMAN_BTN_SELECT_FOLDER,		
	IPC_RESMAN_BTN_CONTINUE,			

	IPC_RESMAN_BTN_TEST_CANCEL,			
	IPC_RESMAN_BTN_ZOOMIN,				
	IPC_RESMAN_BTN_ZOOMOUT,				
	IPC_RESMAN_BTN_ZOOMINOUT,			
	IPC_RESMAN_BTN_ZOOMORG,				
	IPC_RESMAN_BTN_REPORT,				

	IPC_RESMAN_MAIN_LOGO,				

	IPC_RESMAN_COUNT_BG,				
	IPC_RESMAN_SATATUS_FAIL,			
	IPC_RESMAN_SATATUS_RESIZE,			

	IPC_RESMAN_WINDOW_CLOSE,			
	IPC_RESMAN_WINDOW_MAX,				
	IPC_RESMAN_WINDOW_MIN,				


	IPC_RESMAN_MAX
};

class CResManager
{
public:
	CResManager(void);
	virtual ~CResManager(void);

	enum	{	EN_COUNT_BG = 0,
				EN_COUNT_LINE,
				EN_BACKGROUND_MAX
			};
public:
	void			Init();
	void			UnInit();
	void			Localize();
	void			InitResManager();

	CImageList		*GetImageListRes(int nImageListIdx)		{ return &m_imglResManager[nImageListIdx]; }
	CBitmap			*GetBitmapMenuTitle()					{ return &m_bmpMenuTitle; }
	CBitmap			*GetBitmapTitlebar()					{ return &m_bmpTitlebar; }

	CBitmap			*GetBitmapBG(int nIdx)					{ return &m_bmpBG[ nIdx ]; }

	HIMAGELIST		GetSysImageList( BOOL bSmall = FALSE );

protected:
	COLORREF		m_clrMask; 

	CImageList		m_imglResManager[IPC_RESMAN_MAX];
	CBitmap			m_bmpMenuTitle;						
	CBitmap			m_bmpTitlebar;						

	CBitmap			m_bmpBG[EN_BACKGROUND_MAX];			
};

extern CResManager	theResMan;
