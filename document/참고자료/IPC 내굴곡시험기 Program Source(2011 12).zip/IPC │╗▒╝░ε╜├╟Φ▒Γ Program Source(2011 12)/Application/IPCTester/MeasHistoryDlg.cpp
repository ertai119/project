// MeasHistoryDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "MeasHistoryDlg.h"

#include "MeasReportDlg.h"
#include "FileManager.h"

// CMeasHistoryDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CMeasHistoryDlg, CDialog)

CMeasHistoryDlg::CMeasHistoryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMeasHistoryDlg::IDD, pParent)
{
	m_clrBack		= IPC_BACKGROUND_COLOR;	
	m_clrText		= PALETTERGB(0,0,0);			// BLACK
	m_clrBlue		= PALETTERGB(0, 0, 255);		// BLUE
	m_clrOutline	= PALETTERGB( 194, 193, 193);
	m_clrMask		= PALETTERGB(255,0,255);		// PINK

	m_bFail = TRUE;
	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		m_pResistanceWnd[i] = NULL;

	for(int i = 0; i < EN_EDIT_MAX; i++)
		m_zoomScale[i] = 0;
}

CMeasHistoryDlg::~CMeasHistoryDlg()
{
	RemoveAllFileList();
	m_titleFont.DeleteObject();
}

void CMeasHistoryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_HISTORY1, m_stGroup);

	for(int i = EN_EDIT_FROMY; i < EN_EDIT_MAX; i++)
	{
		DDX_Control(pDX, IDC_HISTORY_EDIT_FROMY + i, m_editHistory[i]);
		DDX_Control(pDX, IDC_HISTORY_SPIN_FROMY + i, m_spinHistory[i]);
	}
	for(int i = EN_EDIT_FROMY; i < EN_EDIT_MAX; i++)
		DDX_Text(pDX, IDC_HISTORY_EDIT_FROMY + i, m_zoomScale[i]);

	for(int i = 0; i < 2; i++)
		DDV_MinMaxUInt(pDX, m_zoomScale[EN_EDIT_FROMY + i], 0, 1000);
	for(int i = 0; i < 2; i++)
		DDV_MinMaxUInt(pDX, m_zoomScale[EN_EDIT_FROMX + i], 0, IPC_MAX_BFTEST_LIMIT);
}

void CMeasHistoryDlg::RemoveAllFileList()
{
	BFTFILE_MAP::iterator iter;
	SBFTFileData*	pdata = NULL;
	for (iter = m_BFTList.begin(); iter != m_BFTList.end(); iter++)
	{
		pdata = (SBFTFileData*)(*iter).second;
		if(pdata)
			delete pdata;
	}
	m_BFTList.clear();
}


void CMeasHistoryDlg::Localize()
{

	for (int i = 0; i <= EN_STATIC_TO_Y; i++)
		m_stStatic[i].SetCaption(GetResString(IDS_HISTORY_STATIC_1 + i));

	m_stStatic[EN_STATIC_FROM_X].SetCaption(GetResString(IDS_HISTORY_STATIC_FROM));
	m_stStatic[EN_STATIC_TO_X].SetCaption(GetResString(IDS_HISTORY_STATIC_TO));

	CButton* pRadio = (CButton*)GetDlgItem((m_bFail)? IDC_RADIO_FAILON : IDC_RADIO_FAILOFF);
	if(pRadio)
		pRadio->SetCheck(1);

}

void CMeasHistoryDlg::LocalizeFont()
{
	CFont *pFont = thePrefs.GetGUIDefault();
	CFont*	m_fontBold = thePrefs.GetGUIDefaultBold();

	// Set Font for CheckBox
	/////////////////////////////////////
	CDC *pDC = GetDC();

	LOGFONT lf;
	memset (&lf, 0, sizeof (LOGFONT));
	_tcscpy (lf.lfFaceName, _T("Dotum"));
	lf.lfWeight = FW_BOLD;
	lf.lfHeight = -::MulDiv(11, ::GetDeviceCaps(pDC->m_hDC, LOGPIXELSY), 72);
	m_titleFont.CreateFontIndirect(&lf);

	ReleaseDC(pDC);

	// Set Font Info to EditBox 
	for(int  i= 0; i < EN_EDIT_MAX; i++)
		m_editHistory[i].SetFont(pFont);		

	for (int i = 0; i < EN_STATIC_MAX; i++)
	{
		if(i < EN_STATIC_FROM_Y)
			m_stStatic[i].SetFont(&m_titleFont);
		else
			m_stStatic[i].SetFont(pFont);
	}
}

void CMeasHistoryDlg:: InitControl()
{
	CRect	rcTemp(0,0,0,0);

	CImageList*	pImageList = NULL;
	for (int i = 0; i < EN_BTN_MAX; i++)
	{
		if(i <= EN_BTN_ZOOMORG_X)
			pImageList = theResMan.GetImageListRes(IPC_RESMAN_BTN_ZOOMINOUT + (i % 2));
		else
			pImageList = theResMan.GetImageListRes(IPC_RESMAN_BTN_REPORT);

		IMAGEINFO	imgInfo;
		CRect	rcRect;
		pImageList->GetImageInfo(1, &imgInfo);
		rcRect = imgInfo.rcImage;

		m_btnHistory[i].SetImageList(pImageList, 0);
		m_btnHistory[i].Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
							rcRect, this, IDC_CONFIG_BTN_ZOOMIN_Y + i);
		m_btnHistory[i].SetTransparent();
	}

	short pwidth = 70;
	for (int i = 0; i < EN_STATIC_MAX; i++)
	{
		m_stStatic[i].Create(NULL, WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, 
							CRect(0, 0, pwidth, 20), this, IDC_HISTORY_STATIC_SCALEY + i);
		m_stStatic[i].SetAlign(DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		if(i < EN_STATIC_FROM_Y)
			m_stStatic[i].SetFontColor( m_clrBlue );
		else
			m_stStatic[i].SetFontColor( m_clrText );

		m_stStatic[i].SetCaption( _T("") );
	}
}

void CMeasHistoryDlg::InitHistory()
{
	BOOL ret;

	for(int i = 0; i < 2; i++)
		m_spinHistory[EN_EDIT_FROMY + i].SetRange32(0, 1000);
	for(int i = 0; i < 2; i++)
		m_spinHistory[EN_EDIT_FROMX + i].SetRange32(0, IPC_MAX_BFTEST_LIMIT);

	ret = LoadHeader();
	ret = LoadResistanceData();
}

BOOL CMeasHistoryDlg::LoadHeader()
{
	CFileManager*	pManager = (CFileManager*)theApp.m_pFileManager;
	TCHAR	buffer[256];
	if(pManager)
	{
		{
			if(pManager->ReadLine((LPTSTR)m_strFilePath.GetString(), 
									buffer, 
									IPC_HISTORY_PRETEST_NAMELINE) != S_OK)
				return FALSE;

			LPTSTR	pBuffer = buffer;
			LPTSTR	pos = NULL;

			pos = _tcschr(pBuffer, _T(','));
			if(pos)
			{
				*pos = NULL;
				pBuffer = pos + 1;
			}

			for(int i = 0; i < IPC_MAX_MATERIAL; i++)
			{
				TCHAR	sdata[256];
				pos = _tcschr(pBuffer, _T(','));
				if(pos)
				{
					*pos = NULL;
					strcpy(sdata, pBuffer);

					lstrcpy(m_resultData[i].strName, sdata);

					pBuffer = pos + 1;
				}
				else
				{
					if(strlen(pBuffer))
					{
						CString strData = pBuffer;
						strData = strData.Trim(_T("\r\n"));
						lstrcpy(m_resultData[i].strName, strData);
					}
				}
			}
		}

		float	lfFailMargin = 0.0f;
		{
			if(pManager->ReadLine((LPTSTR)m_strFilePath.GetString(), 
									buffer, 
									IPC_HISTORY_FAILMARGIN_DATALINE) != S_OK)
				return FALSE;
			
			LPTSTR	pBuffer = buffer;
			LPTSTR pos = _tcsrchr(pBuffer, _T(' '));
			if(pos)
			{
				TCHAR	sdata[256];
				strcpy(sdata, pos + 1);
				lfFailMargin = atof(sdata);
			}
			else
				return FALSE;
		}

		{
			if(pManager->ReadLine((LPTSTR)m_strFilePath.GetString(), 
									buffer, 
									IPC_HISTORY_PRETEST_DATALINE) != S_OK)
				return FALSE;

			LPTSTR	pBuffer = buffer;
			LPTSTR	pos = NULL;

			pos = _tcschr(pBuffer, _T(','));
			if(pos)
			{
				*pos = NULL;
				pBuffer = pos + 1;
			}

			for(int i = 0; i < IPC_MAX_MATERIAL; i++)
			{
				pos = _tcschr(pBuffer, _T(','));

				TCHAR	sdata[256];
				if(pos)
				{
					*pos = NULL;
					strcpy(sdata, pBuffer);

					float lfResist = atof(sdata);

					m_pResistanceWnd[i]->SetFailMargin(lfFailMargin);
					m_pResistanceWnd[i]->InitResistance(lfResist, true);

					m_resultData[i].failMargin = lfFailMargin;
					m_resultData[i].lfResist = lfResist;

					pBuffer = pos + 1;
				}
				else
				{
					if(strlen(pBuffer))
					{
						CString strData = pBuffer;
						strData = strData.Trim(_T("\r\n"));
						float lfResist = atof(strData);

						m_pResistanceWnd[i]->SetFailMargin(lfFailMargin);
						m_pResistanceWnd[i]->InitResistance(lfResist, true);

						m_resultData[i].failMargin = lfFailMargin;
						m_resultData[i].lfResist = lfResist;

					}
				}
			}
		}
	}

	return TRUE;
}

BOOL CMeasHistoryDlg::LoadResistanceData()
{
	CFileManager*	pManager = (CFileManager*)theApp.m_pFileManager;
	TCHAR	buffer[1024];
	if(pManager)
	{
		int line = 0;
		while(true)
		{
			if(pManager->ReadLine((LPTSTR)m_strFilePath.GetString(), 
									buffer, 
									IPC_HISTORY_MEASURE_DATALINE + line) != S_OK)
				return FALSE;

			char	sDate[20];
			long	bftCount = 0;
			float	lfResist[IPC_MAX_MATERIAL];
			float	lfTemp = 0.0;
			short	bFail[IPC_MAX_MATERIAL];

			for(int i = 0; i < IPC_MAX_MATERIAL; i++)
			{
				lfResist[i] = 0.0;
				bFail[i] = 0;
			}

			LPTSTR	pBuffer = buffer;
			LPTSTR pos = NULL;
			bool	error = 0;
			int i = 0;

			for(; i < FILE_HISTORY_MAX; i++)
			{
				if(i == FILE_HISTORY_FAIL)
					pos = _tcsrchr(pBuffer, _T(','));
				else
					pos = _tcschr(pBuffer, _T(','));

				TCHAR	sdata[256];
				if(pos)
				{
					if(i == FILE_HISTORY_FAIL)
					{
						lstrcpyn(sdata, pBuffer, pos - pBuffer + 1);

						lfTemp = atof(pos + 1);
					}
					else
					{
						*pos = NULL;
						strcpy(sdata, pBuffer);
					}

					switch(i)
					{
						case FILE_HISTORY_DATE :
							strcpy(sDate, sdata);
							break;

						case FILE_HISTORY_COUNT :
							bftCount = atoi(sdata);
							break;

						case FILE_HISTORY_RESIST1 :
						case FILE_HISTORY_RESIST2 :
						case FILE_HISTORY_RESIST3 :
						case FILE_HISTORY_RESIST4 :
							lfResist[i - FILE_HISTORY_RESIST1] = atof(sdata);
							break;

						case FILE_HISTORY_FAIL :
						{
							CString strFail = sdata;
							strFail = strFail.Trim(_T("\""));

							if(strFail.GetLength())
							{
								strFail.Replace(_T("Fail"), _T(""));

								LPTSTR pp = strFail.GetBuffer();
								LPTSTR mt = _tcschr(pp, _T(','));
								if(mt)
								{
									*mt = NULL;
									short idx = atoi(pp);
									if(idx <= 4)
										bFail[idx - 1] = 1;

									pp = mt + 1;
									while(mt = _tcschr(pp, _T(',')) )
									{
										*mt = NULL;
										short idx = atoi(pp);
										if(idx <= 4)
											bFail[idx - 1] = 1;
										pp = mt + 1;
									}

								}
								short idx = atoi(pp);
								if(idx <= 4)
									bFail[idx - 1] = 1;
							}
						}
						case FILE_HISTORY_TEMP :
							i++;		
							break;
	
						default :
							break;
					}

					pBuffer = pos + 1;
				}
			}

			if(i == FILE_HISTORY_MAX && error == 0)
			{
				SBFTFileData*	pRecord = new SBFTFileData;
				if(pRecord)
				{
					for(int mt = 0; mt < IPC_MAX_MATERIAL; mt++)
					{
						SResistanceData*	pdata = new SResistanceData;
						if(pdata)
						{
							pdata->m_count = bftCount;
							pdata->m_fail = bFail[mt];
							pdata->m_lfResist = lfResist[mt];
							pdata->m_material = mt + 1;

							m_pResistanceWnd[mt]->AddResistanceData(pdata);
							pRecord->AddResistData(pdata);
						}

						if(bFail[mt])
							m_resultData[mt].failCount += 1;		
						m_resultData[mt].totalCount = bftCount;
					}

					pRecord->lfTemp = lfTemp;				
					pRecord->testTotalCount = bftCount;		

					pair< map<long, SBFTFileData*>::iterator, bool > pr;
					pr = m_BFTList.insert(BFTFILE_MAP::value_type(bftCount, pRecord));
					if(pr.second != true)
						delete pRecord;
				}
				///////////////////////////////////////////////
			}
			else
			{
				theApp.IPCMessageBox(_T("���� ������ ��ġ���� �ʽ��ϴ�!!!"),
									GetResString(IDS_IPC_CAPTION),
									MB_OK | MB_ICONINFORMATION);
				return FALSE;
			}

			line++;		// line ����
		}

	}

	return TRUE;
}

void CMeasHistoryDlg::SetPosition()
{
	CRect	rcClient;
	GetClientRect(&rcClient);

	if (m_editHistory[0].m_hWnd	&& m_stStatic[0].m_hWnd && 
		m_btnHistory[0].m_hWnd && m_stGroup.m_hWnd)
	{
		int nCtrlTop = rcClient.bottom - (IPC_HISTORY_CONTROL_HEIGHT + IPC_HISTORY_BOTTOM);

		int nCtrlWidth = 100;
		int	nCtrlHeight = 20;
		int	nCtrlIntv = 10, nLineIntv = 9, nOffSet = 10;

		CRect	rcTemp(0,0,0,0);

		// Set Group Pos
		/////////////////////////////////////////////////////
		//rcTemp.left		= IPC_HISTORY_CONTROL_STARTX;
		rcTemp.left		= IPC_HISTORY_LEFT;
		rcTemp.right	= rcClient.right - IPC_HISTORY_LEFT;
		rcTemp.top		= rcClient.bottom - (IPC_HISTORY_BOTTOM + IPC_HISTORY_CONTROL_HEIGHT);
		rcTemp.bottom	= rcTemp.top + IPC_HISTORY_CONTROL_HEIGHT;

		m_stGroup.MoveWindow(rcTemp.left, rcTemp.top, rcTemp.Width(), rcTemp.Height());
		m_stGroup.Invalidate(FALSE);
		m_stGroup.ShowWindow(SW_SHOW);

		CRect	rcGroup = rcTemp;

		int nInterval = rcGroup.Width() / 3 + 20;

		// Set Static Pos
		/////////////////////////////////////////////////////
		int nLeft		= rcGroup.left + IPC_HISTORY_LEFT;
		for(int i = 0; i <= EN_STATIC_FAIL; i++)
		{
			rcTemp.left		= nLeft + (i * nInterval);

			if(i == EN_STATIC_FAIL)
			{
				rcTemp.left		+= 40;
				rcTemp.right	= rcTemp.left + 70 + 5;
			}
			else
				rcTemp.right	= rcTemp.left + nCtrlWidth + 5;

			rcTemp.top		= rcGroup.top + (IPC_HISTORY_CONTROL_HEIGHT - nCtrlHeight) / 2;
			rcTemp.bottom	= rcTemp.top + nCtrlHeight;

			m_stStatic[i].MoveWindow(&rcTemp, FALSE);
			m_stStatic[i].Invalidate();
			m_stStatic[i].ShowWindow(SW_SHOW);

			rcTemp.left	= rcTemp.right + nCtrlIntv;
			rcTemp.right = rcTemp.left + 30;

			if(i == EN_STATIC_FAIL)
			{
				rcTemp.top = rcGroup.top + nLineIntv * 2;
				rcTemp.bottom = rcTemp.top + nCtrlHeight;

				// Radio Button (FailOn, FailOff)
				for(int j = 0; j < 2; j++)
				{
					CButton*	pCtrl = (CButton*)GetDlgItem(IDC_RADIO_FAILON + j);
					if(pCtrl && pCtrl->m_hWnd)
					{
						CRect rcCtrl;
						pCtrl->GetClientRect(&rcCtrl);

						pCtrl->MoveWindow(rcTemp.left, rcTemp.top, 
										  rcCtrl.Width(), rcCtrl.Height(), FALSE);
						pCtrl->Invalidate();

						rcTemp.top += rcCtrl.Height() + nLineIntv + 3;
					}
				}

				// Report Button Position
				rcTemp.top = rcGroup.top + nLineIntv + 5;
				int nStart = rcTemp.right - 20;

				CRect	rcBtn;
				m_btnHistory[EN_BTN_REPORT].GetClientRect(&rcBtn);

				rcTemp.left = nStart + rcBtn.Width();
				rcTemp.right = rcTemp.left + rcBtn.Width();
				rcTemp.bottom = rcTemp.top + rcBtn.Height();

				m_btnHistory[EN_BTN_REPORT].MoveWindow(&rcTemp, FALSE);
				m_btnHistory[EN_BTN_REPORT].Invalidate();
				m_btnHistory[EN_BTN_REPORT].ShowWindow(SW_SHOW);
			}
			else
			{
				// From Pos
				////////////////////////////////////////////
				rcTemp.top = rcGroup.top + nLineIntv + 5;
				rcTemp.bottom = rcTemp.top + nCtrlHeight;

				m_stStatic[EN_STATIC_FROM_Y + (i * 2)].MoveWindow(&rcTemp, FALSE);
				m_stStatic[EN_STATIC_FROM_Y + (i * 2)].Invalidate();
				m_stStatic[EN_STATIC_FROM_Y + (i * 2)].ShowWindow(SW_SHOW);
		
				// Set Edit Position
				CWnd *pBuddy;
				CRect	rcEdit1 = rcTemp;
				rcEdit1.left = rcTemp.right + 5;

				if(i == EN_STATIC_ZOOM_X)
					rcEdit1.right = rcTemp.left + nCtrlWidth + 30;
				else	// ZOOM_Y
					rcEdit1.right = rcTemp.left + nCtrlWidth;

				m_editHistory[EN_EDIT_FROMY + (i * 2)].MoveWindow(&rcEdit1, FALSE);
				pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcEdit1.left + 1, rcEdit1.top + 1), CWP_SKIPINVISIBLE);
				m_spinHistory[EN_EDIT_FROMY + (i * 2)].SetBuddy(pBuddy);

				// To Position
				//////////////////////////////////////////
				rcTemp.top = rcTemp.bottom + 5;
				rcTemp.bottom = rcTemp.top + nCtrlHeight;

				m_stStatic[EN_STATIC_TO_Y + (i * 2)].MoveWindow(&rcTemp, FALSE);
				m_stStatic[EN_STATIC_TO_Y + (i * 2)].Invalidate();
				m_stStatic[EN_STATIC_TO_Y + (i * 2)].ShowWindow(SW_SHOW);
			
				// Set Edit Position
				CRect	rcEdit2 = rcTemp;
				rcEdit2.left = rcTemp.right + 5;

				if(i == EN_STATIC_ZOOM_X)
					rcEdit2.right = rcTemp.left + nCtrlWidth + 30;
				else	// ZOOM_Y
					rcEdit2.right = rcTemp.left + nCtrlWidth;

				m_editHistory[EN_EDIT_TOY + (i * 2)].MoveWindow(&rcEdit2, FALSE);
				pBuddy = (CWnd *)ChildWindowFromPoint(CPoint(rcEdit2.left + 1, rcEdit2.top + 1), CWP_SKIPINVISIBLE);
				m_spinHistory[EN_EDIT_TOY + (i * 2)].SetBuddy(pBuddy);

				rcTemp.top = rcGroup.top + nLineIntv + 5;
				int nStart = rcEdit2.right + 5;
				for(int j = 0; j < 2; j++)
				{
					CRect	rcBtn;
					m_btnHistory[EN_BTN_ZOOMIN_Y + (i * 2) + j].GetClientRect(&rcBtn);

					rcTemp.left = nStart + (j * (rcBtn.Width() + 3));
					rcTemp.right = rcTemp.left + rcBtn.Width();
					rcTemp.bottom = rcTemp.top + rcBtn.Height();

					m_btnHistory[EN_BTN_ZOOMIN_Y + (i * 2) + j].MoveWindow(&rcTemp, FALSE);
					m_btnHistory[EN_BTN_ZOOMIN_Y + (i * 2) + j].Invalidate();
					m_btnHistory[EN_BTN_ZOOMIN_Y + (i * 2) + j].ShowWindow(SW_SHOW);
				}
			}
		}
	}
}

void CMeasHistoryDlg::SetResistanceWndPosition()
{
	CRect	rcClient;
	GetClientRect( &rcClient );

	if (m_stGroup.m_hWnd)
	{
		CRect	rcGroup;
		m_stGroup.GetWindowRect(&rcGroup);
		ScreenToClient(&rcGroup);

		CRect	rcMeas = rcClient;
		rcMeas.left = IPC_HISTORY_LEFT;
		rcMeas.top = IPC_HISTORY_TOP;
		rcMeas.right = rcClient.right - IPC_HISTORY_LEFT;
		rcMeas.bottom = rcGroup.top - IPC_HISTORY_BOTTOM;

		int m_height = rcMeas.Height() / 4;
		short ntop = rcMeas.Height() % 4;

		rcResist = rcMeas;

		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			rcResist.bottom = rcResist.top + m_height;
			// ntop ���� ������ �� ������ Graphc �� ���Ѵ�.
			if(i == (IPC_MAX_MATERIAL - 1))
				rcResist.bottom += ntop;

			if (m_pResistanceWnd[i] && m_pResistanceWnd[i]->m_hWnd != NULL)
			{
				m_pResistanceWnd[i]->MoveWindow(&rcResist, FALSE);
				m_pResistanceWnd[i]->Invalidate();
				m_pResistanceWnd[i]->ShowWindow(SW_SHOW);

			}
			rcResist.top += m_height;
		}
	}
}

void CMeasHistoryDlg::DrawDialogArea( CDC *pDC )
{
	CRect rcClient;
	GetClientRect(&rcClient);

	// BackGround Color �� (Main Window Left, Right, Bottom ������ ä���
	CRect rcTemp(0, 0, 0, 0);

	CBrush brBack(m_clrBack), *pOldBrush;
	pOldBrush = pDC->SelectObject(&brBack);

	// Top Area
	rcTemp.SetRect( rcClient.left, rcClient.top, rcClient.right, IPC_HISTORY_TOP );	
	pDC->FillRect(rcTemp, &brBack);
	// Left Area
	rcTemp.SetRect( rcClient.left, rcClient.top, rcClient.left + IPC_HISTORY_LEFT, rcClient.bottom );	
	pDC->FillRect(rcTemp, &brBack);
	// Right Area
	rcTemp.SetRect( rcClient.right - IPC_HISTORY_LEFT, rcClient.top, rcClient.right, rcClient.bottom );
	pDC->FillRect(rcTemp, &brBack);
	// Bottom Area
	rcTemp.SetRect( rcClient.left, rcClient.bottom - IPC_HISTORY_BOTTOM, rcClient.right, rcClient.bottom );
	pDC->FillRect(rcTemp, &brBack);
	// Bottom Area2
	rcTemp.SetRect( rcClient.left, rcResist.bottom, rcClient.right, rcResist.bottom + IPC_HISTORY_BOTTOM );
	pDC->FillRect(rcTemp, &brBack);

	pDC->SelectObject(pOldBrush);
}

BEGIN_MESSAGE_MAP(CMeasHistoryDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_CLOSE()
	ON_WM_SIZE()

	ON_CONTROL_RANGE(BN_CLICKED, IDC_RADIO_FAILON, IDC_RADIO_FAILOFF, OnBnClickedFail)
	ON_CONTROL_RANGE(BN_CLICKED, IDC_CONFIG_BTN_ZOOMIN_Y, IDC_CONFIG_BTN_REPORT, OnBnClickedCommand)

	ON_WM_ERASEBKGND()
	ON_WM_SIZING()

	ON_NOTIFY(UDN_DELTAPOS, IDC_HISTORY_SPIN_FROMX, OnDeltaposSpinFromX)
	ON_NOTIFY(UDN_DELTAPOS, IDC_HISTORY_SPIN_TOX,	OnDeltaposSpinToX)

END_MESSAGE_MAP()


// CMeasHistoryDlg �޽��� ó�����Դϴ�.

BOOL CMeasHistoryDlg::OnInitDialog()
{
	/*
	 *	Create Preference Controls & Set Properties	
	 *  Note: DDX/DDV�� �����Ǳ� ���� User Created Control�� �����Ѵ�.
	 */
	InitControl();

	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	CRect rcIpc;

	INT screenX = GetSystemMetrics(SM_CXSCREEN);
	INT screenY = GetSystemMetrics(SM_CYSCREEN);
	
	rcIpc.top = ( screenY - IPC_MAIN_MAX_HEIGHT ) / 2;
	rcIpc.left = ( screenX - IPC_MAIN_MAX_WIDTH ) / 2;
	rcIpc.bottom = rcIpc.top + IPC_MAIN_MAX_HEIGHT;
	rcIpc.right = rcIpc.left + IPC_MAIN_MAX_WIDTH;

	SetWindowPos(NULL, rcIpc.left, rcIpc.top, rcIpc.Width(), rcIpc.Height(), SWP_HIDEWINDOW);

	LocalizeFont();		//Initialize Font Info
	Localize();			//Initialize Control Captions

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
	{
		m_pResistanceWnd[i] = new CResistanceWnd;
		m_pResistanceWnd[i]->SetHistoryWindow();
		m_pResistanceWnd[i]->SetMaterialNum(i);		// zero base
		m_pResistanceWnd[i]->Create(NULL, NULL, WS_CHILD | WS_VISIBLE, CRect(0, 0, 0, 0), this, ID_IPC_WINDOW_RESISTANCE);
	}

	UpdateWindow();

	InitHistory();		//Set Initial Value

	SetPosition();
	SetResistanceWndPosition();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CMeasHistoryDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialog::OnPaint()��(��) ȣ������ ���ʽÿ�.
	DrawDialogArea(&dc);
}

void CMeasHistoryDlg::OnClose()
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		if(m_pResistanceWnd[i])	delete m_pResistanceWnd[i];

	CDialog::OnClose();
}

void CMeasHistoryDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	SetPosition();
	SetResistanceWndPosition();

	CDC* pDC = GetDC();
	DrawDialogArea(pDC);
	ReleaseDC(pDC);
}

void CMeasHistoryDlg::OnDeltaposSpinFromX(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	pNMUpDown->iDelta = pNMUpDown->iDelta * m_pResistanceWnd[0]->GetBendingCount();

	*pResult = 0;
}

void CMeasHistoryDlg::OnDeltaposSpinToX(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	pNMUpDown->iDelta = pNMUpDown->iDelta * m_pResistanceWnd[0]->GetBendingCount();

	*pResult = 0;
}

void CMeasHistoryDlg::OnBnClickedFail(UINT ID)
{
	if(ID == IDC_RADIO_FAILON)	
		m_bFail = TRUE;
	else						
		m_bFail = FALSE;

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		m_pResistanceWnd[i]->DrawFailMargin((m_bFail)? true : false);
}

void CMeasHistoryDlg::OnBnClickedCommand(UINT ID)
{
	if(ID == IDC_CONFIG_BTN_ZOOMIN_Y)		
	{
		UpdateData();

		int min = m_zoomScale[EN_EDIT_FROMY];
		int max = m_zoomScale[EN_EDIT_TOY];

		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			//if(min < max && max <= (int)m_pResistanceWnd[i]->GetOrgMaxScaleY())
			if(min < max)
				m_pResistanceWnd[i]->ChangeZoomScaleY(min, max);
		}
	}
	else if(ID == IDC_CONFIG_BTN_ZOOMIN_X)
	{
		UpdateData();

		int min = m_zoomScale[EN_EDIT_FROMX];
		int max = m_zoomScale[EN_EDIT_TOX];

		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			//if(min < max && max <= (int)m_pResistanceWnd[i]->GetOrgMaxScaleX())
			if(min < max)
				m_pResistanceWnd[i]->ChangeZoomScaleX(min, max);
		}
	}
	else if(ID == IDC_CONFIG_BTN_ZOOMORG_Y )
	{
		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
			m_pResistanceWnd[i]->ChangeOrgScaleY();
	}
	else if(ID == IDC_CONFIG_BTN_ZOOMORG_X )
	{
		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
			m_pResistanceWnd[i]->ChangeOrgScaleX();
	}
	else if(ID == IDC_CONFIG_BTN_REPORT)	// report
	{
		CMeasReportDlg	reportDlg(this);
		reportDlg.DoModal();
	}
}

BOOL CMeasHistoryDlg::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CBrush backBrush(m_clrBack);
	CBrush* pOldBrush = pDC->SelectObject(&backBrush);

	CRect rect;
	pDC->GetClipBox(&rect);     // Erase the area needed

	pDC->PatBlt(rect.left, rect.top, 
				rect.Width(), rect.Height(),
				PATCOPY);

	pDC->SelectObject(pOldBrush);

	return TRUE;
	//return CDialog::OnEraseBkgnd(pDC);
}

void CMeasHistoryDlg::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialog::OnSizing(fwSide, pRect);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	int nFixedWidth = IPC_HISTORY_MIN_WIDTH;
	int nFixedHeight = IPC_HISTORY_MIN_HEIGHT;

	int nWidth, nHeight;
	nWidth = abs(pRect->right - pRect->left);
	nHeight = abs(pRect->bottom - pRect->top);
	switch(fwSide) 
	{
	case 2: 
	case 6: 
	case 8: 
		if (nWidth < nFixedWidth)
			pRect->right = pRect->left + nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->bottom = pRect->top + nFixedHeight;
		break;
	case 1: 
	case 3: 
	case 4: 
		if (nWidth < nFixedWidth)
			pRect->left = pRect->right - nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->top = pRect->bottom - nFixedHeight;
		break;
	case 5: 
		if (nWidth < nFixedWidth)
			pRect->right = pRect->left + nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->top = pRect->bottom - nFixedHeight;
		break;
	case 7: 
		if (nWidth < nFixedWidth)
			pRect->left = pRect->right - nFixedWidth;
		if (nHeight < nFixedHeight)
			pRect->bottom = pRect->top + nFixedHeight;
		break;
	default:
		return;
	}

	if (nWidth < nFixedWidth || nHeight < nFixedHeight)
		SetWindowPos(NULL, pRect->left, pRect->right, nWidth, nHeight, SWP_NOSIZE | SWP_NOMOVE);

}
