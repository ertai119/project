// StatusWnd.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include <afxdlgs.h>

#include "IPCTester.h"
#include "StatusWnd.h"

#include "SerialWorker_ACCT.h"
#include "PopupDlg.h"



// CStatusWnd ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CStatusWnd, CDialog)

CStatusWnd::CStatusWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CStatusWnd::IDD, pParent)
{
	pParentWnd		= pParent;

	m_clrBack		= IPC_BACKGROUND_COLOR;
	m_clrText		= PALETTERGB(55,55,55);
	m_clrMask		= PALETTERGB(255,0,255);
	m_clrOutline	= PALETTERGB(141,154,162);

	m_lfTemp	= 0.0;

	ZeroMemory( m_rcPre, sizeof( CRect ) );
	m_testStatus = TESTSTATUS_STOP;
	m_bProgramExit = false;

	m_secCount = 0;
	m_bConfirm = true;
	m_lTempScan = false;
	m_lTempTimer = false;
}

CStatusWnd::~CStatusWnd()
{
}

void CStatusWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


void CStatusWnd::Localize()
{
	int i;
	for(i = 0; i < STATUS_BTN_MAX; i++)
	{
		m_ToolTipCtrl.UpdateTipText(IDS_MAIN_TOOLTIP_TESTRESTART + i, (CWnd *)&m_testBtn[i]);
	}
	m_ToolTipCtrl.UpdateTipText(IDS_MAIN_TOOLTIP_PREFERENCES, (CWnd *)&m_testBtn[i]);
	m_ToolTipCtrl.UpdateTipText(IDS_MAIN_TOOLTIP_EXIT, (CWnd *)&m_testBtn[i + 1]);
}

void CStatusWnd::LocalizeFont()
{
	LOGFONT lf;
	CFont*	pFont;

	// Set Font to Other Ctrls
	////////////////////////////////////
	pFont = thePrefs.GetGUIDefault();
	pFont->GetLogFont(&lf);

	CDialog::SetFont(pFont);

	int i;
	for(i = 0; i < STATUS_BTN_MAX; i++)	m_testBtn[i].SetFont(pFont);
	m_testBtn[i].SetFont(pFont);
	m_testBtn[i + 1].SetFont(pFont);
}

void CStatusWnd::InitControl()
{
	// Create ToolTip Control
	m_ToolTipCtrl.Create(this);
	m_ToolTipCtrl.Activate(TRUE);

	CRect	rcTemp(0, 0, 0, 0);

	CImageList	*pImgList;			

	// Test Button & 3 Create
	for(int i = 0; i < STATUS_BTN_MAX + 2; i++)
	{
		pImgList = theResMan.GetImageListRes(IPC_RESMAN_BTN_TEST_RESTART + i);

		m_testBtn[ i ].Create(NULL, 
							WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
							rcTemp, this, IDC_IPCTESTER_BTN_RESTART + i );
		m_testBtn[ i ].SetImageList( pImgList, 0 );
		m_testBtn[ i ].SetTransparent();

		m_ToolTipCtrl.AddTool((CWnd *)&m_testBtn[ i ],IDS_MAIN_TOOLTIP_TESTRESTART + i);

		if(i < STATUS_BTN_START)
			m_testBtn[ i ].ShowWindow (SW_HIDE);
	}

	IMAGEINFO	ImgInfo;
	pImgList = theResMan.GetImageListRes( IPC_RESMAN_IPC_COMPANYLOGO );		// ȸ�� Logo
	m_btnSKlogo.SetImageList( pImgList, 0 );
	pImgList->GetImageInfo( 0, &ImgInfo );
	CRect rectLogo = ImgInfo.rcImage;

	rcTemp.right = rcTemp.left + rectLogo.Width();
	rcTemp.bottom = rcTemp.top + rectLogo.Height();

	//Create Popup Menu Button
	m_btnSKlogo.Create(NULL, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_OWNERDRAW | BS_NOTIFY, 
		rcTemp, this, NULL );
	m_btnSKlogo.SetTransparent( );
	m_btnSKlogo.Disable();
}

void CStatusWnd::OnBnClickedCommand(UINT ID)
{
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
	if(ID >= IDC_IPCTESTER_BTN_RESTART && ID < IDC_IPCTESTER_BTN_STOP)
	{
		if(pAcct == NULL || !pAcct->IsConnection())
		{
			theApp.IPCMessageBox(_T("Serial ���� ���� �ƴմϴ�!\r\nȮ�� �� �ٽ� �õ��� �ֽʽÿ�."), 
							GetResString(IDS_IPC_CAPTION), MB_OK | MB_ICONWARNING);

			if(pAcct)
			{
				CIPCTesterDlg*	pWnd = (CIPCTesterDlg*)pParentWnd;
				if(pWnd)
					pWnd->StartConnection();
			}

			return;
		}

		pAcct->SetWindowHandle(m_hWnd);
	}

	if(ID == IDC_IPCTESTER_BTN_RESTART)		// ���� �����
	{
		if (theApp.IPCMessageBox(_T("���� ������ �� ���� �Ͻðڽ��ϱ�?"), 
					GetResString(IDS_MAIN_TOOLTIP_TESTRESTART),
					MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2 | MB_TOPMOST) == IDYES)
		{
			KillTempRequestTimer();

			StartBFTRequest();
			SetTestStatus(TESTSTATUS_RESTART);
		}
	}
	else if(ID == IDC_IPCTESTER_BTN_PAUSE)	
	{
		// IDS_MAIN_TOOLTIP_TESTPAUSE
		if (theApp.IPCMessageBox(_T("���� ������ �Ͻ����� �Ͻðڽ��ϱ�?"), 
					GetResString(IDS_MAIN_TOOLTIP_TESTPAUSE),
					MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2 | MB_TOPMOST) == IDYES)
		{
			if(m_bConfirm)
			{
				PauseBFTRequest();
				SetTestStatus(TESTSTATUS_PAUSE);
			}
			else
			{
				theApp.IPCMessageBox(_T("���� ���� ��� �� �̹Ƿ� ��� �� ������ �ֽʽÿ�"), 
					GetResString(IDS_MAIN_TOOLTIP_TESTSTOP),
					MB_OK | MB_ICONQUESTION | MB_TOPMOST);
			}

		}
	}
	else if(ID == IDC_IPCTESTER_BTN_START)		
	{
		if(pAcct && pAcct->IsConnection())
		{
			for(int i = 0; i < IPC_MAX_MATERIAL; i++)
			{
				theApp.GetResistanceWnd(i)->ClearResistanceData();
			}
			time(&m_tiPass);
			localtime(&m_tiPass);

			m_secCount = 0;

			thePrefs.ClearTestCurrentCount();
			CIPCTesterDlg*	pWnd = (CIPCTesterDlg*)pParentWnd;
			if(pWnd && pWnd->m_hWnd)
				::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_CURRENTCOUNT, UM_IPC_MEAS_CURRENTCOUNT, 0); 

			KillTempRequestTimer();

			pAcct->SetWindowHandle(m_hWnd);
			pAcct->MTPreTest();				

			SetTestStatus(TESTSTATUS_INIT_PRETEST);

			theApp.SetAppStatus(APPSTATUS_RUN);	
		}
	}
	else if(ID == IDC_IPCTESTER_BTN_STOP)	
	{
		if(GetTestStatus() != TESTSTATUS_STOP)
		{
			if (theApp.IPCMessageBox(_T("���� ������ ���� �Ͻðڽ��ϱ�?"), 
						GetResString(IDS_MAIN_TOOLTIP_TESTSTOP),
						MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2 | MB_TOPMOST) == IDYES)
			{
				if(m_bConfirm)
				{
					StopBFTRequest();
					SetTestStatus(TESTSTATUS_STOP);
					theApp.SetAppStatus(APPSTATUS_APPRUNNING);	// Application Mode
				}
				else
				{
					theApp.IPCMessageBox(_T("���� ���� ��� �� �̹Ƿ� ��� �� ������ �ֽʽÿ�"), 
						GetResString(IDS_MAIN_TOOLTIP_TESTSTOP),
						MB_OK | MB_ICONQUESTION | MB_TOPMOST);
				}

			}

		}
	}
	else if(ID == IDC_IPCTESTER_BTN_REPORT)	// ���� �̷�
	{
		TCHAR szFilters[] = _T("���ӱ������ �̷� List (*.txt)|*.txt|���ӱ������ �̷� List (*.csv)|*.csv|�������(*.*)|*.*|");

		CFileDialog dlgFile(TRUE, _T("txt"), _T("*.txt"), OFN_FILEMUSTEXIST, szFilters );				
		CString	fileName;

		CString strTitle = GetResString(IDS_IPC_SELECTFILE_CAPTION);
		CString strDir = thePrefs.GetAppDir();			// 
		dlgFile.m_ofn.lpstrTitle = strTitle;
		dlgFile.m_ofn.lpstrInitialDir = strDir;
		dlgFile.m_ofn.lpstrFile = fileName.GetBuffer(_MAX_PATH);

		BOOL bResult = dlgFile.DoModal() == IDOK ? TRUE : FALSE;
		if(bResult)
		{
			CString m_sPath = dlgFile.GetPathName();		

			CWnd* pMainWnd = theApp.GetMainWnd();
			LPTSTR pParam = new TCHAR[m_sPath.GetLength() + 1];
			lstrcpy(pParam, m_sPath);

			::PostMessage(pMainWnd->m_hWnd, UM_IPC_HISTORYDIALOG, 0, (LPARAM)pParam);	
		}
	}
	else if(ID == IDC_IPCTESTER_BTN_PREF)	
	{
		CWnd* pMainWnd = theApp.GetMainWnd();
		::PostMessage(pMainWnd->m_hWnd, UM_IPC_PREFSDIALOG, 0, 0);		
	}
	else if(ID == IDC_IPCTESTER_BTN_EXIT)	
	{
		CWnd* pMainWnd = theApp.GetMainWnd();
		WPARAM wParam = MAKEWPARAM(IDC_WINDOW_CLOSE, (WORD)BN_CLICKED);
		pMainWnd->PostMessage(WM_COMMAND, wParam, 0);		
	}

	if(ID >= IDC_IPCTESTER_BTN_RESTART && ID <= IDC_IPCTESTER_BTN_STOP)
		UpdateTestStatus();
}

void CStatusWnd::UpdateTestStatus()
{
	if(m_testStatus == TESTSTATUS_INIT_PRETEST || m_testStatus == TESTSTATUS_ALLOWABLE)
	{
		if(m_testBtn[STATUS_BTN_START].m_hWnd != NULL)
			m_testBtn[STATUS_BTN_START].Disable();
		if(m_testBtn[STATUS_BTN_PAUSE].m_hWnd != NULL)
			m_testBtn[STATUS_BTN_PAUSE].Disable();

		if(m_testStatus == TESTSTATUS_ALLOWABLE)
		{
			m_testBtn[STATUS_BTN_PAUSE].ShowWindow(SW_SHOW);
			m_testBtn[STATUS_BTN_START].ShowWindow(SW_HIDE);
		}

		return;
	}
	else
	{
		if(m_testBtn[STATUS_BTN_START].m_hWnd != NULL)
			m_testBtn[STATUS_BTN_START].Enable();
		if(m_testBtn[STATUS_BTN_PAUSE].m_hWnd != NULL)
			m_testBtn[STATUS_BTN_PAUSE].Enable();
	}


	for(int i = 0; i < STATUS_BTN_STOP; i++)	
	{
		if(m_testBtn[i].m_hWnd != NULL)
		{
			if(i <= STATUS_BTN_START)
			{
				if((m_testStatus == TESTSTATUS_STOP && i == STATUS_BTN_START)		||	
				   (m_testStatus == TESTSTATUS_PAUSE && i == STATUS_BTN_RESTART)	||	
				   (m_testStatus == TESTSTATUS_START && i == STATUS_BTN_PAUSE)		||	
				   (m_testStatus == TESTSTATUS_RESTART && i == STATUS_BTN_PAUSE) )		
				{
					m_testBtn[i].ShowWindow(SW_SHOW);
				}
				else
					m_testBtn[i].ShowWindow(SW_HIDE);
			}
		}
	}
}

BEGIN_MESSAGE_MAP(CStatusWnd, CDialog)
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_ERASEBKGND()

	ON_MESSAGE(UM_IPC_TEST_PAUSE,	OnPauseTest)		
	ON_MESSAGE(UM_IPC_TEST_END,		OnEndTest)			

	ON_MESSAGE(UM_IPC_PRETEST,		OnPreTest)
	ON_MESSAGE(UM_IPC_BFTEST,		OnBFTest)

	ON_CONTROL_RANGE(BN_CLICKED, IDC_IPCTESTER_BTN_RESTART, IDC_IPCTESTER_BTN_EXIT, OnBnClickedCommand)

	ON_WM_TIMER()
END_MESSAGE_MAP()


// CStatusWnd �޽��� ó�����Դϴ�.

BOOL CStatusWnd::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	InitControl();
	Localize();
	LocalizeFont();

	// Status Window �� ���� ��ǥ���� �����Ѵ�.
	GetWindowRect(m_orgRect);
	ScreenToClient(m_orgRect);

	m_orgRect.bottom = IPC_MAIN_MENU_HEIGHT;		// rcImg.Height();

	SetTempRequestTimer();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BOOL CStatusWnd::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if (pMsg->message == WM_MOUSEMOVE) m_ToolTipCtrl.RelayEvent(pMsg);	

	return CDialog::PreTranslateMessage(pMsg);
}

void CStatusWnd::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	CRect		rcImg;
	CImageList	*pImgList;
	IMAGEINFO	ImgInfo;
	CDC *pDC = GetDC();
	
	CRect	rcClient;
	GetClientRect(&rcClient);

	// Button Start Position ���
	CRect	rcBtnImg, rcMoveImg;
	pImgList = theResMan.GetImageListRes(IPC_RESMAN_BTN_TEST_START);
	pImgList->GetImageInfo(0, &ImgInfo);
	rcBtnImg = ImgInfo.rcImage;

	int btnStartX = 0;	
	int btnStartY = IPC_STATUS_TOP;

	// Locate Tester Buttons
	//////////////////////////////////////////////////////////////////////////
	btnStartX = IPC_MAIN_LEFT;

	for(int i = 0; i < STATUS_BTN_MAX; i++)	
	{
		int btnleft = btnStartX;	

		if(m_testBtn[i].m_hWnd != NULL)
		{
			m_testBtn[i].MoveWindow( btnleft, btnStartY, rcBtnImg.Width( ), rcBtnImg.Height( ), FALSE );
			m_testBtn[i].Invalidate(FALSE );
			m_testBtn[i].ShowWindow(SW_SHOW);

			btnStartX += rcBtnImg.Width() + IPC_MAIN_BTN_INTERVAL;
			if(i < STATUS_BTN_START)
			{
				btnStartX = btnleft;
			}
		}
	}

	UpdateTestStatus();
	
	int logoStartX = btnStartX - IPC_MAIN_BTN_INTERVAL;

	pImgList = theResMan.GetImageListRes(IPC_RESMAN_BTN_EXIT);
	pImgList->GetImageInfo(0, &ImgInfo);
	rcBtnImg = ImgInfo.rcImage;

	btnStartX = rcClient.right - (IPC_MAIN_LEFT + rcBtnImg.Width());
	if(m_testBtn[STATUS_BTN_MAX + 1].m_hWnd != NULL)
	{
		m_testBtn[STATUS_BTN_MAX + 1].MoveWindow( btnStartX, btnStartY, rcBtnImg.Width( ), rcBtnImg.Height( ), FALSE );
		m_testBtn[STATUS_BTN_MAX + 1].Invalidate(FALSE );
		m_testBtn[STATUS_BTN_MAX + 1].ShowWindow(SW_SHOW);
	}

	btnStartX -= rcBtnImg.Width() + IPC_MAIN_BTN_INTERVAL;

	pImgList = theResMan.GetImageListRes(IPC_RESMAN_BTN_PREFERENCE);
	pImgList->GetImageInfo(0, &ImgInfo);
	rcBtnImg = ImgInfo.rcImage;

	if(m_testBtn[STATUS_BTN_MAX].m_hWnd != NULL)
	{
		m_testBtn[STATUS_BTN_MAX].MoveWindow( btnStartX, btnStartY, rcBtnImg.Width( ), rcBtnImg.Height( ), FALSE );
		m_testBtn[STATUS_BTN_MAX].Invalidate(FALSE );
		m_testBtn[STATUS_BTN_MAX].ShowWindow(SW_SHOW);
	}
	
	int logoEndtX = btnStartX;

	if(m_btnSKlogo.m_hWnd)
	{
		CRect	rcBtn;
		m_btnSKlogo.GetWindowRect(&rcBtn);
		ScreenToClient(&rcBtn);

		btnStartY = (rcClient.Height() - rcBtn.Height()) / 2;

		int width = logoEndtX - logoStartX;
		int nLeftPos = logoStartX + (width - rcBtn.Width()) / 2;

		m_btnSKlogo.MoveWindow(nLeftPos, btnStartY, rcBtn.Width(), rcBtn.Height());
		m_btnSKlogo.Invalidate(FALSE);
		m_btnSKlogo.ShowWindow(SW_SHOW);
	}

	ReleaseDC(pDC);	
}

void CStatusWnd::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialog::OnSizing(fwSide, pRect);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
}

BOOL CStatusWnd::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CBrush backBrush(m_clrBack);
	CBrush* pOldBrush = pDC->SelectObject(&backBrush);

	CRect rect;
	pDC->GetClipBox(&rect);     // Erase the area needed

	pDC->PatBlt(rect.left, rect.top, 
				rect.Width(), rect.Height(),
				PATCOPY);

	pDC->SelectObject(pOldBrush);
	return FALSE;    // Prevents the execution of return
	//return CDialog::OnEraseBkgnd(pDC);
}

HRESULT CStatusWnd::OnBFTest( WPARAM wParam, LPARAM lParam )
{	
	static bool	bAllowable = true;

	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;

	switch(wParam)
	{
		case ID_IPC_BFTEST_PARAM_CONFIRM :		
			{
				if(isBFTest())
					pAcct->ReadyBFT();
			}
			break;	
		case ID_IPC_BFTEST_READY_CONFIRM :		
			{
				if(thePrefs.m_bAutoStart)
				{
					bAllowable = false;
					SetTestStatus(TESTSTATUS_ALLOWABLE);

					if(isBFTest())
						pAcct->TempDataRequest();
				}
				else 
				{
					if(isBFTest())
						StartBFTRequest();
				}
			}

			break;
		case ID_IPC_BFTEST_START_CONFIRM :		
			{
				if(isBFTest())
					pAcct->TempDataRequest();

				if(pParentWnd)
				{
					float timer = thePrefs.m_interval;
					short min = timer;
					short sec = (short)(timer * 10 ) % 10;
					long  termSec = (min * 60 + sec * 6);

					time(&m_tiPass);
					localtime(&m_tiPass);

					if(m_secCount == 0)
					{
						m_timerID = IPC_TEMP_DATAREQUEST_TIMER;
						pParentWnd->SetTimer(IPC_TEMP_DATAREQUEST_TIMER, termSec * 1000, NULL);
					}
					else
					{
						termSec = termSec - m_secCount;
						m_timerID = IPC_TEMP_DATAREQUEST_TIMER2;
						pParentWnd->SetTimer(IPC_TEMP_DATAREQUEST_TIMER2, termSec * 1000, NULL);
					}
				}

				// 
			}
			break;
		case ID_IPC_BFTEST_END_CONFIRM :		
			{
				if(pParentWnd && m_timerID)
					pParentWnd->KillTimer(m_timerID);

				theApp.SetAppStatus(APPSTATUS_APPRUNNING);	// Application Mode
			}
			break;
		case ID_IPC_BFTEST_PAUSE_CONFIRM :		
			{
				if(pParentWnd && m_timerID)
				{
					time_t	ti;
					time(&ti);
					localtime(&ti);
	
					m_secCount += ti - m_tiPass;
					pParentWnd->KillTimer(m_timerID);
				}
			}
			break;

		case ID_IPC_BFTEST_TEMPDATA :			
			{
				char* pStr = (char*)lParam;
				m_lfTemp = atof(pStr);

				thePrefs.m_bftTemp = m_lfTemp;
				CIPCTesterDlg*	pWnd = (CIPCTesterDlg*)pParentWnd;
				if(pWnd && pWnd->m_hWnd)
				{
					char*	pdata = new char[20];
					if(pdata)
					{
						sprintf(pdata, "%.02lf", m_lfTemp);
						::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_TEMP, 0, (LPARAM)pdata); 
					}
				}

				if(m_lTempScan)
				{
					::InterlockedExchange(&m_lTempScan, 0);
					return 0;
				}

				m_bConfirm = false;

				if(thePrefs.m_bAutoStart && !bAllowable && GetTestStatus() == TESTSTATUS_ALLOWABLE)
				{
					if(m_lfTemp >= (float)(thePrefs.m_temp - thePrefs.m_allowable) &&
					   m_lfTemp <= (float)(thePrefs.m_temp + thePrefs.m_allowable) )
					{
						bAllowable = true;


						StartBFTRequest();

						SetTestStatus(TESTSTATUS_START);
					}
					else
					{
						SetTimer(IPC_TEMP_DATACHECK_TIMER, 2 * 1000, NULL);
					}
				}
				else	
				{
					if(isBFTest())
						pAcct->MTPreTest();	
				}
			}
			break;

		case ID_IPC_BFTEST_TEMPDATA_SCAN :
			if(lParam == 1)
			{
				SetTempRequestTimer();
			}
			else
			{
				KillTempRequestTimer();

			}
			break;

		default :
			break;
	}
	UpdateTestStatus();
	return 0;
}

HRESULT CStatusWnd::OnPauseTest( WPARAM wParam, LPARAM lParam )
{
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;

	if(pAcct && pAcct->IsConnection())
	{
		PauseBFTRequest();
		SetTestStatus(TESTSTATUS_PAUSE);
		UpdateTestStatus();
	}
	return 0;
}

HRESULT CStatusWnd::OnEndTest( WPARAM wParam, LPARAM lParam )
{
	{
		StopBFTRequest();
		SetTestStatus(TESTSTATUS_STOP);
		theApp.SetAppStatus(APPSTATUS_APPRUNNING);	// Application Mode

		UpdateTestStatus();
	}
	return 0;
}

HRESULT CStatusWnd::OnPreTest( WPARAM wParam, LPARAM lParam )
{
	static short	m_selectMT = 0;			
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
	
	switch(wParam)
	{
		case ID_IPC_PRETEST_CONFIRM :		
			{
				m_selectMT = 0;
				bool	bSelect = false;
				short	failcount = 0;
				short	selectcount = 0;
				for(int i = 0; i < IPC_MAX_MATERIAL; i++)
				{
					if(thePrefs.m_materialInfo[i])
					{
						if(!(theApp.GetResistanceWnd(i)->IsFail()))
						{
							m_selectMT = i + 1;
							pAcct->SelectMTRequest(m_selectMT);
							bSelect = true;
							break;
						}
						else
							failcount++;
						selectcount++;
					}
				}

				if(!bSelect)
				{
					StopBFTRequest();
					SetTestStatus(TESTSTATUS_STOP);
					theApp.SetAppStatus(APPSTATUS_APPRUNNING);	// Application Mode

					UpdateTestStatus();

					if(failcount == selectcount)
						theApp.IPCMessageBox(
									_T("������ ���� �մϴ�.\r\n��� ������ Fail �����Դϴ�."), 
									GetResString(IDS_IPC_CAPTION), 
									MB_OK | MB_ICONINFORMATION);
					else
						theApp.IPCMessageBox(_T("���õ� ������ �����ϴ�"), 
											GetResString(IDS_IPC_CAPTION), 
											MB_OK | MB_ICONINFORMATION);

				}

			}
			break;

		case ID_IPC_PRETEST_INITIALIZE_CONFIRM :		
			{
				bool	bSelect = false;
				for(int i = m_selectMT; i < IPC_MAX_MATERIAL; i++)
				{
					if(thePrefs.m_materialInfo[i])
					{
						if(!(theApp.GetResistanceWnd(i)->IsFail()))
						{
							m_selectMT = i + 1;
							SleepEx(500, TRUE);

							pAcct->SelectMTRequest(m_selectMT);
							bSelect = true;
							break;
						}
					}
				}

				if(!bSelect)	
				{
					SetTempRequestTimer();

					if(GetTestStatus() == TESTSTATUS_INIT_PRETEST)
					{
						CPopupDlg	popupDlg;
						popupDlg.SetPopupParam(	IDS_IPC_POPUP_CAPTION1,
												IDS_POPUP_BFTEST_READY,
												IPC_RESMAN_BTN_TEST_START,
												IPC_RESMAN_BTN_TEST_CANCEL);
						if(popupDlg.DoModal() == IDOK)
						{
							KillTempRequestTimer();

							CSerialWorker_ACCT::WORKINFO_INDICATION* pParam = new CSerialWorker_ACCT::WORKINFO_INDICATION;
							if(pParam)
							{
								for(int i = 0; i < 4; i++)
									pParam->m_mtInfo[i] = thePrefs.m_materialInfo[i];
								pParam->m_amplitude = thePrefs.m_amplitude;
								pParam->m_bendingSpeed = thePrefs.m_bendingSpeed;
								pParam->m_autoStart = thePrefs.m_bAutoStart;
								pParam->m_temp = thePrefs.m_temp;

								pAcct->SetParamInfo(pParam);

								delete pParam;
							}
							if(thePrefs.m_bAutoStart)
								SetTestStatus(TESTSTATUS_ALLOWABLE);	
							else
								SetTestStatus(TESTSTATUS_START);		

							CIPCTesterDlg*	pWnd = (CIPCTesterDlg*)pParentWnd;
							if(pWnd && pWnd->m_hWnd)
							{
								::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_CREATEFILE, 0, 0); 
							}
						}
						else
						{
							SetTestStatus(TESTSTATUS_STOP);
							theApp.SetAppStatus(APPSTATUS_APPRUNNING);	
						}

						UpdateTestStatus();
					}
					else
					{
						CIPCTesterDlg*	pWnd = (CIPCTesterDlg*)pParentWnd;
						if(pWnd && pWnd->m_hWnd)
						{
							::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_CURRENTCOUNT, UM_IPC_MEAS_CURRENTCOUNT, thePrefs.GetTestCurrentCount()); 
							::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_TOTALCOUNT, UM_IPC_MEAS_TOTALCOUNT, thePrefs.GetTestTotalCount()); 
							::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_DISPLAY, 0, thePrefs.GetTestCurrentCount()); 
						}

						if(thePrefs.m_bUsed && thePrefs.GetTestCurrentCount() >= thePrefs.m_stopCount)
						{
							theApp.Log(1, _T("�պ�� ���� Ƚ���� �����߽��ϴ�! ��������� ���� �մϴ�."));

							StopBFTRequest();
							SetTestStatus(TESTSTATUS_STOP);
							theApp.SetAppStatus(APPSTATUS_APPRUNNING);	// Application Mode

							UpdateTestStatus();

							theApp.IPCMessageBox(_T("�պ�� ���� Ƚ���� �����߽��ϴ�!\r\n��������� ���� �մϴ�."), 
												GetResString(IDS_IPC_CAPTION), 
												MB_OK | MB_ICONINFORMATION);

							theApp.Log(1, _T("�պ�� ���� Ƚ���� ����! ��������� ���� Ȯ��!"));
							return 0;
						}

						m_bConfirm = true;
					}
				}
			}
			break;

		case ID_IPC_PRETEST_SELECT_CONFIRM :		
			{
#ifdef	_IPC_TEST_RMI_
				SleepEx(600, TRUE);
				char*	pdata = new char[256];
				if(pdata)
				{
					sprintf(pdata, "%.06lf", 250.123);
					::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_RESISTANCE, (LPARAM)pdata);
				}
#else
				CRMIInterface* pRMI = theApp.m_pRMI;
				if(pRMI)
				{
					pRMI->SetWindowHandle(m_hWnd);
					pRMI->RequestResistData();
				}
#endif
			}
			break;

		case ID_IPC_PRETEST_RESISTANCE :			
			{
				char* pStr = (char*)lParam;
				float lfResist = atof(pStr);
				delete[] pStr;

#ifdef	_IPC_TEST_
				::PostMessage(m_hWnd, UM_IPC_PRETEST, ID_IPC_PRETEST_INITIALIZE_CONFIRM, 0);
#else
				pAcct->SelectMTRequest(0);
#endif
				CIPCTesterDlg*	pWnd = (CIPCTesterDlg*)pParentWnd;
				if(pWnd && pWnd->m_hWnd)
				{
					SResistanceData*	pData = new SResistanceData;
					if(pData)
					{
						pData->m_count = thePrefs.GetTestCurrentCount();

						pData->m_material = m_selectMT;
						pData->m_lfResist = lfResist;

						if(GetTestStatus() == TESTSTATUS_INIT_PRETEST)
						{
							thePrefs.m_preTest[m_selectMT - 1] = lfResist;
							::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_PRETEST, m_selectMT, (LPARAM)pData);
						}
						else
						{
							::PostMessage(pWnd->m_hWnd, UM_IPC_MEAS_RESISTANCE, m_selectMT, (LPARAM)pData);
						}
					}
				}	
			}
			break;

		case ID_IPC_PRETEST_RESISTANCE_ERROR :
			{
				theApp.WarningLog(_T("������ ���� ���װ� ��� �����Դϴ�!"));

				if(GetTestStatus() == TESTSTATUS_INIT_PRETEST)
				{
					SetTestStatus(TESTSTATUS_STOP);
					theApp.SetAppStatus(APPSTATUS_APPRUNNING);	// Application Mode
				}
				else
				{
					if(pParentWnd && m_timerID)
					{
						time_t	ti;
						time(&ti);
						localtime(&ti);
		
						m_secCount += ti - m_tiPass;

						pParentWnd->KillTimer(m_timerID);
						m_timerID = 0;
					}
					// 

					PauseBFTRequest();
					SetTestStatus(TESTSTATUS_PAUSE);
				}
				UpdateTestStatus();

				theApp.IPCMessageBox(_T("���� ���װ� ��� �����Դϴ�!\r\n��������� �Ͻ����� �մϴ�."), 
									GetResString(IDS_IPC_CAPTION), 
									MB_OK | MB_ICONINFORMATION);
			}

			break;

		case ID_IPC_PRETEST_SERIAL_ERROR :		
				if(GetTestStatus() == TESTSTATUS_INIT_PRETEST)
				{
					SetTestStatus(TESTSTATUS_STOP);
					theApp.SetAppStatus(APPSTATUS_APPRUNNING);	// Application Mode
					UpdateTestStatus();
				}
			break;

		default :
			break;
	}
	return 0;

}

void CStatusWnd::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(nIDEvent == IPC_TEMP_DATAREQUEST_TIMER)
	{
		KillTempRequestTimer();

		time_t	ti;
		time(&ti);
		localtime(&ti);
		m_tiPass = ti;
		m_secCount = 0;

		thePrefs.IncreaseTestCount();
		TempDataRequest();
	}
	else if(nIDEvent == IPC_TEMP_DATAREQUEST_TIMER2)
	{
		KillTempRequestTimer();

		float timer = thePrefs.m_interval;
		short min = timer;
		short sec = (short)(timer * 10 ) % 10;
		long  termSec = (min * 60 + sec * 6);

		KillTimer(m_timerID);
		m_timerID = IPC_TEMP_DATAREQUEST_TIMER;
		SetTimer(IPC_TEMP_DATAREQUEST_TIMER, termSec * 1000, NULL);

		time_t	ti;
		time(&ti);
		localtime(&ti);
		m_tiPass = ti;
		m_secCount = 0;
	
		thePrefs.IncreaseTestCount();
		TempDataRequest();
	}
	else if(nIDEvent == IPC_TEMP_DATASCAN)
	{
		::InterlockedExchange(&m_lTempScan, 1);
		TempDataRequest();
	}
	else if(nIDEvent == IPC_TEMP_DATACHECK_TIMER)
	{
		KillTimer(IPC_TEMP_DATACHECK_TIMER);

		TempDataRequest();
	}

}

void CStatusWnd::StartBFTRequest()
{
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
	if(pAcct && pAcct->IsConnection())
		pAcct->StartBFTRequest();
}

void CStatusWnd::PauseBFTRequest()
{
	if(isBFTest())
	{
		CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
		if(pAcct && pAcct->IsConnection())
			pAcct->PauseBFTRequest();
	}
}

void CStatusWnd::StopBFTRequest()
{
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
	if(pAcct && pAcct->IsConnection())
		pAcct->EndBFTRequest();
}

void CStatusWnd::TempDataRequest()
{
	CSerialWorker_ACCT*	pAcct = theApp.m_pACCT;
	if(pAcct && pAcct->IsConnection())
	{
		pAcct->TempDataRequest();
	}
	else if(!pAcct->IsConnection())
	{
		CIPCTesterDlg*	pWnd = (CIPCTesterDlg*)pParentWnd;
		if(pWnd)
			pWnd->StartConnection();
	}
}

void CStatusWnd::SetTempRequestTimer()
{
	if(m_lTempTimer == false)
	{
		SetTimer(IPC_TEMP_DATASCAN, 3 * 1000, NULL);
		::InterlockedExchange(&m_lTempTimer, true);
	}
}

void CStatusWnd::KillTempRequestTimer()
{
	if(m_lTempTimer == TRUE)
	{
		KillTimer(IPC_TEMP_DATASCAN);
		::InterlockedExchange(&m_lTempTimer, false);
	}
}
