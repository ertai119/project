#pragma once


// System Windows Menu
#define IDB_BTN_CLOSE                   9004
#define IDB_BTN_MAX                     9005
#define IDB_BTN_MIN                     9006

// Window background Images
#define IDB_COUNT_BG                    9100
