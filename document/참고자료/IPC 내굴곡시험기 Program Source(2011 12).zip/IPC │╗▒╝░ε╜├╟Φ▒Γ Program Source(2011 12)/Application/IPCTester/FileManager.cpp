// FileManager.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IPCTester.h"
#include "FileManager.h"

// File ���� ����
#include <io.h>
#include <fcntl.h>
#include <share.h>
#include <sys/types.h>
#include <sys/stat.h> 

#include "StatusWnd.h"

#define	BFT_TIMER_DELAY			1000				// 1�� Timer 

// CFileManager

CFileManager::CFileManager()
{
	m_hIOPORT = NULL;
	m_hThread = NULL;
	m_IDThread = 0;
	m_long_StartFlag = 0;

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		::ZeroMemory(&ResistData[i], sizeof(SResistanceData));

	::InitializeCriticalSection(&m_CriticalSection);
}

CFileManager::~CFileManager()
{
	::DeleteCriticalSection(&m_CriticalSection);
}


// CFileManager ��� �Լ�
BOOL CFileManager::Start(CWnd* pWindow, DWORD timeout)
{
	if(GetStartFlag() == FALSE)
	{
		if(timeout == 0)	timeout = INFINITE;
		m_TimeOut = timeout;
		m_pMainWnd = (CWnd*)pWindow;

#ifndef	_WIN32_WINDOWS_
		m_hIOPORT = ::CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);
#endif
		m_hThread = ::CreateThread(NULL, 0, CFileManager::InterfaceThread, this, 0, &m_IDThread);
		
		return TRUE;
	}
#ifdef _DEBUG
	else
		theApp.WarningLog(_T("WARRING : CFileManager Already Started"));
#endif
	return FALSE;
}

void CFileManager::Stop()
{
	if(GetStartFlag() == TRUE)
	{
		SetStartFlag(FALSE);

#ifdef	_WIN32_WINDOWS_ 
		::PostThreadMessage(m_IDThread, WM_IOPORT_NOTIFY, IOPORT_SHUTDOWN, NULL);
#else
		::PostQueuedCompletionStatus(m_hIOPORT, 0, IOPORT_SHUTDOWN, NULL);
#endif
		::WaitForSingleObject(m_hThread, INFINITE);

		::CloseHandle(m_hThread);

		SetStartFlag(FALSE);

		m_hThread = NULL;
		m_IDThread = 0;
	}

#ifndef	_WIN32_WINDOWS_ 
	if(m_hIOPORT)
	{
		::CloseHandle(m_hIOPORT);
		m_hIOPORT = NULL;
	}
#endif
}


DWORD WINAPI CFileManager::InterfaceThread(LPVOID lpParameter)
{
#if _WIN32_WINNT >= 0x0400
	HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
#else
	HRESULT hr = CoInitialize(NULL);
#endif
	CFileManager* pParent = (CFileManager*)lpParameter;
	HANDLE  hPort;
	
#ifdef	_WIN32_WINDOWS_ 
	DWORD		dwRet;
    MSG			Msg;
#else
	DWORD UserKey;					
	DWORD NumberOfBytesTransferred;	
	LPOVERLAPPED lpOverlapped;	
#endif

	BOOL bContinue = TRUE;
	BOOL bStatus;
	DWORD timeout = INFINITE;

	if(pParent == NULL)
	{	
#ifdef _DEBUG
		theApp.ErrorLog(_T("ERROR : Parent Pointer is NULL"));
#endif
		return 0;
	}
	hPort = pParent->Get_IOPORT();
	timeout = pParent->m_TimeOut;
#ifndef	_WIN32_WINDOWS_ 
	if(hPort == NULL)
	{	
#ifdef _DEBUG
		theApp.ErrorLog(_T("ERROR : IOPORT Handle == NULL []"));
#endif
		return 0;
	}
#endif

#ifdef _DEBUG
	theApp.Log(FALSE, _T("FileManager started"));
#endif
	pParent->SetStartFlag(TRUE);

	while(bContinue)
	{
#ifdef	_WIN32_WINDOWS_ 
		dwRet = ::MsgWaitForMultipleObjects(1, &pParent->m_hThread, FALSE, timeout, QS_ALLPOSTMESSAGE);
		if (dwRet == WAIT_TIMEOUT)
		{
#else
		bStatus = ::GetQueuedCompletionStatus(hPort, &NumberOfBytesTransferred, &UserKey, &lpOverlapped, timeout);
		if(bStatus == FALSE)
		{
			if(lpOverlapped != NULL)	
			{
				theApp.Log(FALSE, _T("CFileManager::InterfaceThread GetQueuedCompletionStatus Error(%ld)"), GetLastError());
				//bContinue = FALSE;
			}
			else
#endif
			{
				pParent->TimeOutFunction();
				timeout = pParent->m_TimeOut;
			}
			continue;
		}

#ifdef	_WIN32_WINDOWS_ 
		while (bContinue && PeekMessage(&Msg, NULL, 0, 0, PM_NOREMOVE))
		{
			bStatus = ::GetMessage(&Msg, NULL, 0, 0);
			if(bStatus == -1) 
			{
				bContinue = FALSE;
				break;
			}
#endif

#ifdef	_WIN32_WINDOWS_ 
		switch(Msg.wParam)
#else
		switch(UserKey)
#endif
		{
		case IOPORT_SHUTDOWN:
			bContinue = FALSE;
			break;

		default:
#ifdef	_WIN32_WINDOWS_ 
			pParent->OnUnknownMsg(Msg.wParam, (void*)Msg.lParam);
#else				
			pParent->OnUnknownMsg(UserKey, lpOverlapped);
#endif
			break;
		}

#ifdef	_WIN32_WINDOWS_ 
		TranslateMessage(&Msg); 
		DispatchMessage(&Msg); 
		}
#endif
	}

	pParent->SetStartFlag(FALSE);

#ifdef _DEBUG
	theApp.Log(FALSE, _T("FileManager was stopped"));
#endif

	if(pParent->m_hThread)
		::CloseHandle(pParent->m_hThread);
	pParent->m_hThread = NULL;

	::CoUninitialize();
	return 0;
}

void CFileManager::OnUnknownMsg(DWORD userkey, void* pParam)
{
	switch(userkey)
	{
		case __INNERP_FILEMANAGER_ADDRESISTANCE__ :
			AddResistanceData(pParam);
			break;

		case __INNERP_FILEMANAGER_BFTFILE_CREATE__ :
			SaveHeader();
			break;

		case __INNERP_FILEMANAGER_BFTFILE_SAVE__ :
			{
				long count = (LPARAM)pParam;
				SaveBFTFile(count);
			}
			break;

		default :
			break;
	}
}

void CFileManager::TimeOutFunction()
{

}

void CFileManager::AddResistanceData(void* pParam)
{
	SResistanceData* pData = (SResistanceData*)pParam;
	if(pData == NULL)
		return;

	CIPCTesterDlg*	pDlg = (CIPCTesterDlg*)m_pMainWnd;
	if(pDlg == NULL)
	{
		delete pData;
		return;
	}

	CopyMemory(&ResistData[pData->m_material - 1], pData, sizeof(SResistanceData));

	BOOL	ret = S_OK;
	CResistanceWnd* pResistance = pDlg->GetResistanceWnd(pData->m_material - 1);
	if(pResistance)
		ret = pResistance->AddResistanceData(pData);

	if(ret != S_OK)
	{
		ResistData[pData->m_material - 1].m_fail = 1;
		
		::PostMessage(pResistance->m_hWnd, UM_IPC_MEAS_DISPLAY, 0, pData->m_count);

		bool	bSelect = false;
		for(int i = 0; i < IPC_MAX_MATERIAL; i++)
		{
			if(thePrefs.m_materialInfo[i])
			{
				if(!(theApp.GetResistanceWnd(i)->IsFail()))
				{
					bSelect = true;
					break;
				}
			}
		}

		if(!bSelect)	
		{
			SleepEx(300, TRUE);
			::PostMessage(pDlg->GetStatusWindow()->m_hWnd, UM_IPC_TEST_END, 0, 0);

			theApp.IPCMessageBox(
						_T("������ ���� �մϴ�.\r\n��� ������ Fail �����Դϴ�."), 
						GetResString(IDS_IPC_CAPTION), 
						MB_OK | MB_ICONINFORMATION);
		}
	}
	//
}

BOOL CFileManager::SaveHeader()
{
	CStringA	strHeader;
	CStringA	strTemp;

	strHeader.GetBuffer(2048);

	strHeader = _T("Moving Rate\r\n");

	strTemp.Format(_T("(Bending/Min.) : %d,Start Temp.(��) : %.1f\r\n"),
					thePrefs.m_bendingSpeed, thePrefs.m_temp);
	strHeader += strTemp;

	strHeader += _T("\r\n");
	strHeader += _T("Initial Resistances(��)\r\n");

	strTemp.Format(_T(",%s,%s,%s,%s,\r\n"),
										thePrefs.m_materialName[0], 
										thePrefs.m_materialName[1], 
										thePrefs.m_materialName[2], 
										thePrefs.m_materialName[3] 
										);
	strHeader += strTemp;

	strTemp.Format(_T(",%.6lf,%.6lf,%.6lf,%.6lf,\r\n"),
										thePrefs.m_preTest[0], 
										thePrefs.m_preTest[1], 
										thePrefs.m_preTest[2], 
										thePrefs.m_preTest[3] 
										);
	strHeader += strTemp;
	strHeader += _T("\r\n");

	strTemp.Format(_T("Failure Margin(%%) : %.1f\r\n"),
										thePrefs.m_failPercent
										);
	strHeader += strTemp;
	strHeader += _T("\r\n");

	strTemp.Format(_T("Time,Number of Bending,%s,%s,%s,%s,Fail Status,Temp.(��)\r\n"),
										thePrefs.m_materialName[0], 
										thePrefs.m_materialName[1], 
										thePrefs.m_materialName[2], 
										thePrefs.m_materialName[3] );
					
	strHeader += strTemp;


	LPTSTR filename = CreateFilePath();
	BOOL ret = WriteBlock(filename, (LPSTR)strHeader.GetString(), strHeader.GetLength());

	strHeader.ReleaseBuffer();
	return ret;
}

BOOL CFileManager::SaveBFTFile(long count)
{
	CStringA	strBFTest;
	CStringA	strTemp;

	strBFTest.GetBuffer(1024);

	struct tm* ctime = NULL;
	time_t	ti;
	time(&ti);
	ctime = localtime(&ti);

	CString strFail;
	strFail.Empty();
	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
	{
		if(ResistData[i].m_fail)
		{
			CString stemp;
			stemp.Format(_T(",%d"), ResistData[i].m_material);
			strFail += stemp;
		}
	}

	if(!strFail.IsEmpty())
	{
		strFail += _T(" Fail");
		strFail = strFail.Right(strFail.GetLength() - 1);
	}

	strTemp.Format(_T("%4d/%02d/%02d %02d:%02d:%02d,%ld,%.6lf,%.6lf,%.6lf,%.6lf,\"%s\",%.1f\r\n"),
							ctime->tm_year + 1900, ctime->tm_mon + 1, ctime->tm_mday,
							ctime->tm_hour, ctime->tm_min, ctime->tm_sec,
							count,
							ResistData[0].m_lfResist, ResistData[1].m_lfResist, 
							ResistData[2].m_lfResist, ResistData[3].m_lfResist, 
							strFail.GetString(),
							thePrefs.m_bftTemp
							);
					
	strBFTest = strTemp;

	LPTSTR filename = GetFilePath();
	WriteBlock(filename, (LPSTR)strBFTest.GetString(), strBFTest.GetLength());

	strBFTest.ReleaseBuffer();

	for(int i = 0; i < IPC_MAX_MATERIAL; i++)
	{
		::ZeroMemory(&ResistData[i], sizeof(SResistanceData));
	}

	return S_OK;
}

LPTSTR CFileManager::CreateFilePath()
{
	CString strFileName = thePrefs.m_fileName;

	struct tm* ctime = NULL;
	time_t	ti;
	time(&ti);
	ctime = localtime(&ti);

	if(strFileName.IsEmpty())
	{

		strFileName.Format(	_T("%4d%02d%02d%02d%02d%02d.txt"), 
							ctime->tm_year + 1900, ctime->tm_mon + 1, ctime->tm_mday,
							ctime->tm_hour, ctime->tm_min, ctime->tm_sec);
	}

	::sprintf(m_saveFile, _T("%s/%s"), thePrefs.GetFileDir(), strFileName);

	if(PathFileExists(m_saveFile))
	{
		CString newFileName;
		newFileName.Format(_T("%s/%4d%02d%02d%02d%02d%02d.bak"), thePrefs.GetFileDir(),
							ctime->tm_year + 1900, ctime->tm_mon + 1, ctime->tm_mday,
							ctime->tm_hour, ctime->tm_min, ctime->tm_sec);
		::MoveFile(m_saveFile, newFileName);
	}

	return m_saveFile;
}

#define MAXRETRIES  9
#define RETRYDELAY  3000


BOOL CFileManager::WriteBlock(LPTSTR filepath, LPSTR pBuffer, int nsize)
{
	short dwRetries = 0;

	do
	{
		int wHandle = _sopen(	filepath, 
								_O_CREAT | _O_RDWR | _O_BINARY | _O_SEQUENTIAL, 
								_SH_DENYNO, 
								_S_IREAD | _S_IWRITE); 

		if(wHandle && wHandle != -1)
		{
			_lseek(wHandle, 0, SEEK_END);

			int writen;
			if((writen = _write(wHandle, (LPVOID)pBuffer, nsize)) == -1)
			{
				DWORD error = ::GetLastError();
				theApp.ErrorLogEvent(_T("CFileManager::WriteBlock WriteFile API [LI(%lu) Win32ERRCD(%ld)]"), 
									__LINE__, error);
			
				_close(wHandle);
				return FALSE;
			}
			_close(wHandle);

			return TRUE;
		}
		else
		{
			DWORD dwErr = ::GetLastError();
			theApp.ErrorLogEvent(_T("CFileManager::WriteBlock FileOpen API [LI(%lu) Win32ERRCD(%ld)]"), 
								__LINE__, dwErr);

			if ( ERROR_SHARING_VIOLATION == dwErr )
			{
				dwRetries += 1;
				SleepEx(RETRYDELAY, TRUE);		
				continue;
			}
		}

	} while ( dwRetries < MAXRETRIES );

	return FALSE;
}

BOOL CFileManager::ReadLine(LPTSTR filepath, LPSTR pBuffer, int nline)
{
	BOOL	result = S_FALSE;

	FILE *file = fopen ( filepath, "rb" );
	if(file != NULL)
	{
		char	line[256];
		int		lineCount = 0;

		while(fgets(line, sizeof(line), file) != NULL)
		{
			lineCount++;
			if(lineCount == nline)
			{
				strcpy(pBuffer, line);
				result = S_OK;
				break;
			}
		}
		fclose(file);
	}

	return result;
}

BOOL CFileManager::ReadBlock(LPTSTR filepath, LPSTR pBuffer, int nline)
{
	FILE *file = fopen ( filepath, "rb" );
	if(file != NULL)
	{
		char	line[256];
		int		lineCount = 0;

		while(fgets(line, sizeof(line), file) != NULL)
		{
			lineCount++;
			if(lineCount == nline)
			{
				strcpy(pBuffer, line);
				break;
			}
		}
		fclose(file);
	}

	return TRUE;
}
