#pragma once

// IOPORT NOTIFY User message
#define WM_IOPORT_NOTIFY	WM_USER + 550

// ALL WM_USER messages are to be declared here *after* 'WM_FIRST_BEETOTO_USER_MSG'
enum EUserWndMessages
{
	// *) Do *NOT* place any message *before* UM_FIRST_BEETOTO_USER_MSG !!
	// *) Do *NOT* use any WM_USER messages in the range WM_USER - WM_USER+0x100 !!
	UM_FIRST_BFTMS_USER_MSG = (WM_USER + 0x600 + 1),		// 1536 + 1

	// Preferences
	UM_CONFIG_LOCALIZE,
	UM_IPC_PREFSDIALOG,
	UM_IPC_AMPTESTDIALOG,
	UM_IPC_HISTORYDIALOG,
	UM_IPC_USERDIALOG,

	UM_IPC_USERDIALOG_OK,

	UM_IPC_TEST_PAUSE,			
	UM_IPC_TEST_END,			

	UM_IPC_AMPTEST,				
	UM_IPC_PRETEST,				
	UM_IPC_BFTEST,				

	UM_IPC_MEAS_TEMP,			
	UM_IPC_MEAS_CURRENTCOUNT,	
	UM_IPC_MEAS_TOTALCOUNT,		
	UM_IPC_MEAS_PRETEST,		


	UM_IPC_MEAS_CREATEFILE,		
	UM_IPC_MEAS_RESISTANCE,		
	UM_IPC_MEAS_DISPLAY,		

	UM_IPC_CLOSE,

};
